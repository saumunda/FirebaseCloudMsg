package com.JavaWallet.Adapters

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.networking.BaseResponse
import com.JavaWallet.networking.ManageWalletData
import com.JavaWallet.networking.WithdrawLimitRequest
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.limit_subitem.view.*
import kotlinx.android.synthetic.main.setlimit_item.view.*
import kotlinx.android.synthetic.main.setlimit_item.view.iv_currency
import org.json.JSONArray
import java.util.*

/**
 * Created by user on 11/4/19.
 */

class SetLimit_Adapter(private val walletlist: ArrayList<ManageWalletData>, private val listner: Listner) : RecyclerView.Adapter< SetLimit_Adapter.ViewHolder>() {

    private lateinit var mContext: Context
    var delay: Long = 800 // 1 seconds after user stops typing
    var last_text_edit: Long = 0
    var handler = Handler()
    private var limit_value: Double = 0.0
    private var pstn: Int = 0

    interface Listner {

        fun onClickk(limit_value: String)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.setlimit_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var listdata = walletlist.get(position)
        holder.itemView.tv_crncyname.text = listdata.coinName
        holder.itemView.tv_limitvalue.setText((mContext as BaseActivity).decimalConverterUpto(listdata.userWithdrawLimit, 8))
        holder.itemView.tv_limitcoin.text = listdata.coinSymbol.toUpperCase()

        val rnd = Random()
        val color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
        try{
            if(walletlist[position].coinImage==null){
                holder.itemView.iv_currency.visibility=View.INVISIBLE
                holder.itemView.tv_rounds.visibility=View.VISIBLE
                val bgShape = holder.itemView.tv_rounds.getBackground() as GradientDrawable
                bgShape.setColor(color)
                holder.itemView.tv_rounds.text=walletlist.get(position).coinName.substring(0,1);
            }else{
                holder.itemView.iv_currency.visibility=View.VISIBLE
                holder.itemView.tv_rounds.visibility=View.GONE
                (mContext as  BaseActivity).loadPicture_circle(holder.itemView.iv_currency, JavaWallet.IMAGEBASE_URL + listdata.coinImage)

            }

        }catch (e:Exception){
            e.printStackTrace()
        }
        try {
            val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.CRYPTODATA)
            for (i in 0 until jsonarray.length()) {
                var jsnobj = jsonarray.getJSONObject(i)
                if (listdata.coinSymbol.equals(jsnobj.getString("symbol"))) {
                    holder.itemView.tv_limitamount.text = "" +
                            (mContext as  BaseActivity).decimalConverterUpto(listdata.defaultWithdrawLimit * jsnobj.getString("current_price").toDouble(), 8) + " " + JavaWallet.mPreferenceDataModal.DefaultCurrency
                } else {
                }

            }
        } catch (e: Exception) {
            e.printStackTrace()
            holder.itemView.tv_limitamount.text = "0.00 " + JavaWallet.mPreferenceDataModal.DefaultCurrency
        }

        holder.itemView.iv_refresh.setOnClickListener {
            holder.itemView.tv_limitvalue.setText(listdata.defaultWithdrawLimit.toString())
        }
        holder.itemView.tv_limitvalue.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {

                if (p0!!.isNotEmpty()) {
                    pstn = position
                    limit_value = holder.itemView.tv_limitvalue.text.toString().trim().toDouble()
                    Apihit()
                    last_text_edit = System.currentTimeMillis();
                    handler.postDelayed(input_finish_checker, delay);
                } else {

                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if (p0!!.isNotEmpty()) {
                    pstn = position
                    limit_value = holder.itemView.tv_limitvalue.text.toString().trim().toDouble()
                }
                handler.removeCallbacks(input_finish_checker)

            }

        })
    }

    private fun Apihit() {

        var rqst= WithdrawLimitRequest(walletlist.get(pstn).userCoinId, limit_value)
        val plainText = Gson().toJson(rqst)
        val cryptLib =  CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        (mContext as  BaseActivity).apiServiceWithAuthorization.setWithdrawLimit(JavaWallet.mPreferenceDataModal.JWTToken,cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> (mContext as  BaseActivity).handleError(error); })
    }

    private fun handleResponse(it: BaseResponse?) {

        if (it!!.status) {

        } else {

        }

    }

    private val input_finish_checker = Runnable {
        if (System.currentTimeMillis() > last_text_edit + delay - 500) {
            if (!limit_value.equals("")) {
                Apihit()
            }

        }
    }

    override fun getItemCount(): Int {
        return walletlist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context
        }

        fun bindItems() {

        }
    }
}