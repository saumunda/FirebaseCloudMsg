package com.JavaWallet.ui.activities

import android.app.Activity
import android.app.Dialog
import android.app.PendingIntent
import android.app.ProgressDialog
import android.content.*
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.support.v4.content.LocalBroadcastManager
import android.support.v7.widget.AppCompatEditText
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.LinearLayoutManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.animation.AnimationUtils
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.JavaWallet.*
import com.JavaWallet.Adapters.AddressAdapter
import com.JavaWallet.Adapters.SendlistAdapter
import com.JavaWallet.Utilities.Bytetohex
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.Utilities.PermissionCheck
import com.JavaWallet.networking.*
import com.JavaWallet.ui.fragments.Listener
import com.JavaWallet.ui.fragments.NFCReadFragment

import com.google.gson.Gson

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_send.*
import kotlinx.android.synthetic.main.btcfees_dialog.*
import kotlinx.android.synthetic.main.ethfeesfialog.*
import kotlinx.android.synthetic.main.ethusd_dialog.*
import kotlinx.android.synthetic.main.header_title.*
import org.bitcoinj.core.*
import org.bitcoinj.crypto.TransactionSignature
import org.bitcoinj.params.MainNetParams
import org.bitcoinj.params.TestNet3Params
import org.bitcoinj.script.Script
import org.bitcoinj.script.ScriptBuilder
import org.bitcoinj.wallet.UnreadableWalletException
import org.json.JSONArray
import org.web3j.crypto.Credentials
import org.web3j.crypto.RawTransaction
import org.web3j.crypto.TransactionEncoder
import org.web3j.protocol.Web3j
import org.web3j.protocol.http.HttpService
import org.web3j.utils.Convert
import org.web3j.utils.Numeric
import retrofit2.HttpException
import java.math.BigDecimal
import java.math.BigInteger
import java.text.DecimalFormat
import java.util.*
import kotlin.collections.ArrayList


class Send : BaseActivity(), View.OnClickListener, SendlistAdapter.Listner, PermissionInterface, AddressAdapter.AddresListner, Listener {

    override fun onDialogDisplayed() {
    }

    override fun onDialogDismissed() {
    }


    private lateinit var rawTransaction: RawTransaction
    private var ethTosend: Double = 0.0
    private var amountWeiToken: Double = 0.0
    private var amountWeiEth: BigInteger? = null
    private var selectedpickerValue: Int = 1
    private var final_txnFee: Double = 0.0
    var Erc_nonce: Int = 0
    private lateinit var linearLayoutManager: LinearLayoutManager
    private lateinit var linearLayoutManageraddrs: LinearLayoutManager
    lateinit var walletlist: ArrayList<ManageWalletData>
    lateinit var addresslist: ArrayList<AddressData>
    private lateinit var adpter: SendlistAdapter
    private lateinit var addrs_adpter: AddressAdapter
    lateinit var pCheck: PermissionCheck
    private lateinit var coin_sym: String

    var current_price = ""
    var token_address = ""
    var decimals = ""
    private val QRCODEE: Int = 1
    private val QRCODEE_Dialog: Int = 2
    private val WALLETPIN_SEND: Int = 3
    var isdialog_qr: Boolean = false
    private var gas_price: String = "30000000000"
    private var gas_Limit: Double = 21000.0
    private var list_position: Int = 0
    private lateinit var edt_dialog: AppCompatEditText
    private var crypto_bal: Double = 0.00

    //private var crypto_availablebal: Double = 0.00
    private var autoIncrement = false
    private var autoDecrement = false
    private val REPEAT_DELAY: Long = 50
    private val repeatUpdateHandler = Handler()
    lateinit var applctn: JavaWallet

    var mNfcReadFragment: NFCReadFragment = NFCReadFragment()
    lateinit var mNfcAdapter: NfcAdapter
    var isfiatselected: Boolean = false
    var used_rate: Double = 0.0
    var priority: Int = 1

    var commsionList = ArrayList<CommisionResponseData>()
    //var ContractAddress = "0x5b0Adb5A0f9E8551CB2502A0AD6307faD06121CB"
      var ContractAddress = "0xb061d8806de7a93af7760f1f1499f7faada66496" // java main
    // var ContractAddress = "0xa8f69D25F01285Aa3526F56626C9c08ddC03dD73" // bank test
    var ethCommisionAddress = ""
    var eth_antier_address = ""
    var ethpercentage_fee = 0.0
    var ethmin_fee = 0.0
    var btcCommisionAddress = ""
    var btc_antier_address = ""
    var btcpercentage_fee = 0.0
    var btcmin_fee = 0.0
    var min_fee: Double = 0.0
    var max_fee: Double = 0.0

    var percentage_fee: String = ""
    var admin_address: String = ""
    var wallet_address: String = ""


    private var btcFeetosend: Double = 0.0
    private var isUplAddres = false

    /* var btcCommAddress = "miKvGfH5VPtdjcTbqkemeMJHnzVkMJBH5u"
     var btcCommFee = 2000*/

    // lateinit var contractcommison: Ankit_sol_multiSendOxygen
//   lateinit var contractcommison: Cryptmultisol_sol_multiSendOxygen
    lateinit var contractcommison: Jv
    lateinit var web3j: Web3j
    private var privKey: BigInteger? = null
    private var credentials: Credentials? = null
    var senderaddress = ""

    var errormessage = ""
    private var currentNonce: Int = 0
    var contractTransactionhash = ""

    var feestoSend = 0.0
    private var amounttosend: Double = 0.0
    private var txnFee: Double = 0.0
    private var nonce_btc: Int = 0


    //    var minBTCfees: Long = 37400
    var myvalue = 0
    var myunspentforoutput: Long = 0
    var btctosatoshi = 100000000
    private var outputUsedtomatchValue: Long = 0

    var btcUnspentlist: ArrayList<UnspentResponseLocalData> = ArrayList()
    var jsonutxo = ArrayList<UTXO>()
    var minebalance: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_send)
        try {
            var b: Bundle? = Bundle()
            b = intent.extras
            tv_coinnamee.text = b!!.getString(getString(R.string.coin_name))
            tv_crypto.text = b!!.getString(getString(R.string.coinamount_crypto))
            tv_fiat.text = b!!.getString(getString(R.string.coinamount_fiat))
            coin_sym = b!!.getString(getString(R.string.coin_sym))!!.toLowerCase()
            current_price = b!!.getString(getString(R.string.current_price))!!
            token_address = b!!.getString(getString(R.string.token_address))!!
            decimals = b!!.getString("decimals")!!
            if (current_price.equals("0")) {
                ivdrp.visibility = View.GONE
                rltv_ethusd.isEnabled = false
            } else {
                ivdrp.visibility = View.GONE
                rltv_ethusd.isEnabled = true
            }

            if (coin_sym.equals("upl")) {
                min_fee = b!!.getDouble("min_fee")!!
                max_fee = b!!.getDouble("max_fee")!!
                percentage_fee = b!!.getString("percentage_fee")!!
                admin_address = b!!.getString("admin_address")!!
                wallet_address = b!!.getString("wallet_address")!!
                gasEstimationApi("onCreate")


            } else if (!coin_sym.equals("btc", true)) {
                gasEstimationApi("onCreate")
                rltv_coinfee.isEnabled = true
                iv_edit.visibility = View.VISIBLE
            } else if (coin_sym.equals("btc")) {

                getUnspentBtc()
            }

            getCommisonApi()

            tv_enterin.text = getString(R.string.enteramount) + coin_sym.toUpperCase()
            tv_enter.text = getString(R.string.enterspace) + coin_sym.toUpperCase() + getString(R.string.addressspace)
            edt_addrs.setText(b!!.getString(getString(R.string.coin_address)))
            // edt_addrs.setText("bitcoin:2NGZrVvZG92qGYqzTLjCAewvPZ7JE8S8VxE")
            val rnd = Random()
            val color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))

            try {
                if (b!!.getString(getString(R.string.coin_icon)) == null) {
                    iv_currency.visibility = View.INVISIBLE
                    tv_roundsnd.visibility = View.VISIBLE
                    val bgShape = tv_roundsnd.getBackground() as GradientDrawable
                    bgShape.setColor(color)
                    tv_roundsnd.text = b!!.getString(getString(R.string.coin_name)).substring(0, 1);
                } else {
                    iv_currency.visibility = View.VISIBLE
                    tv_roundsnd.visibility = View.GONE
                    loadPicture_circle(iv_currency, JavaWallet.IMAGEBASE_URL+b!!.getString(getString(R.string.coin_icon)))
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }

            if (isNFC()) {
                mNfcAdapter = NfcAdapter.getDefaultAdapter(mActivity);
            }


        } catch (e: Exception) {

        }

        try {
            val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.CRYPTODATA)
            for (i in 0 until jsonarray.length()) {
                var jsnobj = jsonarray.getJSONObject(i)
                if (coin_sym.equals(jsnobj.getString("symbol"))) {
                    crypto_bal = jsnobj.getString("current_price").toDouble()
                    used_rate = 1 / crypto_bal
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        linearLayoutManager = LinearLayoutManager(this)
        rccyl_choose.layoutManager = linearLayoutManager
        linearLayoutManageraddrs = LinearLayoutManager(this)
        rcycl_oldaddress.layoutManager = linearLayoutManageraddrs

        pCheck = PermissionCheck(this, this)

        edt_addrs.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                if (p0.isNullOrEmpty()) {
                    tv_paste.visibility = View.VISIBLE
                    tv_saveaddress.visibility = View.GONE
                } else {
                    tv_paste.visibility = View.GONE
                    tv_saveaddress.visibility = View.VISIBLE
                    rcycl_oldaddress.visibility = View.GONE
                    if (p0.toString().length == 42) {
                        if (coin_sym.equals("upl")) {
                            isWallletAddressApi()
                        }
                        if (isValidAddress(p0.toString())) {

                        }
                    }
                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

        })

        edtAmount.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                if (p0.isNullOrEmpty() || p0.toString().replace(",", ".").equals(".")) {
                    tv_fiatupdate.text = "0.00 " + JavaWallet.mPreferenceDataModal.DefaultCurrency
                } else {
                    if (!isfiatselected) {

                        tv_fiatupdate.text = decimalConverterUpto(crypto_bal * edtAmount.text.toString().replace(",", ".").toDouble(), 8) + " " + JavaWallet.mPreferenceDataModal.DefaultCurrency

                    } else {
                        tv_fiatupdate.text = decimalConverterUpto(used_rate * edtAmount.text.toString().replace(",", ".").toDouble(), 8) + " " + coin_sym.toUpperCase()
                    }

                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

        })
    }


    private fun getUnspentBtc() {

        if (isInternetConnected()) {
            showLoading()
            apiServiceWithAuthorization.getUnspent(JavaWallet.mPreferenceDataModal.BTC_ADDRESS)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponseUnspent(it) },
                            { error -> handleError(error);hideLoading() })
        } else {
            showDialog(getString(R.string.network_error), false)

        }
    }

    private fun handleResponseUnspent(itmy: UnspentResponseLocal) {

        hideLoading()
        var unResponse = itmy.data.filter { it.confirmations >= 1 }
        btcUnspentlist.addAll(unResponse)

        for (i in 0 until btcUnspentlist.size) {
            var script = Script(btcUnspentlist[i].scriptPubKey.hexToByteArray())
            val coin = Coin.parseCoin((btcUnspentlist[i].amount).toString());
            var hashh = Sha256Hash.wrap(btcUnspentlist[i].txid)

            var utxo = UTXO(hashh, btcUnspentlist[i].vout.toLong(), coin,
                    btcUnspentlist[i].height, false, script, btcUnspentlist[i].address)
            if (btcUnspentlist[i].confirmations >= 1) {
                jsonutxo.add(utxo)
                minebalance = minebalance + btcUnspentlist[i].satoshis
            }

        }
    }

    fun String.hexToByteArray(): ByteArray {
        return ByteArray(this.length / 2) {
            this.substring(it * 2, it * 2 + 2).toInt(16).toByte()
        }
    }

    override fun onResume() {
        super.onResume()

        if (coin_sym.equals(getString(R.string.btc))) {
            // tv_coinfee.text = "Fee: $priority sat/b"
            tv_coinfee.text = getString(R.string.feee) + decimalConverterUpto(JavaWallet.mPreferenceDataModal.BTC_FEES, 8) + " BTC"
        }
        tv_title.text = getString(R.string.titlesend)
        if (isNFC()) {
            lnr_nfc.alpha = 1.0f
            lnr_nfc.isEnabled = true
        } else {
            lnr_nfc.alpha = 0.4f
            lnr_nfc.isEnabled = false
        }
        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
            /* iv_add.setColorFilter(resources.getColor(R.color.white));
             iv_qr.setColorFilter(resources.getColor(R.color.white));
             iv_nfc.setColorFilter(resources.getColor(R.color.white));*/
            iv_phonebook.setColorFilter(resources.getColor(R.color.white));
            iv_dropdown.setColorFilter(resources.getColor(R.color.white));
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
            /* iv_add.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
             iv_qr.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
             iv_nfc.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));*/
            iv_phonebook.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
            iv_dropdown.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
        } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
            /* iv_add.setColorFilter(resources.getColor(R.color.white));
             iv_qr.setColorFilter(resources.getColor(R.color.white));
             iv_nfc.setColorFilter(resources.getColor(R.color.white));*/
            iv_phonebook.setColorFilter(resources.getColor(R.color.white));
            iv_dropdown.setColorFilter(resources.getColor(R.color.white));
        }
        lnr_nfc.setOnClickListener(this)
        iv_currencydropdown.setOnClickListener(this)
        lnr_address.setOnClickListener(this)
        iv_phonebook.setOnClickListener(this)
        iv_dropdown.setOnClickListener(this)
        lnr_qr.setOnClickListener(this)
        iv_back.setOnClickListener(this)
        tv_paste.setOnClickListener(this)
        tv_saveaddress.setOnClickListener(this)
        tv_next.setOnClickListener(this)
        txtAmountPlus.setOnClickListener(this)
        txtAmountMinus.setOnClickListener(this)
        //    rltv_ethusd.setOnClickListener(this)
        txttwentyfive.setOnClickListener(this)
        txtfifty.setOnClickListener(this)
        txtseventyfive.setOnClickListener(this)
        txthundred.setOnClickListener(this)
        rltv_coinfee.setOnClickListener(this)
        if (isInternetConnected()) {
            getWalletList()
            getAddedaddressses()
        } else {
            showDialog(getString(R.string.network_error), false)
        }


        txtAmountPlus.setOnLongClickListener { v ->
            if (v.isPressed) {
                autoIncrement = true
                repeatUpdateHandler.post(AmountRunnable())
                // if set to false, then long clicks will propagate into single-clicks
                // also, and we don't want that.
            }
            false
        }
        txtAmountPlus.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_UP && autoIncrement) {

                autoIncrement = false
            }
            if (event.action == MotionEvent.ACTION_DOWN) {

            }
            false
        }


        txtAmountMinus.setOnLongClickListener { v ->
            if (v.isPressed) {
                autoDecrement = true
                repeatUpdateHandler.post(AmountRunnable())
                // if set to false, then long clicks will propagate into single-clicks
                // also, and we don't want that.
            }
            false
        }
        txtAmountMinus.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_UP && autoDecrement) {

                autoDecrement = false
            }
            if (event.action == MotionEvent.ACTION_DOWN) {


            }
            false
        }

        // ECR_Rawtransaction()


    }

    override fun onPause() {
        super.onPause()
        if (isNFC()) {
            if (mNfcAdapter != null)
                mNfcAdapter.disableForegroundDispatch(mActivity)
        }

    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)

        val tag = intent!!.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
        if (tag != null) {
            try {
                Toast.makeText(this, getString(R.string.nfctag), Toast.LENGTH_SHORT).show()
                val ndef = Ndef.get(tag)
                ndef.connect()
                val ndefMessage = ndef.ndefMessage
                val message = String(ndefMessage.records[0].payload)
                ndef.close()
                edt_addrs.setText(message)
                mNfcReadFragment.dismiss()
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }
    }


    internal inner class AmountRunnable : Runnable {
        override fun run() {
            if (autoIncrement) {
                if (edtAmount.text!!.isNotEmpty()) {
                    incrementAmount()
                    repeatUpdateHandler.postDelayed(AmountRunnable(), REPEAT_DELAY)
                }
            } else if (autoDecrement) {
                if (edtAmount.text!!.isNotEmpty()) {
                    decrementAmount()
                    repeatUpdateHandler.postDelayed(AmountRunnable(), REPEAT_DELAY)
                }
            }

        }
    }

    fun incrementAmount() {

        if (!isfiatselected) {
            val _temp = edtAmount.text.toString().replace(",", ".").toDouble().plus(0.00000001)
            val df2 = DecimalFormat(".########")
            val data = df2.format(_temp)
            edtAmount.setText(data)
        } else {
            val _temp = edtAmount.text.toString().replace(",", ".").toDouble().plus(0.01)
            val df2 = DecimalFormat(".##")
            val data = df2.format(_temp)
            edtAmount.setText(data)
        }


    }

    fun decrementAmount() {
        try {

            if (edtAmount.text.toString().replace(",", ".").toDouble() != .00000000 && edtAmount.text.toString().replace(",", ".").isNotEmpty()) {

                if (!isfiatselected) {
                    val _temp = edtAmount.text.toString().replace(",", ".").toDouble().minus(0.00000001)
                    val df2 = DecimalFormat(".########")
                    val data = df2.format(_temp)
                    edtAmount.setText(data)
                } else {
                    val _temp = edtAmount.text.toString().replace(",", ".").toDouble().minus(0.01)
                    val df2 = DecimalFormat(".##")
                    val data = df2.format(_temp)
                    edtAmount.setText(data)
                }

            } else {
                edtAmount.setText(".00000000")
            }
        } catch (e: Exception) {
        }
    }


    private fun eth_Rawtransaction(it: NonceResponse) {
        try {
            val privKey = JavaWallet.mPreferenceDataModal.ETHPRIVATE_KEY
            // Web3j
            val credentials = Credentials.create(privKey!!.toString(16))
            amountWeiEth = Convert.toWei(ethTosend.toString().replace(",", "."), Convert.Unit.ETHER).toBigInteger()

            //BigInteger nonce, BigInteger gasPrice, BigInteger gasLimit, String to, BigInteger value
            if (coin_sym.equals("upl")) {
                rawTransaction = RawTransaction.createEtherTransaction(BigInteger.valueOf(it.nonce.toLong()),
                        BigInteger.valueOf(JavaWallet.mPreferenceDataModal.GASPRICE.toLong()),
                        BigInteger.valueOf(JavaWallet.mPreferenceDataModal.GASLIMIT.toLong()), admin_address, amountWeiEth)
            } else {
                rawTransaction = RawTransaction.createEtherTransaction(BigInteger.valueOf(it.nonce.toLong()),
                        BigInteger.valueOf(JavaWallet.mPreferenceDataModal.GASPRICE.toLong()),
                        BigInteger.valueOf(JavaWallet.mPreferenceDataModal.GASLIMIT.toLong()), edt_addrs.text.toString(), amountWeiEth)
            }

            val signedMessage = TransactionEncoder.signMessage(rawTransaction, credentials)
            val hexValue = Numeric.toHexString(signedMessage)
            sendCoinApi(it.nonce.toLong(), hexValue.substring(2))
        } catch (e: UnreadableWalletException) {
            e.printStackTrace()
        }

    }

    private fun ERC_Rawtransaction(data_raw: String) {

        try {
            val privKey = JavaWallet.mPreferenceDataModal.ETHPRIVATE_KEY
            // Web3j
            val credentials = Credentials.create(privKey!!.toString(16))
            //BigInteger nonce, BigInteger gasPrice, BigInteger gasLimit, String to,
            //            BigInteger value, String data
            val rawTransaction = RawTransaction.createTransaction(BigInteger.valueOf(Erc_nonce.toLong()),
                    BigInteger.valueOf(JavaWallet.mPreferenceDataModal.GASPRICE.toLong()),
                    BigInteger.valueOf(JavaWallet.mPreferenceDataModal.GASLIMIT.toLong()), token_address, data_raw)
            val signedMessage = TransactionEncoder.signMessage(rawTransaction, credentials)
            val hexValue = Numeric.toHexString(signedMessage)
            sendCoinApi(Erc_nonce.toLong(), hexValue.substring(2))

        } catch (e: UnreadableWalletException) {
            e.printStackTrace()
        }

    }

    private fun showTxnDialog(final_txnFee: Double, commissionFees: Double, Amount: Double) {
        var dialog = Dialog(mActivity)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.logout_dialog)
        val dialog_no = dialog.findViewById<View>(R.id.dialog_no) as TextView
        val dialog_yes = dialog.findViewById<View>(R.id.dialog_yes) as TextView
        val dialog_message = dialog.findViewById<View>(R.id.dialog_message) as TextView

        if (coin_sym.equals("eth")) {
            dialog_message.text = getString(R.string.estimatedincludingGasFee) + " " + decimalConverterUpto(final_txnFee, 8) +
                    " " + coin_sym.toUpperCase() + "\nAmount to be sent: " +
                    decimalConverterUpto(Amount, 8) + " " + coin_sym.toUpperCase() + "\nGas fee: " +
                    decimalConverterUpto(txnFee, 10) + " " + coin_sym.toUpperCase() + "\n JavaWallet Commission: " +
                    decimalConverterUpto(commissionFees, 8) + " " + coin_sym.toUpperCase() + "\n" + getString(R.string.continueuu)
        } else if (coin_sym.equals("btc")) {

            dialog_message.text = getString(R.string.estimatedincludingGasFee) + " " + decimalConverterUpto(final_txnFee, 8) +
                    " " + coin_sym.toUpperCase() + "\nAmount to be sent: " +
                    decimalConverterUpto(Amount, 8) + " " + coin_sym.toUpperCase() + "\nGas fee: " +
                    decimalConverterUpto(JavaWallet.mPreferenceDataModal.BTC_FEES, 10) + " " + coin_sym.toUpperCase() + "\n JavaWallet Commission: " +
                    decimalConverterUpto(commissionFees, 8) + " " + coin_sym.toUpperCase() + "\n" + getString(R.string.continueuu)

        } else if (coin_sym.equals("upl")) {
            if (isUplAddres) {
                dialog_message.text = "Amount to be sent: " +
                        decimalConverterUpto(edtAmount.text.toString().toDouble(), 8) + " " + coin_sym.toUpperCase() + "\n" + getString(R.string.continueuu)
            } else {
                //"Amount to be sent 0.05 upl , with  Eth transaction of ethsend including gas fee gas fee of
                dialog_message.text = "Amount to be sent: " + " " + decimalConverterUpto(edtAmount.text.toString().toDouble(), 8) +
                        " UPL" + "\nWith  Eth transaction of: " +
                        decimalConverterUpto(ethTosend, 8) + " ETH " + "\nWith gas fee: " +
                        decimalConverterUpto(commissionFees, 10) + " ETH " + "\n" + getString(R.string.continueuu)
            }

        } else {
            dialog_message.text = getString(R.string.estimatedGasFee) + decimalConverterUpto(final_txnFee, 8) + getString(R.string.ethCptl) + "\n" + getString(R.string.continueuu)

        }
        dialog_no.setOnClickListener { dialog.dismiss() }
        dialog_yes.setOnClickListener {
            var blnc = tv_crypto.text.toString().substring(0, tv_crypto.text.toString().indexOf(" "))

            if (coin_sym.equals(getString(R.string.btc), true) || coin_sym.equals("eth", true)) {
                if (blnc.replace(",", ".").toDouble() < final_txnFee) {
                    showDialog(getString(R.string.lowbalance), false)
                } else {
                    myvalue = 0
                    outputUsedtomatchValue = 0
                    myunspentforoutput = 0
                    getNonceApi()
                }
            } else if (coin_sym.equals("upl", true)) {
                if (isUplAddres) {
                    if (blnc.replace(",", ".").toDouble() < edtAmount.text.toString().replace(",", ".").toDouble()) {
                        showDialog(getString(R.string.lowbalance), false)
                    } else {
                        uplSendInternal(wallet_address, edt_addrs.text.toString().trim(), edtAmount.text.toString().trim())
                    }
                } else {

                    var ethblncfee = tv_coinfee.text.toString().substring(5, tv_coinfee.text.toString().indexOf("E"))

                    var blnc = JavaWallet.mPreferenceDataModal.ETH_BALANCE.toString()
                    if (blnc.replace(",", ".").toDouble() < ethblncfee.toDouble()) {
                        showDialog(getString(R.string.lowbalance), false)
                    } else {
                        //uplSendInternal(wallet_address, edt_addrs.text.toString().trim(), edtAmount.text.toString().trim())
                        getNonceApi()
                    }
                }


            } else {
                if (selectedpickerValue == 1) {
                    if (blnc.replace(",", ".").toDouble() < edtAmount.text.toString().replace(",", ".").toDouble()) {
                        showDialog(getString(R.string.lowbalance), false)
                    } else {
                        getNonceApi()
                    }
                } else {
                    if (blnc.replace(",", ".").toDouble() < tv_fiatupdate.text.toString().split(" ").get(0).toDouble()) {
                        showDialog(getString(R.string.lowbalance), false)
                    } else {
                        getNonceApi()
                    }
                }

            }

            dialog.dismiss()
        }
        dialog.show()
    }

    override fun onClick(p0: View?) {
        when (p0) {
            iv_currencydropdown -> {
                rcycl_oldaddress.visibility = View.GONE
                if (rccyl_choose.visibility == View.VISIBLE) {
                    rccyl_choose.visibility = View.GONE
                    lnr_data.visibility = View.VISIBLE
                } else {
                    val animFadeIn = AnimationUtils.loadAnimation(applicationContext, R.anim.fade_in)
                    rccyl_choose.startAnimation(animFadeIn)
                    rccyl_choose.visibility = View.VISIBLE
                    lnr_data.visibility = View.GONE
                }
            }
            iv_phonebook -> {
                if (rcycl_oldaddress.visibility == View.VISIBLE) {
                    rcycl_oldaddress.visibility = View.GONE

                } else {
                    /* val animFadeIn = AnimationUtils.loadAnimation(applicationContext, R.anim.fade_in)
                     rcycl_oldaddress.startAnimation(animFadeIn)*/
                    if (addresslist.size > 0) {
                        rcycl_oldaddress.visibility = View.VISIBLE
                    } else {
                        showDialog(getString(R.string.noaddress), false)
                    }

                }
            }
            iv_dropdown -> {
                if (rcycl_oldaddress.visibility == View.VISIBLE) {
                    rcycl_oldaddress.visibility = View.GONE

                } else {
                    if (addresslist.size > 0) {
                        rcycl_oldaddress.visibility = View.VISIBLE
                    } else {
                        showDialog(getString(R.string.noaddress), false)
                    }
                }
            }
            lnr_nfc -> {
                if (isNFC()) {

                    var tagDetected = IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
                    var ndefDetected = IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
                    var techDetected = IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED);
                    val nfcIntentFilter = arrayOf(techDetected, tagDetected, ndefDetected)
                    var pendingIntent = PendingIntent.getActivity(
                            mActivity, 0, Intent(mActivity, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
                    if (mNfcAdapter != null)
                        mNfcAdapter.enableForegroundDispatch(mActivity, pendingIntent, nfcIntentFilter, null);


                    if (mNfcAdapter.isEnabled) {
                        mNfcReadFragment = NFCReadFragment.newInstance("Send")
                        mNfcReadFragment.show(fragmentManager, NFCReadFragment.TAG)
                    } else {
                        showDialog(getString(R.string.enablenfc), false)
                    }
                }
            }

            iv_back -> {
                finish()
            }
            lnr_qr -> {
                isdialog_qr = false
                pCheck.checkPermission(arrayOf(android.Manifest.permission.CAMERA), this)
            }
            lnr_address -> {
                Address_dialog("")
            }
            tv_saveaddress -> {
                Address_dialog(edt_addrs.text.toString().trim())
            }
            tv_paste -> {
                try {
                    val clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clipData = clipboardManager.primaryClip
                    if (!clipData.getItemAt(0).text.toString().equals("")) {
                        edt_addrs.setText(clipData.getItemAt(0).text.toString())
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            tv_next -> {
                if (edtAmount.text.toString().trim().replace(",", ".").toDouble() == 0.0 || edtAmount.text.toString().trim().replace(",", ".").equals("")
                        || edtAmount.text.toString().trim().replace(",", ".").toDouble() < 0.0) {
                    showDialog(getString(R.string.amountsent), false)
                    return
                }
                if (edt_addrs.text.toString().trim().equals("")) {
                    showDialog(getString(R.string.receiveraddress), false)
                    return
                }


                if (coin_sym.equals(getString(R.string.btc))) {
                    if (edtAmount.text.toString().replace(",", ".").toDouble() < 0.00005460) {
                        showDialog(getString(R.string.minamount), false)
                        return
                    } else {
                        var bndl = Bundle()
                        bndl.putBoolean(getString(R.string.isfromSend), true)
                        bndl.putBoolean(getString(R.string.isfromsetting), false)
                        bndl.putBoolean(getString(R.string.isfromTransaction), false)
                        bndl.putBoolean(getString(R.string.isfromImport), false)
                        callActivityforResultData(NewPinAfterImport::class.java, WALLETPIN_SEND, bndl)
                    }

                } else {

                    var bndl = Bundle()
                    bndl.putBoolean(getString(R.string.isfromSend), true)
                    bndl.putBoolean(getString(R.string.isfromsetting), false)
                    bndl.putBoolean(getString(R.string.isfromTransaction), false)
                    bndl.putBoolean(getString(R.string.isfromImport), false)
                    callActivityforResultData(NewPinAfterImport::class.java, WALLETPIN_SEND, bndl)
                }
            }
            txtAmountPlus -> {
                incrementAmount()
            }
            txtAmountMinus -> {
                decrementAmount()
            }
            rltv_ethusd -> {
                val usddialog = Dialog(mActivity)
                usddialog.setCancelable(false)
                usddialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                usddialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                usddialog.setContentView(R.layout.ethusd_dialog)
                usddialog.crncypicker.setMinValue(1)
                usddialog.crncypicker.setMaxValue(2)
                usddialog.crncypicker.setDisplayedValues(arrayOf(coin_sym.toUpperCase(), JavaWallet.mPreferenceDataModal.DefaultCurrency))
                usddialog.dialog_canecl.setOnClickListener {
                    usddialog.dismiss()
                }
                usddialog.dialog_done.setOnClickListener {
                    usddialog.dismiss()
                    selectedpickerValue = usddialog.crncypicker.value
                    setEnterValueView()
                }
                usddialog.show()
            }

            txttwentyfive -> {
                txttwentyfive.alpha = 1.0f
                txtfifty.alpha = 0.5f
                txtseventyfive.alpha = 0.5f
                txthundred.alpha = 0.5f
                if (!isfiatselected) {
                    var blnc = tv_crypto.text.toString().substring(0, tv_crypto.text.toString().indexOf(" "))
                    var bln_per = (blnc.toDouble() * 25) / 100
                    val df2 = DecimalFormat(".########")
                    val data = df2.format(bln_per)
                    edtAmount.setText(data)
                } else {
                    var blnc = tv_fiat.text.toString().substring(0, tv_fiat.text.toString().indexOf(" "))
                    var bln_per = (blnc.toDouble() * 25) / 100
                    val df2 = DecimalFormat(".##")
                    val data = df2.format(bln_per)
                    edtAmount.setText(data)
                }
            }

            txtfifty -> {

                txttwentyfive.alpha = 0.5f
                txtfifty.alpha = 1.0f
                txtseventyfive.alpha = 0.5f
                txthundred.alpha = 0.5f

                if (!isfiatselected) {
                    var blnc = tv_crypto.text.toString().substring(0, tv_crypto.text.toString().indexOf(" "))
                    var bln_per = (blnc.toDouble() * 50) / 100
                    val df2 = DecimalFormat(".########")
                    val data = df2.format(bln_per)
                    edtAmount.setText(data)
                } else {
                    var blnc = tv_fiat.text.toString().substring(0, tv_fiat.text.toString().indexOf(" "))
                    var bln_per = (blnc.toDouble() * 50) / 100
                    val df2 = DecimalFormat(".##")
                    val data = df2.format(bln_per)
                    edtAmount.setText(data)
                }
            }


            txtseventyfive -> {

                txttwentyfive.alpha = 0.5f
                txtfifty.alpha = 0.5f
                txtseventyfive.alpha = 1.0f
                txthundred.alpha = 0.5f

                if (!isfiatselected) {
                    var blnc = tv_crypto.text.toString().substring(0, tv_crypto.text.toString().indexOf(" "))
                    var bln_per = (blnc.toDouble() * 75) / 100
                    val df2 = DecimalFormat(".########")
                    val data = df2.format(bln_per)
                    edtAmount.setText(data)
                } else {
                    var blnc = tv_fiat.text.toString().substring(0, tv_fiat.text.toString().indexOf(" "))
                    var bln_per = (blnc.toDouble() * 75) / 100
                    val df2 = DecimalFormat(".##")
                    val data = df2.format(bln_per)
                    edtAmount.setText(data)
                }
            }


            txthundred -> {

                txttwentyfive.alpha = 0.5f
                txtfifty.alpha = 0.5f
                txtseventyfive.alpha = 0.5f
                txthundred.alpha = 1.0f

                if (!isfiatselected) {
                    var blnc = tv_crypto.text.toString().substring(0, tv_crypto.text.toString().indexOf(" "))
                    var bln_per = (blnc.toDouble() * 100) / 100
                    val df2 = DecimalFormat(".########")
                    val data = df2.format(bln_per)
                    edtAmount.setText(data)
                } else {
                    var blnc = tv_fiat.text.toString().substring(0, tv_fiat.text.toString().indexOf(" "))
                    var bln_per = (blnc.toDouble() * 100) / 100
                    val df2 = DecimalFormat(".##")
                    val data = df2.format(bln_per)
                    edtAmount.setText(data)
                }
            }
            rltv_coinfee -> {
                if (coin_sym.equals(getString(R.string.btc))) {
                    btcFeeDialog()
                } else {
                    ethFeeDialog()
                }
            }


        }


    }

    private fun ethFeeDialog() {
        /* var mBottomSheetDialog = BottomSheetDialog(this!!)
         val sheetView = this!!.layoutInflater.inflate(R.layout.ethfeesfialog, null)
         mBottomSheetDialog.setContentView(sheetView)*/
        var dialog = Dialog(this)
        dialog.setCancelable(true)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.ethfeesfialog)
        val window = dialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        window.setGravity(Gravity.BOTTOM)
        dialog.edt_limit.setText(JavaWallet.mPreferenceDataModal.GASLIMIT.toString())
        var newPrice = (JavaWallet.mPreferenceDataModal.GASPRICE) / 1000000000
        dialog.eth_gasprice.setText(newPrice.toString())
        dialog.tv_set.setOnClickListener {
            if (dialog.eth_gasprice.text.toString().equals("")) {
                showDialog(getString(R.string.gasprice), false)
            } else if (dialog.edt_limit.text.toString().equals("")) {
                showDialog(getString(R.string.gaslimit), false)
            } else {
                var gasFeeMultiplier = 0.000000000000000001
                var newvl = dialog.eth_gasprice.text.toString().replace(",", ".").toDouble() * 1000000000
                var initialValue = newvl * dialog.edt_limit.text.toString().replace(",", ".").toDouble()
                txnFee = initialValue * gasFeeMultiplier
                tv_coinfee.text = getString(R.string.feee) + decimalConverterUpto(txnFee, 10) + getString(R.string.ethCptl)
                // val edtamout = decimalConverterUpto(edtAmount.text.toString().replace(",",".").toDouble(), 10).toDouble()

                if (coin_sym.equals("Eth", true)) {

                    if (selectedpickerValue == 1) {
                        val vl = decimalConverterUpto(txnFee.toString().replace(",", ".").toDouble(), 10)
                        final_txnFee = vl.toString().replace(",", ".").toDouble()
                    } else {
                        val vl = decimalConverterUpto(txnFee.toString().replace(",", ".").toDouble(), 10)
                        final_txnFee = vl.toString().replace(",", ".").toDouble()
                    }
                } else {
                    val vl = decimalConverterUpto(txnFee.toString().replace(",", ".").toDouble(), 10)
                    final_txnFee = vl.toString().replace(",", ".").toDouble()
                }


                //txnFee + edtAmount.text.toString().toDouble()
                JavaWallet.mPreferenceDataModal.GASLIMIT = dialog.edt_limit.text.toString().replace(",", ".").toDouble()
                JavaWallet.mPreferenceDataModal.GASPRICE = dialog.eth_gasprice.text.toString().replace(",", ".").toDouble() * 1000000000
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun btcFeeDialog() {

        var dialog = Dialog(this)
        dialog.setCancelable(true)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.btcfees_dialog)
        val window = dialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        window.setGravity(Gravity.BOTTOM)

        val vl = decimalConverterUpto(JavaWallet.mPreferenceDataModal.BTC_FEES.toString().replace(",", ".").toDouble(), 8)


        dialog.tvfeescancel.setOnClickListener {
            dialog.dismiss()
        }



        dialog.edt_fees.setText("${decimalConverterUpto(vl.replace(",", ".").toDouble(), 8).toString().replace(",", ".")}")

        dialog.tvfeescancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.tvfeesok.setOnClickListener {
            if (dialog.edt_fees.text.toString().equals("")) {
                showDialog(getString(R.string.enterfee), false)
            } else {
                var vl = decimalConverterUpto(dialog.edt_fees.text.toString().toDouble(), 8)
                JavaWallet.mPreferenceDataModal.BTC_FEES = vl.replace(",", ".").toDouble()!!
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                dialog.dismiss()
                try {
                    if (dialog.edt_fees.text.toString().equals("")) {
                        showDialog("Please Enter fee", false)
                    } else {
                        if (dialog.edt_fees.text.toString().toDouble() < 0.00000226) {
                            showDialog("Minimum Fees shoud be 0.00000226", false)
                        } else {
                            var vl = decimalConverterUpto(dialog.edt_fees.text.toString().toDouble(), 8)
                            JavaWallet.mPreferenceDataModal.BTC_FEES = vl.replace(",", ".").toDouble()!!
                            JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                            tv_coinfee.text = "Fee: " + decimalConverterUpto(JavaWallet.mPreferenceDataModal.BTC_FEES, 8) + " BTC"
                            dialog.dismiss()
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    showDialog("something happened wrong, please try again later.", false)
                }


            }

        }
        dialog.tvdefault_fees.setOnClickListener {

            dialog.edt_fees.setText(getString(R.string.btc_fees))
        }

        dialog.show()

    }

    private fun setEnterValueView() {
        if (selectedpickerValue == 1) {
            isfiatselected = false
            tv_enterin.text = getString(R.string.enteramount) + coin_sym.toUpperCase()
            if (!edtAmount.text.toString().replace(",", ".").equals("")) {
                val _temp = edtAmount.text.toString().replace(",", ".").toDouble()
                val df2 = DecimalFormat(".########")
                val data = df2.format(_temp)
                edtAmount.setText(data)
                tv_fiatupdate.text = decimalConverterUpto(crypto_bal * edtAmount.text.toString().replace(",", ".").toDouble(), 8) + " " + JavaWallet.mPreferenceDataModal.DefaultCurrency
            } else {
                tv_fiatupdate.text = "0.00 " + JavaWallet.mPreferenceDataModal.DefaultCurrency
            }


        } else if (selectedpickerValue == 2) {
            isfiatselected = true
            tv_enterin.text = getString(R.string.enteramount) + JavaWallet.mPreferenceDataModal.DefaultCurrency
            if (!edtAmount.text.toString().replace(",", ".").equals("")) {
                val _temp = edtAmount.text.toString().replace(",", ".").toDouble()
                val df2 = DecimalFormat(".##")
                val data = df2.format(_temp)
                edtAmount.setText(data)
                tv_fiatupdate.text = decimalConverterUpto(used_rate * edtAmount.text.toString().replace(",", ".").toDouble(), 8) + " " + coin_sym.toUpperCase()
            } else {
                tv_fiatupdate.text = "0.00 " + coin_sym.toUpperCase()

            }


        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        pCheck.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun permissionAccepted() {
        if (isdialog_qr) {
            callActivityforResult(QrcodeScannerActivity::class.java, QRCODEE_Dialog)
        } else {
            callActivityforResult(QrcodeScannerActivity::class.java, QRCODEE)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == QRCODEE && resultCode == Activity.RESULT_OK) {
            edt_addrs.setText(data?.getStringExtra(ConstantsUtils.QRCODE))
//            if (coin_sym.equals("upl")) {
//                isWallletAddressApi()
//            }

        } else if (requestCode == QRCODEE_Dialog && resultCode == Activity.RESULT_OK) {
            edt_dialog.setText(data?.getStringExtra(ConstantsUtils.QRCODE))
//            if (coin_sym.equals("upl")) {
//                isWallletAddressApi()
//            }
        } else if (requestCode == WALLETPIN_SEND && resultCode == Activity.RESULT_OK) {
            if (coin_sym.equals(getString(R.string.btc))) {
                //  gasEstimationApi("onActivity")

                amounttosend = edtAmount.text.toString().toDouble()
                var commison_fees = amounttosend * (btcpercentage_fee / 100)
                if (decimalConverterUpto(commison_fees, 8) > btcmin_fee.toString()) {
                    feestoSend = commison_fees
                } else {
                    feestoSend = btcmin_fee
                }

                var btcfee = JavaWallet.mPreferenceDataModal.BTC_FEES
                showTxnDialog(btcfee + edtAmount.text.toString().replace(",", ".").toDouble(), feestoSend, edtAmount.text.toString().toDouble())


            } else if (coin_sym.equals("eth")) {
                if (selectedpickerValue == 1) {
                    amounttosend = edtAmount.text.toString().toDouble()
                    var commison_fees = amounttosend * (ethpercentage_fee / 100)
                    if (decimalConverterUpto(commison_fees, 8) > ethmin_fee.toString()) {
                        feestoSend = commison_fees
                    } else {
                        feestoSend = ethmin_fee
                    }

                    showTxnDialog(final_txnFee + edtAmount.text.toString().toDouble(), feestoSend, edtAmount.text.toString().toDouble())
                } else {


                    amounttosend = tv_fiatupdate.text.toString().split(" ").get(0).toDouble()
                    var commison_fees = (amounttosend * ethpercentage_fee) / 100
                    if (decimalConverterUpto(commison_fees, 12) > ethmin_fee.toString()) {
                        feestoSend = commison_fees
                    } else {
                        feestoSend = ethmin_fee
                    }
                    showTxnDialog(final_txnFee + edtAmount.text.toString().toDouble(), feestoSend, tv_fiatupdate.text.toString().split(" ").get(0).toDouble())
                }
            } else if (coin_sym.equals("upl")) {

                if (isUplAddres) {
                    showTxnDialog(0.0, 0.0, 0.0)
                } else {

                    var ethTosendPercentage = (edtAmount.text.toString().toDouble() / 100) * percentage_fee.toDouble()
                    if (ethTosendPercentage > max_fee) {
                        ethTosend = max_fee
                    } else if (ethTosendPercentage < min_fee) {
                        ethTosend = min_fee
                    } else {
                        ethTosend = ethTosendPercentage
                    }

                    //"Amount to be sent 0.05 upl , with  Eth transaction of ethsend including gas fee gas fee of

                    showTxnDialog(0.0, final_txnFee, 0.0)
                }


            } else {
                showTxnDialog(final_txnFee, 0.0, 0.0)
            }

        }
    }

    private fun isWallletAddressApi() {
        showLoading()
        var rqst = IsUplWalletRequest(token_address, edt_addrs.text.toString().trim())
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.upliswalletaddress(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleErrorisUpl(error);hideLoading() })

    }

    private fun handleErrorisUpl(error: Throwable?) {

        when (error) {
            is HttpException -> {
                when {

                    error.code() == 400 -> {
                        val responseBody = error.response().errorBody()?.string()
                        var message = Gson().fromJson<BaseResponseisUpl>(responseBody, BaseResponseisUpl::class.java)
                        //  showToast(message.message)
                        isUplAddres = false
                        rltv_coinfee.isEnabled = true
                        var gasFeeMultiplier = 0.000000000000000001
                        var newvl = JavaWallet.mPreferenceDataModal.GASPRICE
                        var initialValue = newvl * JavaWallet.mPreferenceDataModal.GASLIMIT.toDouble()
                        var txnFee = initialValue * gasFeeMultiplier
                        tv_coinfee.text = getString(R.string.feee) + decimalConverterUpto(txnFee, 10) + "ETH"

                    }
                    else -> {

                        val responseBody = error.response().errorBody()?.string()
                        var message = Gson().fromJson<BaseResponseisUpl>(responseBody, BaseResponseisUpl::class.java)
                        showToast(message.message)


                    }

                }
            }
        }
    }


    private fun uplSendInternal(fromAddress: String, to: String, amount: String) {

        showLoading()
        // var rqst = IsUplWalletRequest(token_address, edt_addrs.text.toString().trim())
        var rqst = sendUplWalletRequest(fromAddress, to, amount)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.uplSend(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }

    private fun uplSendouter(fromAddress: String, to: String, amount: String) {

        showLoading()
        // var rqst = IsUplWalletRequest(token_address, edt_addrs.text.toString().trim())
        var rqst = sendUplWalletRequest(fromAddress, to, amount)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.uplSendouterwithdraw(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }

    override fun onAddress_Click(addresslist: AddressData) {
        rcycl_oldaddress.visibility = View.GONE
        edt_addrs.setText(addresslist.payeeAddress)
    }

    override fun ondelete_Click(addresslist: AddressData, pstn: Int) {
        var dialog = Dialog(mActivity)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.logout_dialog)
        val dialog_no = dialog.findViewById<View>(R.id.dialog_no) as TextView
        val dialog_yes = dialog.findViewById<View>(R.id.dialog_yes) as TextView
        val dialog_message = dialog.findViewById<View>(R.id.dialog_message) as TextView
        dialog_message.text = getString(R.string.deleteaddres)
        dialog_no.setOnClickListener { dialog.dismiss() }
        dialog_yes.setOnClickListener {
            deleteAdddress(addresslist.payeeId, pstn)
            dialog.dismiss()
        }
        dialog.show()
    }


    override fun onCoin_Click(walletlist: ManageWalletData) {

        tv_coinnamee.text = walletlist.coinName
        edtAmount.setText("0.00000000")
        tv_crypto.text = decimalConverterUpto(walletlist.balance, 8) + " " + walletlist.coinSymbol.toUpperCase()
        val rnd = Random()
        val color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
        try {
            if (walletlist.coinImage == null) {
                iv_currency.visibility = View.INVISIBLE
                tv_roundsnd.visibility = View.VISIBLE
                val bgShape = tv_roundsnd.getBackground() as GradientDrawable
                bgShape.setColor(color)
                tv_roundsnd.text = walletlist.coinName.substring(0, 1);
            } else {
                iv_currency.visibility = View.VISIBLE
                tv_roundsnd.visibility = View.GONE
                loadPicture_circle(iv_currency, JavaWallet.IMAGEBASE_URL + walletlist.coinImage)
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }


        coin_sym = walletlist.coinSymbol
        tv_enter.text = getString(R.string.enterspace) + walletlist.coinSymbol.toUpperCase() + getString(R.string.addressspace)
        tv_enterin.text = getString(R.string.enteramount) + coin_sym.toUpperCase()

        if (coin_sym.equals(getString(R.string.btc))) {
            tv_coinfee.text = getString(R.string.feee) + decimalConverterUpto(JavaWallet.mPreferenceDataModal.BTC_FEES, 8) + " BTC"
        } else {

            var gasFeeMultiplier = 0.000000000000000001
            var newvl = JavaWallet.mPreferenceDataModal.GASPRICE
            var initialValue = newvl * JavaWallet.mPreferenceDataModal.GASLIMIT.toDouble()
            var txnFee = initialValue * gasFeeMultiplier
            tv_coinfee.text = getString(R.string.feee) + decimalConverterUpto(txnFee, 10) + "ETH"

        }
        try {
            val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.CRYPTODATA)
            for (i in 0 until jsonarray.length()) {
                var jsnobj = jsonarray.getJSONObject(i)
                if (walletlist.coinSymbol.equals(jsnobj.getString("symbol"))) {
                    crypto_bal = jsnobj.getString("current_price").toDouble()
                    used_rate = 1 / crypto_bal
                    tv_fiat.text = decimalConverterUpto(((walletlist.balance) * (jsnobj.getString("current_price").toDouble())), 2) +
                            " " + walletlist.currencyCode
                    current_price = jsnobj.getString("current_price")
                    break
                } else {
                    current_price = "0"
                    //  tv_fiat.text = "0.00 " + walletlist.currencyCode
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            tv_fiat.text = "0.00 " + walletlist.currencyCode
        }

        if (current_price.equals("0")) {
            ivdrp.visibility = View.GONE
            rltv_ethusd.isEnabled = false
        } else {
            ivdrp.visibility = View.GONE
            rltv_ethusd.isEnabled = true
        }

        rccyl_choose.visibility = View.GONE
        lnr_data.visibility = View.VISIBLE

        setEnterValueView()
        edt_addrs.setText("")
        getAddedaddressses()
    }


    private fun Address_dialog(addrs: String) {
        var dialog = Dialog(this)
        dialog.setCancelable(true)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.address_dialog)
        val tv_save = dialog.findViewById<View>(R.id.tv_save) as AppCompatTextView
        val iv_cross = dialog.findViewById<View>(R.id.iv_cross) as AppCompatImageView
        val iv_qrcode = dialog.findViewById<View>(R.id.iv_qrcode) as AppCompatImageView
        val tv_entere = dialog.findViewById<View>(R.id.tv_entere) as AppCompatTextView
        val edt_label = dialog.findViewById<View>(R.id.edt_label) as AppCompatEditText
        val edt_coinaddrs = dialog.findViewById<View>(R.id.edt_coinaddrs) as AppCompatEditText
        edt_coinaddrs.setText(addrs)
        edt_dialog = edt_coinaddrs
        tv_entere.text = getString(R.string.enterspace) + coin_sym.toUpperCase() + getString(R.string.addressspace)
        tv_save.setOnClickListener {
            if (edt_label.text.toString().trim().equals("") || edt_coinaddrs.text.toString().trim().equals("")) {
                showDialog(getString(R.string.enterabovefields), false)
            } else {
                dialog.dismiss()
                addAddressApi(edt_label.text.toString().trim(), edt_coinaddrs.text.toString().trim())
            }

        }
        iv_qrcode.setOnClickListener {
            isdialog_qr = true
            pCheck.checkPermission(arrayOf(android.Manifest.permission.CAMERA), this)

        }
        iv_cross.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun addAddressApi(label: String, address: String) {

        var rqst = AddpayeeRequest(label, address, coin_sym)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.addAddres(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); })
    }

    private fun sendCoinApi(nonce: Long, tx_raw: String) {
        showLoading()
        var rqst: sendCoinRequest
        if (coin_sym.equals(getString(R.string.btc))) {
            if (selectedpickerValue == 1) {
                rqst = sendCoinRequest(nonce, tx_raw, JavaWallet.mPreferenceDataModal.BTC_ADDRESS,
                        edt_addrs.text.toString().trim(), edtAmount.text.toString().replace(",", ".").trim(),
                        JavaWallet.mPreferenceDataModal.BTC_FEES, 0.0, "", priority,false)
            } else {
                rqst = sendCoinRequest(nonce, tx_raw, JavaWallet.mPreferenceDataModal.BTC_ADDRESS,
                        edt_addrs.text.toString().trim(), tv_fiatupdate.text.toString().split(" ").get(0).toString().trim(),
                        JavaWallet.mPreferenceDataModal.BTC_FEES, 0.0, "", priority,false)
            }
        } else {
            if (coin_sym.equals("upl")) {
                rqst = sendCoinRequest(nonce, tx_raw, JavaWallet.mPreferenceDataModal.COIN_ADDRESS,
                        admin_address, ethTosend.toString().replace(",", ".").trim(),
                        JavaWallet.mPreferenceDataModal.GASLIMIT, JavaWallet.mPreferenceDataModal.GASPRICE, "", 0,true)
            } else {
                if (selectedpickerValue == 1) {
                    rqst = sendCoinRequest(nonce, tx_raw, JavaWallet.mPreferenceDataModal.COIN_ADDRESS,
                            edt_addrs.text.toString().trim(), edtAmount.text.toString().replace(",", ".").trim(),
                            JavaWallet.mPreferenceDataModal.GASLIMIT, JavaWallet.mPreferenceDataModal.GASPRICE, "", 0,false)
                } else {
                    rqst = sendCoinRequest(nonce, tx_raw, JavaWallet.mPreferenceDataModal.COIN_ADDRESS,
                            edt_addrs.text.toString().trim(), tv_fiatupdate.text.toString().split(" ").get(0).toString().trim(),
                            JavaWallet.mPreferenceDataModal.GASLIMIT, JavaWallet.mPreferenceDataModal.GASPRICE, "", 0,false)
                }
            }
        }

        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        if (coin_sym.equals("upl")) {
            apiServiceWithAuthorization.sendCoin(JavaWallet.mPreferenceDataModal.JWTToken, "eth", cipherText)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponse(it) },
                            { error -> handleErrorsendcoin(error);hideLoading() })
        } else {
            apiServiceWithAuthorization.sendCoin(JavaWallet.mPreferenceDataModal.JWTToken, coin_sym, cipherText)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponse(it) },
                            { error -> handleErrorsendcoin(error);hideLoading() })
        }


    }

    private fun handleErrorsendcoin(error: Throwable?) {
        when (error) {
            is HttpException -> {
                when {
                    error.code() == 400 -> {
                        val responseBody = error.response().errorBody()?.string()
                        var message = Gson().fromJson<BaseResponse>(responseBody, BaseResponse::class.java)
                        showDialog(message.message, false)

                    }

                }
            }
        }
    }

    private fun deleteAdddress(payeeId: Int, pstn: Int) {
        list_position = pstn
        var rqst = RemoveuserpayeeRequest(payeeId)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.removeAddreses(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); })

    }

    private fun getCommisonApi() {
        apiServiceWithAuthorization.getCommissiondetail(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })

    }

    lateinit var rqst: GasEstimateRequest
    private fun gasEstimationApi(type: String) {
        showLoading()
        if (type.equals("onCreate")) {
            rqst = GasEstimateRequest(JavaWallet.mPreferenceDataModal.COIN_ADDRESS, "0.001")
        } else {
            rqst = GasEstimateRequest(edt_addrs.text.toString().trim(), edtAmount.text.toString().replace(",", ".").trim())
        }

        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.gasEstimation(JavaWallet.mPreferenceDataModal.JWTToken, coin_sym, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })
    }

    private fun getNonceApi() {
        showLoading()
              if (coin_sym.equals("upl")) {
                  var rqst = GetNonceRequest(edtAmount.text.toString().replace(",", ".").trim(),true)
                  val plainText = Gson().toJson(rqst)
                  val cryptLib = CryptLib()
                  val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

                  apiServiceWithAuthorization.getNonce(JavaWallet.mPreferenceDataModal.JWTToken, "eth", cipherText)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponse(it) },
                            { error -> handleErrornonce(error);hideLoading() })
        } else {
                  var rqst = GetNonceRequest(edtAmount.text.toString().replace(",", ".").trim(),false)
                  val plainText = Gson().toJson(rqst)
                  val cryptLib = CryptLib()
                  val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

                  apiServiceWithAuthorization.getNonce(JavaWallet.mPreferenceDataModal.JWTToken, coin_sym, cipherText)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponse(it) },
                            { error -> handleErrornonce(error);hideLoading() })
        }

    }

    private fun handleErrornonce(error: Throwable?) {
        when (error) {
            is HttpException -> {
                when {
                    error.code() == 400 -> {
                        val responseBody = error.response().errorBody()?.string()
                        var message = Gson().fromJson<NonceErrorResponse>(responseBody, NonceErrorResponse::class.java)
                        showDialog(message.message, false)
                    }
                    else -> {
                        val responseBody = error.response().errorBody()?.string()
                        var message = Gson().fromJson<NonceErrorResponse>(responseBody, NonceErrorResponse::class.java)
                        showDialog(message.message, false)
                    }
                }
            }
        }
    }

    private fun getAddedaddressses() {

        var rqst = GetuserpayeeRequest(coin_sym)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.getAddreses(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); })

    }

    private fun getWalletList() {

        apiServiceWithAuthorization.managewallet(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); })
    }

    private fun handleResponse(it: Any?) {
        when (it) {

            is BaseResponseisUpl -> {
                hideLoading()

                if (it.status) {
                    if (it.message.equals("To address is our App wallet address.")) {
                        isUplAddres = true
                        rltv_coinfee.isEnabled = false
                        tv_coinfee.text = "0.00 ETH"
                    } else {
                        isUplAddres = false
                    }
                }

            }
            is BaseResponseUplSend -> {
                hideLoading()
                if (it.status) {
                    showDialog(it.message, true)
                } else {
                    showDialog(it.message, false)
                }

            }

            is BaseResponseUplSendOuter -> {
                hideLoading()
                if (it.status) {
                    showDialog(it.message, true)
                } else {
                    showDialog(it.message, false)
                }

            }


            is ManageWalletResponse -> {

                if (it.status) {
                    walletlist = it.data
                    adpter = SendlistAdapter(walletlist, this)
                    rccyl_choose.adapter = adpter
                }
            }
            is BaseResponse -> {
                if (it.status) {
                    getAddedaddressses()
                } else {
                    showDialog(it.message, false)
                }
            }

            is BaseResponsenew -> {
                if (it.status) {
                    addresslist.removeAt(list_position)
                    addrs_adpter.notifyDataSetChanged()
                    rcycl_oldaddress.visibility = View.GONE
                }
            }

            is AddressResponse -> {
                if (it.status) {
                    addresslist = it.data
                    addrs_adpter = AddressAdapter(addresslist, this)
                    rcycl_oldaddress.adapter = addrs_adpter
                }
            }

            is GasResponse -> {
                hideLoading()
                if (it.status) {
                    gas_price = it.gasGweiPrice
                    gas_Limit = it.gasEstimate.toDouble()

                    JavaWallet.mPreferenceDataModal.GASLIMIT = gas_Limit
                    JavaWallet.mPreferenceDataModal.GASPRICE = gas_price.toDouble()
                    JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)

                    var gasFeeMultiplier = 0.000000000000000001
                    var initialValue = gas_price.toDouble() * gas_Limit
                    txnFee = initialValue * gasFeeMultiplier
                    //var final_txnFee = txnFee + edtAmount.text.toString().toDouble()
                    if (coin_sym.equals(getString(R.string.btc), true)) {
                        /*    if (selectedpickerValue == 1) {
                            // final_txnFee = JavaWallet.mPreferenceDataModal.BTC_FEES + edtAmount.text.toString().replace(",", ".").toDouble()
                          */
                        amounttosend = edtAmount.text.toString().toDouble()
                        var commison_fees = decimalConverterUpto((amounttosend * (btcpercentage_fee / 100)), 12)
                        if (decimalConverterUpto(commison_fees.toDouble(), 12) > btcmin_fee.toString()) {
                            feestoSend = commison_fees.toDouble()
                        } else {
                            feestoSend = btcmin_fee
                        }

                        showTxnDialog(amounttosend + feestoSend, feestoSend, amounttosend)


                    } else {
                        if (coin_sym.equals("upl")) {
                            rltv_coinfee.isEnabled = false
                            tv_coinfee.setText("0.00 ETH")
                            final_txnFee = txnFee
                        } else {
                            rltv_coinfee.isEnabled = true
                            tv_coinfee.text = getString(R.string.feee) + decimalConverterUpto(txnFee, 10) + getString(R.string.ethCptl)
                            final_txnFee = txnFee
                        }

                    }

                } else {
                    if (it.gasEstimate == 0) {
                        JavaWallet.mPreferenceDataModal.GASLIMIT = gas_Limit
                        JavaWallet.mPreferenceDataModal.GASPRICE = gas_price.toDouble()
                        JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                        var gasFeeMultiplier = 0.000000000000000001
                        var initialValue = gas_price.toDouble() * gas_Limit
                        var txnFee = initialValue * gasFeeMultiplier


                        if (coin_sym.equals("upl")) {
                            rltv_coinfee.isEnabled = false
                            tv_coinfee.setText("0.00 ETH")
                            final_txnFee = txnFee
                        } else {
                            rltv_coinfee.isEnabled = true
                            tv_coinfee.text = getString(R.string.feee) + decimalConverterUpto(txnFee, 10) + getString(R.string.ethCptl)
                            final_txnFee = txnFee
                        }
                    } else {
                        showDialog(getString(R.string.checkaddress), false)
                    }
                }
            }
            is NonceResponse -> {
                hideLoading()
                nonce_btc = it.nonce
                if (it.status) {
                    currentNonce = it.nonce
                    if (it.rawtxRequired.equals("yes")) {
                        if (coin_sym.equals(getString(R.string.btc), true)) {
//                            btc_Rawtransaction()
                            getFeesAndUnspent()
                        } else if (coin_sym.equals("eth", true)) {
                            // eth_Rawtransaction(it)
                            Commision(edt_addrs.text.toString()).execute()
                        } else if (coin_sym.equals("upl", true)) {
                            eth_Rawtransaction(it)

                        } else {
                            getRawDataERC(it)
                        }
                    } else {
                        sendCoinApi(it.nonce.toLong(), "")
                    }
                }
            }
            is SendBtcResponse -> {
                hideLoading()
                if (it.status) {
                    showDialog(it.message, true)
                } else {
                    showDialog(it.message, false)
                }
            }
            is SendResponse -> {
                hideLoading()

                if (it.status) {

                    if (coin_sym.equals("upl")) {
                        uplSendouter(wallet_address, edt_addrs.text.toString().trim(), edtAmount.text.toString().trim())
                    } else {
                        showDialog(it.message, true)
                    }


                } else {
                    showDialog(it.message, false)
                }


            }
            is ErcDataResponse -> {
                hideLoading()
                if (it.status) {
                    ERC_Rawtransaction(it.data)
                }

            }

            is CommisionResponse -> {
                commsionList = it.data
                for (i in 0 until commsionList.size) {
                    if (commsionList[i].coinSymbol.equals("btc")) {
                        btcCommisionAddress = commsionList[i].address
                        btcmin_fee = commsionList[i].minFee
                        btcpercentage_fee = commsionList[i].percentageFee
                    } else if (commsionList[i].coinSymbol.equals("eth")) {
                        ethCommisionAddress = commsionList[i].address
                        ethmin_fee = commsionList[i].minFee
                        ethpercentage_fee = commsionList[i].percentageFee
                    }
                }
                /* if (!coin_sym.equals("btc")) {
                     gasEstimationApi("onCreate")
                 }*/
            }

            is sendContractResponse -> {
                hideLoading()
                showDialog(it.message, true)
            }


        }

    }

    lateinit var keyk: ECKey
    lateinit var tx: Transaction
    lateinit var addressmine: Address
    lateinit var commision_address: Address
    lateinit var address2: Address
    lateinit var scriptPubKey: Script

    private fun getFeesAndUnspent() {

        try {

            showLoading()
            if (JavaWallet.is_MainNet) {
                org.bitcoinj.core.Context.getOrCreate(MainNetParams.get());
                val dumpedPrivateKey = DumpedPrivateKey.fromBase58(MainNetParams.get(), JavaWallet.mPreferenceDataModal.PRIVATE_KEYBTC);
                keyk = dumpedPrivateKey.getKey();
                //String to an address
                address2 = Address.fromString(MainNetParams.get(), edt_addrs.text.toString().trim());
                addressmine = Address.fromString(MainNetParams.get(), JavaWallet.mPreferenceDataModal.BTC_ADDRESS);
                commision_address = Address.fromString(MainNetParams.get(), btcCommisionAddress);
                tx = Transaction(MainNetParams.get());
            } else {
                org.bitcoinj.core.Context.getOrCreate(TestNet3Params.get());
                val dumpedPrivateKey = DumpedPrivateKey.fromBase58(TestNet3Params.get(), JavaWallet.mPreferenceDataModal.PRIVATE_KEYBTC);
                keyk = dumpedPrivateKey.getKey();
                //String to an address
                address2 = Address.fromString(TestNet3Params.get(), edt_addrs.text.toString().trim());
                addressmine = Address.fromString(TestNet3Params.get(), JavaWallet.mPreferenceDataModal.BTC_ADDRESS);
                commision_address = Address.fromString(TestNet3Params.get(), btcCommisionAddress);
                tx = Transaction(TestNet3Params.get());
            }

            //value is a sum of all inputs, fee is 4013
            var btcfees = (JavaWallet.mPreferenceDataModal.BTC_FEES * btctosatoshi).toLong()
            var amount = (edtAmount.text.toString().toDouble() * btctosatoshi).toLong()
            var btc_commisionamount = (feestoSend.toDouble() * btctosatoshi).toLong()
            var amounttobesentFromunspent = amount + btcfees + btc_commisionamount
            if (minebalance >= amounttobesentFromunspent) {
                if (btcUnspentlist[myvalue].satoshis.toLong() == amounttobesentFromunspent) {
                    tx.addOutput(Coin.valueOf(amount), address2);
                    tx.addOutput(Coin.valueOf(btc_commisionamount), commision_address)
                } else if (btcUnspentlist[myvalue].satoshis.toLong() > amounttobesentFromunspent) {
                    tx.addOutput(Coin.valueOf(amount), address2);
                    tx.addOutput(Coin.valueOf(btcUnspentlist[myvalue].satoshis.toLong() - (amount + btcfees)), addressmine);
                    tx.addOutput(Coin.valueOf(btc_commisionamount), commision_address)
                } else if (btcUnspentlist[myvalue].satoshis.toLong() < amounttobesentFromunspent) {
                    txCaculation(tx, amounttobesentFromunspent, btcUnspentlist[myvalue].satoshis.toLong(), address2, addressmine,
                            btcUnspentlist, amount, btc_commisionamount, commision_address)
                }
                for (utxo in jsonutxo) {
                    if (amounttobesentFromunspent > outputUsedtomatchValue) {
                        if (JavaWallet.is_MainNet) {
                            val outPoint = TransactionOutPoint(MainNetParams.get(), utxo.index, utxo.hash)
                            tx.addSignedInput(outPoint, utxo.getScript(), keyk, Transaction.SigHash.ALL, true)
                            outputUsedtomatchValue = outputUsedtomatchValue + utxo.value.value
                        } else {
                            val outPoint = TransactionOutPoint(TestNet3Params.get(), utxo.index, utxo.hash)
                            tx.addSignedInput(outPoint, utxo.getScript(), keyk, Transaction.SigHash.ALL, true)
                            outputUsedtomatchValue = outputUsedtomatchValue + utxo.value.value
                        }

                    }

                }

                for (i in 0 until tx.inputs.size) {
                    val transactionInput: TransactionInput = tx.getInput(i.toLong())
                    val addressFromUtxo: String = jsonutxo[i].getAddress()
                    if (JavaWallet.is_MainNet) {
                        scriptPubKey = ScriptBuilder.createOutputScript(Address.fromString(MainNetParams.get(), jsonutxo[i].getAddress()))
                    } else {
                        scriptPubKey = ScriptBuilder.createOutputScript(Address.fromString(TestNet3Params.get(), jsonutxo[i].getAddress()))
                    }

                    val hash: Sha256Hash = tx.hashForSignature(i, scriptPubKey, Transaction.SigHash.ALL, false)
                    val ecSig = keyk.sign(hash)
                    val txSig = TransactionSignature(ecSig, Transaction.SigHash.ALL, false)
                    transactionInput.scriptSig = ScriptBuilder.createInputScript(txSig, keyk)
                }
                tx.getConfidence().setSource(TransactionConfidence.Source.SELF);
                tx.setPurpose(Transaction.Purpose.USER_PAYMENT);
                var rawtrnsactn = Bytetohex.ByteArrayToHexString(tx.bitcoinSerialize())
                System.out.println(rawtrnsactn);
                hideLoading()
                sendCoinApi(nonce_btc.toLong(), rawtrnsactn)


            } else {
                hideLoading()
                showDialog("Insufficient fund", false)
                System.out.println("Insufficient fund");
            }
        } catch (e: Exception) {
            hideLoading()
            showDialog("listError " + e.message.toString(), false)
        }

    }


    private fun txCaculation(tx: Transaction, amounttobesentFromunspent: Long, myUnspentBalance: Long, addresSend: Address,
                             addressmine: Address, outputjson: ArrayList<UnspentResponseLocalData>, amount: Long, commision_amount: Long,
                             commision_addresSend: Address) {

        if (myUnspentBalance == amounttobesentFromunspent) {
            tx.addOutput(Coin.valueOf(amount), addresSend);
            tx.addOutput(Coin.valueOf(commision_amount), commision_addresSend);

        } else if (myUnspentBalance > amounttobesentFromunspent) {
            tx.addOutput(Coin.valueOf(amount), addresSend);
            tx.addOutput(Coin.valueOf(myUnspentBalance - (amounttobesentFromunspent)), addressmine);
            tx.addOutput(Coin.valueOf(commision_amount), commision_addresSend);
        } else if (myUnspentBalance < amounttobesentFromunspent) {
            myunspentforoutput = myUnspentBalance
            if (myunspentforoutput == amounttobesentFromunspent) {
                tx.addOutput(Coin.valueOf(amount), addresSend);
                tx.addOutput(Coin.valueOf(commision_amount), commision_addresSend);
            } else if (myunspentforoutput > amounttobesentFromunspent) {
                tx.addOutput(Coin.valueOf(amount), addresSend);
                tx.addOutput(Coin.valueOf(myunspentforoutput - (amounttobesentFromunspent)), addressmine);
                tx.addOutput(Coin.valueOf(commision_amount), commision_addresSend);
            } else if (myunspentforoutput < amounttobesentFromunspent) {
                myvalue++
                myunspentforoutput = myunspentforoutput + outputjson[myvalue].satoshis.toLong()
                txCaculation(tx, amounttobesentFromunspent, myunspentforoutput, addresSend, addressmine, outputjson, amount, commision_amount, commision_addresSend)
            }
        }
    }

    private fun getRawDataERC(it: NonceResponse) {

        Erc_nonce = it.nonce
        if (selectedpickerValue == 1) {
            amountWeiToken = edtAmount.text.toString().replace(",", ".").toDouble() * decimals.toDouble()
        } else {
            amountWeiToken = tv_fiatupdate.text.toString().split(" ").get(0).toDouble() * decimals.toDouble()
        }
        if (edtAmount.text.toString().replace(",", ".").contains(".")) {
            var number = edtAmount.text.toString().replace(",", ".")
            number = number.substring(number.indexOf(".")).substring(1)
            if (number.length > decimals.length) {
                showDialog(getString(R.string.decimalsvaluemore) + decimals, false)
            } else {
                showLoading()
                var rqst = GetERCDataRequest(JavaWallet.mPreferenceDataModal.COIN_ADDRESS, edt_addrs.text.toString().trim(),
                        coin_sym.toLowerCase(), BigDecimal(amountWeiToken).toBigInteger().toString())
                val plainText = Gson().toJson(rqst)
                val cryptLib = CryptLib()
                val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

                apiServiceWithAuthorization.getERCDATA(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe({ println(it);handleResponse(it) },
                                { error -> handleError(error); hideLoading() })

            }

        } else {
            showLoading()
            var rqst = GetERCDataRequest(JavaWallet.mPreferenceDataModal.COIN_ADDRESS, edt_addrs.text.toString().trim(),
                    coin_sym.toLowerCase(), BigDecimal(amountWeiToken).toBigInteger().toString())
            val plainText = Gson().toJson(rqst)
            val cryptLib = CryptLib()
            val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
            apiServiceWithAuthorization.getERCDATA(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponse(it) },
                            { error -> handleError(error); hideLoading() })
        }


    }


    override fun onDestroy() {
        super.onDestroy()
        JavaWallet.mPreferenceDataModal.BTC_FEES = getString(R.string.btc_fees).toDouble()
        JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)

    }


    private var hitapi = false

    private inner class Commision(address: String) : AsyncTask<String, String, String>() {


        init {
            senderaddress = address
        }

        override fun doInBackground(vararg urls: String): String? {
            showLoading()
            hitapi = true
            try {
                //  web3j = Web3j.build(HttpService("https://mainnet.infura.io/v3/af08f92cb0064554a28996fc361619e7"))
                //main
                  web3j = Web3j.build(HttpService("https://mainnet.infura.io/v3/ec3e001e25614013b9e1b6ffec3d61b1"))


              // web3j = Web3j.build(HttpService("https://ropsten.infura.io/v3/805096ce0ba141b797b939635f778424"))
                //java testantech8 infura
                //web3j = Web3j.build(HttpService("https://mainnet.infura.io/v3/43ebc46b78e947d79bd4c6201f81e8e9"))
                // web3j = Web3j.build(HttpService("https://ropsten.infura.io/v3/43ebc46b78e947d79bd4c6201f81e8e9"))

                privKey = JavaWallet.mPreferenceDataModal.ETHPRIVATE_KEY
                credentials = Credentials.create(privKey!!.toString(16))
                Log.i("contractcommison", "commison Smart contract loading...")
                contractcommison = Jv.load(ContractAddress,
                        web3j, credentials, BigInteger.valueOf(JavaWallet.mPreferenceDataModal.GASPRICE.toLong()),
                        BigInteger.valueOf(JavaWallet.mPreferenceDataModal.GASLIMIT.toLong()))
                Log.i("contractcommison", "Smart contract addres " + contractcommison.getContractAddress())
                val value = Convert.toWei((amounttosend + feestoSend).toString(), Convert.Unit.ETHER).toBigInteger()
                Log.i("contractcommison", "valueeeee contract : " + value)
                val receipt = contractcommison.multipleOutputs(senderaddress, ethCommisionAddress,
                        Convert.toWei(amounttosend.toString(), Convert.Unit.ETHER).toBigInteger(),
                        Convert.toWei(feestoSend.toString(), Convert.Unit.ETHER).toBigInteger(), value).send()
                hideLoading()
                contractTransactionhash = receipt.getTransactionHash()
                Log.i("contractcommison", "Smart contract after: " + contractcommison.getContractAddress())
                Log.i("contractcommison", "Smart contract hash: " + receipt.getTransactionHash())


            } catch (e: Exception) {
                hideLoading()
                hitapi = false
                e.printStackTrace()
                errormessage = e.message!!
            }

            return contractTransactionhash
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if (hitapi) {
                sendCoinContract()
            } else {
                if (!errormessage.equals("")) {
                    showDialog(errormessage, false)
                }

            }

        }

    }

    private fun sendCoinContract() {
        showLoading()
        var rqst = afterSendRequest(contractTransactionhash, JavaWallet.mPreferenceDataModal.COIN_ADDRESS, ContractAddress, amounttosend, currentNonce,
                JavaWallet.mPreferenceDataModal.GASLIMIT.toLong(), JavaWallet.mPreferenceDataModal.GASPRICE.toLong(), "complete", 0)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.sendContract(JavaWallet.mPreferenceDataModal.JWTToken, "eth", cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }


}




