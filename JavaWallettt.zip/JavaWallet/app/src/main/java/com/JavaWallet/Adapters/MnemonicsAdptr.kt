package com.JavaWallet.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.R
import kotlinx.android.synthetic.main.mnemonic_item.view.*

/**
 * Created by user on 11/4/19.
 */

class MnemonicsAdptr(private val addresslist: List<String>, private val lstnr:  MnemonicListner, private val isclick: Boolean) : RecyclerView.Adapter< MnemonicsAdptr.ViewHolder>() {

    private lateinit var mContext: Context

    interface MnemonicListner {
        fun onAddress_Click(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.mnemonic_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val listdata = addresslist.get(position)

        holder.itemView.m_txt.text = addresslist.get(position)
        if(isclick){
            holder.itemView.setOnClickListener {
                lstnr.onAddress_Click(position)
            }
        }


    }

    override fun getItemCount(): Int {
        return addresslist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context
        }

        fun bindItems() {

        }
    }
}