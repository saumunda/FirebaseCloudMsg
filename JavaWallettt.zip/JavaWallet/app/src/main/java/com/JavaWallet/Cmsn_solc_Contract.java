package com.JavaWallet;

import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.5.8.
 */
@SuppressWarnings("rawtypes")
public class Cmsn_solc_Contract extends Contract {
    private static final String BINARY = "608060405234801561001057600080fd5b50610103806100206000396000f3fe608060405260043610601c5760003560e01c8063fda7b8e7146021575b600080fd5b605a60048036036080811015603557600080fd5b506001600160a01b03813581169160208101359091169060408101359060600135605c565b005b6040516001600160a01b0385169083156108fc029084906000818181858888f193505050501580156091573d6000803e3d6000fd5b506040516001600160a01b0384169082156108fc029083906000818181858888f1935050505015801560c7573d6000803e3d6000fd5b505050505056fea265627a7a723158202a4c309f00cab84dcb2fa752217be84871bb86dee718c899b29fb815daed6e8064736f6c634300050d0032";

    public static final String FUNC_MULTIPLEOUTPUTS = "multipleOutputs";

    @Deprecated
    protected Cmsn_solc_Contract(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected Cmsn_solc_Contract(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected Cmsn_solc_Contract(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected Cmsn_solc_Contract(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public RemoteCall<TransactionReceipt> multipleOutputs(String address1, String address2, BigInteger amt1, BigInteger amt2, BigInteger weiValue) {
        final Function function = new Function(
                FUNC_MULTIPLEOUTPUTS, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(address1),
                new org.web3j.abi.datatypes.Address(address2),
                new org.web3j.abi.datatypes.generated.Uint256(amt1), 
                new org.web3j.abi.datatypes.generated.Uint256(amt2)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function, weiValue);
    }

    @Deprecated
    public static Cmsn_solc_Contract load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new Cmsn_solc_Contract(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static Cmsn_solc_Contract load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new Cmsn_solc_Contract(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static Cmsn_solc_Contract load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new Cmsn_solc_Contract(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static Cmsn_solc_Contract load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new Cmsn_solc_Contract(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static RemoteCall<Cmsn_solc_Contract> deploy(Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Cmsn_solc_Contract.class, web3j, credentials, contractGasProvider, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Cmsn_solc_Contract> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Cmsn_solc_Contract.class, web3j, credentials, gasPrice, gasLimit, BINARY, "");
    }

    public static RemoteCall<Cmsn_solc_Contract> deploy(Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Cmsn_solc_Contract.class, web3j, transactionManager, contractGasProvider, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Cmsn_solc_Contract> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Cmsn_solc_Contract.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, "");
    }
}
