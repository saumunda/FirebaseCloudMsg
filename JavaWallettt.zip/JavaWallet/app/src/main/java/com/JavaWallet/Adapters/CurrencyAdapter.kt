package com.JavaWallet.Adapters

import android.content.Context
import android.support.v4.content.ContextCompat
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet.Companion.mPreferenceDataModal
import com.JavaWallet.R
import com.JavaWallet.Utility
import com.JavaWallet.networking.CurrencyListData
import kotlinx.android.synthetic.main.currency_item.view.*

/**
 * Created by user on 11/4/19.
 */

class CurrencyAdapter(private val currencyListData: ArrayList<CurrencyListData>, private val listener:  Listener) : RecyclerView.Adapter< CurrencyAdapter.ViewHolder>() {

    var row_index: Int = -1
    private lateinit var mContext: Context

    interface Listener {

        fun onItemClick(currencyListData: CurrencyListData)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  CurrencyAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.currency_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder:  CurrencyAdapter.ViewHolder, position: Int) {
        // holder.bindItems(currencyListData[position], listener,row_index,position)
        holder.itemView.tv_coinname.text = currencyListData.get(position).currencyName + "(" + currencyListData.get(position).currencyCode + ")"
        holder.itemView.setOnClickListener {
            row_index = position;
            notifyDataSetChanged();
            listener.onItemClick(currencyListData[position])

        }
        if (Utility.getTheme(mContext).equals((mContext as BaseActivity).THEME_DARK)) {
            if (row_index == position) {
                // change back on click
                holder.itemView.setBackgroundColor((mContext.getColor(R.color.black)));
                holder.itemView.ivcoin_check.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_choose_currency_tab_tick));
            } else {
                // check prvs selected value from pref and set value
                if (mPreferenceDataModal.DefaultCurrency.equals(currencyListData.get(position).currencyCode)) {
                    holder.itemView.setBackgroundColor((mContext.getColor(R.color.qPrimary_text_colorwhite_Darktheme)));
                    holder.itemView.ivcoin_check.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_choose_currency_tab_tick));
                } else {
                     holder.itemView.setBackgroundColor((mContext.getColor(R.color.black)));
                    holder.itemView.ivcoin_check.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_choose_currency_tab_tick_dark));
                }

            }
        } else if (Utility.getTheme(mContext).equals((mContext as  BaseActivity).THEME_LIGHT)) {
            if (row_index == position) {
                // change back on click
                holder.itemView.setBackgroundColor((mContext.getColor(R.color.colorPrimary_Lighttheme)));
                holder.itemView.ivcoin_check.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_choose_currency_tab_tick));
            } else {
                // check prvs selected value from pref and set value
                if (mPreferenceDataModal.DefaultCurrency.equals(currencyListData.get(position).currencyCode)) {
                    holder.itemView.setBackgroundColor((mContext.getColor(R.color.colorPrimary_Lighttheme)));
                    holder.itemView.ivcoin_check.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_choose_currency_tab_tick));
                } else {
                    holder.itemView.setBackgroundColor((mContext.getColor(R.color.white)));
                    holder.itemView.ivcoin_check.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_choose_currency_tab_tick_dark));
                }

            }
        }else{
            if (row_index == position) {
                // change back on click
                holder.itemView.setBackgroundColor((mContext.getColor(R.color.qPrimary_text_colorwhite_Darktheme)));
                holder.itemView.ivcoin_check.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_choose_currency_tab_tick));
            } else {
                // check prvs selected value from pref and set value
                if (mPreferenceDataModal.DefaultCurrency.equals(currencyListData.get(position).currencyCode)) {
                    holder.itemView.setBackgroundColor((mContext.getColor(R.color.qPrimary_text_colorwhite_Darktheme)));
                    holder.itemView.ivcoin_check.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_choose_currency_tab_tick));
                } else {
                    holder.itemView.setBackgroundColor((mContext.getColor(R.color.lightnewgrey)));
                    holder.itemView.ivcoin_check.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_choose_currency_tab_tick_dark));
                }

            }
        }



    }

    override fun getItemCount(): Int {
        return currencyListData.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        init {
            mContext = itemView.context

        }

        fun bindItems(currencyListData: CurrencyListData, listener:  CurrencyAdapter.Listener) {
            itemView.setOnClickListener {}
        }
    }
}