package com.JavaWallet.models
import com.google.gson.annotations.SerializedName



data class Unspent(
    @SerializedName("unspent_outputs") var unspentOutputs: ArrayList<UnspentOutput>
)

data class UnspentOutput(
    @SerializedName("tx_hash") var txHash: String,
    @SerializedName("tx_hash_big_endian") var txHashBigEndian: String,
    @SerializedName("tx_output_n") var txOutputN: Int,
    @SerializedName("script") var script: String,
    @SerializedName("value") var value: Int,
    @SerializedName("value_hex") var valueHex: String,
    @SerializedName("confirmations") var confirmations: Int,
    @SerializedName("tx_index") var txIndex: Int
)