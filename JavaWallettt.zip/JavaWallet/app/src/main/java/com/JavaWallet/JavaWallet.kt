package com.JavaWallet

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.Application
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Point
import android.hardware.fingerprint.FingerprintManager
import android.os.*
import android.preference.PreferenceManager
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.support.v4.app.ActivityCompat
import android.support.v4.content.LocalBroadcastManager
import android.util.Log
import android.view.WindowManager
import com.JavaWallet.FingerPrintSensor.FingerPrintStatusInfo
import com.JavaWallet.FingerPrintSensor.FingerprintHandler
import com.JavaWallet.Utilities.Preference
import com.JavaWallet.models.PreferenceDataModal
import com.JavaWallet.ui.activities.NewPinAfterImportResume
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.iid.FirebaseInstanceId
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import org.bitcoinj.crypto.MnemonicCode
import java.io.File
import java.io.IOException
import java.security.*
import java.security.cert.CertificateException
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.NoSuchPaddingException
import javax.crypto.SecretKey

/**
 * Created by user on 14/5/19.
 */
class JavaWallet : Application() {


    private var txCachePath: File? = null
    private var packageInfo: PackageInfo? = null
    private var versionString: String? = null

    private var lastStop: Long = 0


    private var walletFile: File? = null

    private var coinServiceIntent: Intent? = null
    private var coinServiceConnectIntent: Intent? = null
    private var coinServiceCancelCoinsReceivedIntent: Intent? = null

    lateinit var mRemoteConfig: FirebaseRemoteConfig

    /**
     * For FingerPrint Scanner
     */

    inner class AppLifecycleTracker : Application.ActivityLifecycleCallbacks {
        private var numStarted = 0
        override fun onActivityPaused(p0: Activity?) {
        }

        override fun onActivityResumed(p0: Activity?) {
        }

        override fun onActivityStarted(p0: Activity?) {
            if (numStarted == 0) {
                if (JavaWallet.mPreferenceDataModal.ISSIGNIN) {

                    val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    val taskInfo = am.getRunningTasks(1)
                    val act_name = taskInfo[0].topActivity.className
                    if (act_name == ConstantsUtils.NewPinAfterImport_Screen || act_name == ConstantsUtils.Splash_Screen) {

                    } else {

                        if (!ConstantsUtils.isthemeCliked) {

                            val i = Intent().setClass(this@JavaWallet, NewPinAfterImportResume::class.java)
                            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(i)
                        }

                    }


                }

            }
            numStarted++
        }

        override fun onActivityDestroyed(p0: Activity?) {
        }

        override fun onActivitySaveInstanceState(p0: Activity?, p1: Bundle?) {
        }

        override fun onActivityStopped(p0: Activity?) {
            numStarted--
            if (numStarted == 0) {
                Log.i("OnActivity Stopped", "Has Gone to the Background ")
            }

        }

        override fun onActivityCreated(p0: Activity?, p1: Bundle?) {
        }

    }


    override fun onCreate() {
        super.onCreate()
        IMAGEBASE_URL = BuildConfig.IMAGEBASE_URL
        BASE_URL_LINKS = BuildConfig.BASE_URL_LINKS
        BASE_URL = BuildConfig.BASE_URL
        BASE_KEY = BuildConfig.BASE_KEY
        is_MainNet = BuildConfig.is_MainNet
        AES_KEY = resources.getString(R.string.AES_KEY)
        AES_IV = resources.getString(R.string.AES_IV)
        PREFERNCE_KEY = resources.getString(R.string.PREFERNCE_KEY)
        instance = this
        mPreferenceDataModal = Preference.getInstance(instance).sharedPreference
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val size = Point()
        display.getSize(size)
        width = size.x
        height = size.y
        setFirebaseToken()
        registerActivityLifecycleCallbacks(AppLifecycleTracker())
        packageInfo = packageInfoFromContext(this)
        versionString = packageInfo!!.versionName.replace(" ", "_") + "__" +
                packageInfo!!.packageName + "_android"



        StrictMode.setThreadPolicy(
                StrictMode.ThreadPolicy.Builder().detectAll().permitDiskReads().permitDiskWrites().penaltyLog().build())


        // Set MnemonicCode.INSTANCE if needed
        if (MnemonicCode.INSTANCE == null) {
            try {
                MnemonicCode.INSTANCE = MnemonicCode()
            } catch (e: IOException) {
                throw RuntimeException("Could not set MnemonicCode.INSTANCE", e)
            }

        }

        initializeFirebase()
    }

    private fun initializeFirebase() {

        mRemoteConfig = FirebaseRemoteConfig.getInstance()
        mRemoteConfig.setDefaults(R.xml.remote_values)
        val remoteConfigSettings = FirebaseRemoteConfigSettings.Builder().setDeveloperModeEnabled(BuildConfig.DEBUG).build()
        mRemoteConfig.setConfigSettings(remoteConfigSettings)
        fetchRemoteConfigValues()
    }
    private fun fetchRemoteConfigValues() {
        var cacheExpiration: Long = 3600

        if (mRemoteConfig.info.configSettings.isDeveloperModeEnabled) {
            cacheExpiration = 0
        }
        val finalCacheExpiration = cacheExpiration
        Handler().postDelayed({
            mRemoteConfig.fetch(finalCacheExpiration).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    mRemoteConfig.info.lastFetchStatus
                    mRemoteConfig.getString("version_name")
                    mRemoteConfig.activateFetched()
                    val newVersion = mRemoteConfig.getString("versionName")
                    val versionName = BuildConfig.VERSION_NAME

                    if (versionName == newVersion) {
                        mPreferenceDataModal.NEW_VERSON=false
                        setPreference(mPreferenceDataModal)
                    } else {
                        mPreferenceDataModal.NEW_VERSON=true
                        setPreference(mPreferenceDataModal)
                    }
                } else {
                }
            }
        }, 0)


    }


    fun packageInfoFromContext(context: Context): PackageInfo {
        try {
            return context.packageManager.getPackageInfo(context.packageName, 0)
        } catch (x: PackageManager.NameNotFoundException) {
            throw RuntimeException(x)
        }

    }


    private fun setFirebaseToken() {
        if (JavaWallet.mPreferenceDataModal.DEVICEToken.equals("")) {
            FirebaseInstanceId.getInstance().instanceId
                    .addOnCompleteListener(OnCompleteListener { task ->
                        if (!task.isSuccessful) {
                            return@OnCompleteListener
                        }
                        // Get new Instance ID token
                        val token = task.result?.token
                        JavaWallet.mPreferenceDataModal.DEVICEToken = token!!
                        JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                    })
        }
    }

    companion object {
        lateinit var mPreferenceDataModal: PreferenceDataModal
        var fingerPrintErrorStatus = FingerPrintStatusInfo.FINGER_PRINT_NO_SUPPORTED
        var fingerPrintErrorMessage = ""
        var fingerprintManager: FingerprintManager? = null
        var keyguardManager: KeyguardManager? = null
        var cryptoObject: FingerprintManager.CryptoObject? = null
        var IMAGEBASE_URL = ""
        var BASE_URL_LINKS = ""
        var BASE_URL = ""
        var BASE_KEY = ""
        var AES_KEY = ""
        var AES_IV = ""
        var PREFERNCE_KEY = ""
        var is_MainNet = false
        var instance: JavaWallet? = null
        val KEY_NAME = "yourKey"
        var cipher: Cipher? = null
        var keyStore: KeyStore? = null
        var keyGenerator: KeyGenerator? = null
        var width = 0
        var height = 0

        val walletId_b = "MyWallet_java"

        var stateProgress: Double = 0.0

        fun setPreference(preferenceDataModal: PreferenceDataModal) {
            Preference.getInstance(instance).sharedPreference = preferenceDataModal
        }

        fun checkIsFingerprintLockEnabled(ctx: Context): Boolean {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                keyguardManager = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager?
                fingerprintManager = ctx.getSystemService(Context.FINGERPRINT_SERVICE) as FingerprintManager?
                if (fingerprintManager != null) {
                    if (!fingerprintManager!!.isHardwareDetected()) {
                        fingerPrintErrorMessage = "Your device doesn't support fingerprint authentication"
                        fingerPrintErrorStatus = FingerPrintStatusInfo.FINGER_PRINT_NO_SUPPORTED
                        return false
                    }
                } else {
                    fingerPrintErrorMessage = "Your device doesn't support fingerprint authentication"
                    fingerPrintErrorStatus = FingerPrintStatusInfo.FINGER_PRINT_NO_SUPPORTED
                    return false
                }

                if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED) {
                    fingerPrintErrorMessage = "Please enable the fingerprint permission"
                    fingerPrintErrorStatus = FingerPrintStatusInfo.FINGER_PRINT_OTHER_ERROR
                    return false
                }
                if (!fingerprintManager!!.hasEnrolledFingerprints()) {
                    fingerPrintErrorMessage = "No fingerprint configured. Please register at least one fingerprint in your device's Settings"
                    fingerPrintErrorStatus = FingerPrintStatusInfo.FINGER_PRINT_NO_SUPPORTED
                    return false
                }
                if (!keyguardManager!!.isKeyguardSecure()) {
                    fingerPrintErrorMessage = "Please enable lockscreen security in your device's Settings"
                    fingerPrintErrorStatus = FingerPrintStatusInfo.FINGER_PRINT_NO_SUPPORTED
                    return false
                } else {
                    try {
                        generateKey()
                    } catch (e: FingerprintException) {
                        e.printStackTrace()
                    }

                    if (initCipher()) {
                        cryptoObject = FingerprintManager.CryptoObject(cipher)
                        val helper = FingerprintHandler(ctx)
                        helper.startAuth(fingerprintManager, cryptoObject)
                    }
                    return true
                }
            }
            return false
        }


        @Throws(FingerprintException::class)
        fun generateKey() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    keyStore = KeyStore.getInstance("AndroidKeyStore")
                    keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
                    keyStore!!.load(null)
                    keyGenerator!!.init(KeyGenParameterSpec.Builder(KEY_NAME,
                            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                            .setBlockModes(KeyProperties.BLOCK_MODE_CBC)
                            .setUserAuthenticationRequired(true)
                            .setEncryptionPaddings(
                                    KeyProperties.ENCRYPTION_PADDING_PKCS7)
                            .build())

                    keyGenerator!!.generateKey()
                } catch (exc: KeyStoreException) {
                    exc.printStackTrace()
                    throw FingerprintException(exc)
                } catch (exc: NoSuchAlgorithmException) {
                    exc.printStackTrace()
                    throw FingerprintException(exc)
                } catch (exc: NoSuchProviderException) {
                    exc.printStackTrace()
                    throw FingerprintException(exc)
                } catch (exc: InvalidAlgorithmParameterException) {
                    exc.printStackTrace()
                    throw FingerprintException(exc)
                } catch (exc: CertificateException) {
                    exc.printStackTrace()
                    throw FingerprintException(exc)
                } catch (exc: IOException) {
                    exc.printStackTrace()
                    throw FingerprintException(exc)
                }

            }
        }

        fun initCipher(): Boolean {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    cipher = Cipher.getInstance(
                            KeyProperties.KEY_ALGORITHM_AES + "/"
                                    + KeyProperties.BLOCK_MODE_CBC + "/"
                                    + KeyProperties.ENCRYPTION_PADDING_PKCS7)
                } catch (e: NoSuchAlgorithmException) {
                    throw RuntimeException("Failed to get Cipher", e)
                } catch (e: NoSuchPaddingException) {
                    throw RuntimeException("Failed to get Cipher", e)
                }

                try {
                    keyStore!!.load(
                            null)
                    val key = keyStore!!.getKey(KEY_NAME, null) as SecretKey
                    cipher!!.init(Cipher.ENCRYPT_MODE, key)
                    return true
                } catch (e: KeyPermanentlyInvalidatedException) {
                    return false
                } catch (e: KeyStoreException) {
                    throw RuntimeException("Failed to init Cipher", e)
                } catch (e: CertificateException) {
                    throw RuntimeException("Failed to init Cipher", e)
                } catch (e: UnrecoverableKeyException) {
                    throw RuntimeException("Failed to init Cipher", e)
                } catch (e: IOException) {
                    throw RuntimeException("Failed to init Cipher", e)
                } catch (e: NoSuchAlgorithmException) {
                    throw RuntimeException("Failed to init Cipher", e)
                } catch (e: InvalidKeyException) {
                    throw RuntimeException("Failed to init Cipher", e)
                }

            }
            return false
        }

        private class FingerprintException(e: Exception) : Exception(e)


    }
}
