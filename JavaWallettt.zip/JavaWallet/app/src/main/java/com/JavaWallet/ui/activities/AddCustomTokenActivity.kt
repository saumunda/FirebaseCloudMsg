package com.JavaWallet.ui.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.Utility
import com.JavaWallet.networking.*
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_add_custom_token.*
import kotlinx.android.synthetic.main.header_title.*
import org.json.JSONArray


class AddCustomTokenActivity : BaseActivity(), View.OnClickListener {


    private var coin_name = ""
    private var coingeekoalias = ""
    var delay: Long = 800 // 1 seconds after user stops typing
    var last_text_edit: Long = 0
    var handler_ = Handler()
    private var isthemeDark: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_custom_token)
        tv_title.text = getString(R.string.addcustomtoken)
        onclick()

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
            iv_search_icon.setColorFilter(resources.getColor(R.color.white));
         } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
            iv_search_icon.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
         } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
            iv_search_icon.setColorFilter(resources.getColor(R.color.white));
         }

        edt_token_contract_address.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {

                if (p0!!.isNotEmpty()) {
                    last_text_edit = System.currentTimeMillis();
                    handler_.postDelayed(input_finish_checker, delay);
                } else {
                    hitApi()
                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                handler_.removeCallbacks(input_finish_checker)
            }

        })
    }

    private fun hitApi() {

        if (isInternetConnected()) {
            getCustomToken(edt_token_contract_address.text.toString().trim())
        } else {
            showDialog(getString(R.string.network_error), false)
        }
    }

    private fun getCustomToken(word: String) {
        if (!word.equals("")) {
            showLoading()
            apiServiceWithAuthorization.getCustomToken(word)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponse(it) },
                            { error -> handleError(error);hideLoading() })
        }


    }

    private fun handleResponse(it: Any) {
        hideLoading()

        when (it) {
            is ContractResponse -> {
                if (it.status.equals("1")) {
                    edt_token_symbol.text = it.result.symbol
                    edt_decimals_of_precision.text = it.result.decimals
                    coin_name = it.result.name

                } else if (it.status.equals("0")) {
                    showDialog(it.message, false)
                    edt_token_symbol.text = ""
                    edt_decimals_of_precision.text = ""
                }

            }

            is BaseResponse -> {
                if (it.status) {
                    showDialog(it.message, true)
                } else {
                    showDialog(it.message, false)

                }

            }


        }
    }

    private val input_finish_checker = Runnable {
        if (System.currentTimeMillis() > last_text_edit + delay - 500) {
            hitApi()
        }
    }

    private fun onclick() {
        iv_back.setOnClickListener(this)
        iv_search_icon.setOnClickListener(this)
        edt_token_symbol.setOnClickListener(this)
        tv_add_token.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {

            R.id.iv_back -> {
                finish()
            }

            R.id.iv_search_icon -> {
                callActivityforResult(SearchTokenActivity::class.java, 150)
            }
            R.id.edt_token_symbol -> {
                callActivityforResult(SearchTokenActivity::class.java, 150)
            }
            R.id.tv_add_token -> {
                if (edt_token_contract_address.text.toString().equals("") || edt_token_symbol.text.toString().equals("")) {
                    showDialog(getString(R.string.plsfill), false)

                } else {
                    if (JavaWallet.mPreferenceDataModal.COINGEEKODATA.equals("")) {
                        getCoinGeekoApi()
                    } else {
                        cheCkApi()
                    }
                }


            }

        }
    }

    private fun getCoinGeekoApi() {

        showLoading()
        apiInterfaceWithAuthorization_Token.getCoingeekosearch()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponseArr(it) },
                        { error -> handleError(error);hideLoading() })
    }

    private fun handleResponseArr(it: ArrayList<CoinGeekoList>?) {
        hideLoading()
        val jsonarray = JSONArray(Gson().toJson(it))
        JavaWallet.mPreferenceDataModal.COINGEEKODATA = jsonarray.toString()
        JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)

        cheCkApi()


    }

    private fun cheCkApi() {
        try {
            val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.COINGEEKODATA)
            for (i in 0 until jsonarray.length()) {
                var jsnobj = jsonarray.getJSONObject(i)

                if (edt_token_symbol.text.toString().trim().toLowerCase().equals(jsnobj.getString("symbol"))) {
                    coingeekoalias = jsnobj.getString("id")
                    break
                }

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        sendTokenApi()


    }

    private fun sendTokenApi() {
        showLoading()
        var rqst = addTokenRequest(coin_name, edt_token_symbol.text.toString().trim().toLowerCase(), coingeekoalias, edt_decimals_of_precision.text.toString().trim(),
                edt_token_contract_address.text.toString().trim())
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.addTokenApi(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 150 && resultCode == Activity.RESULT_OK) {
            edt_token_contract_address.setText(data?.getStringExtra(getString(R.string.smartContracrAddess)))
        }
    }

}
