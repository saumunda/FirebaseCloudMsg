package com.JavaWallet.ui.activities

import android.os.Bundle
import android.view.View
import com.JavaWallet.BaseActivity
import com.JavaWallet.R
import com.JavaWallet.Utility
import kotlinx.android.synthetic.main.activity_backupnow.*
import kotlinx.android.synthetic.main.header_title.*

class Backupnow : BaseActivity() {

    private var isfrom: Boolean = false
    private var isfromsetting: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_backupnow)

        try {
            var b: Bundle? = Bundle()
            b = intent.extras
            isfrom = b!!.getBoolean(getString(R.string.isfromcreate))
            isfromsetting = b!!.getBoolean(getString(R.string.isfromsetting))

        } catch (e: Exception) {
            e.printStackTrace()
        }


        if (isfrom) {
            hdr.visibility = View.GONE
        } else {
            hdr.visibility = View.VISIBLE
        }
        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
         } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
         } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
         }
        cb_understandnow.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) {
                if (isChecked) {
                    tv_continue.visibility = View.VISIBLE
                } else {
                    tv_continue.visibility = View.INVISIBLE
                }
            }
        }
        iv_back.setOnClickListener {
            finish()
        }
        tv_continue.setOnClickListener {
            if (isfrom) {
                startNewActivity(BackMnemonics())
            } else if (isfromsetting) {
                var bndl = Bundle()
                bndl.putBoolean(getString(R.string.isfromSend), false)
                bndl.putBoolean(getString(R.string.isfromsetting), true)
                bndl.putBoolean(getString(R.string.isfromTransaction), false)
                bndl.putBoolean(getString(R.string.isfromImport), false)
                callActivityWithData(NewPinAfterImport::class.java, bndl)
            } else {
                startNewActivity(BackupWallet())
            }

            finish()
        }
    }

    override fun onBackPressed() {
        if (!isfrom) {
            super.onBackPressed()
        }

    }
}
