package com.JavaWallet.Fcm

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Bundle
import android.provider.Settings
import android.support.v4.app.NotificationCompat
import com.JavaWallet.R
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import android.support.v4.content.LocalBroadcastManager
import com.JavaWallet.ConstantsUtils
import com.JavaWallet.ui.activities.BackupCosignerNotificationActivity
import com.JavaWallet.ui.activities.MainActivity
import com.JavaWallet.ui.activities.ThreeFactor
import com.JavaWallet.ui.activities.TransactionDetail


/**
 * Created by user on 24/5/19.
 */
class MyFirebaseMessagingService : FirebaseMessagingService() {
    internal var ctx: Context = this
    private lateinit var pendingIntent: PendingIntent

    override fun onMessageReceived(remoteMessage: RemoteMessage?) {
        super.onMessageReceived(remoteMessage)
        showNotification(remoteMessage)
    }

    private fun showNotification(remoteMessage: RemoteMessage?) {

        //2=notify to sender, cosigner accepted req
        if (remoteMessage!!.data["notification_type"].equals("2") || remoteMessage!!.data["notification_type"].equals("3")
                || remoteMessage!!.data["notification_type"].equals("4")) {
            val intent = Intent(this, ThreeFactor::class.java)
            val bundle = Bundle()
            bundle.putBoolean(getString(R.string.is_sent), true)
            intent.putExtras(bundle);
            pendingIntent = PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT)

            //local broadacast
            val i = Intent(ConstantsUtils.threeFactorUpadte)
            i.putExtra("is_sentB", true)
            LocalBroadcastManager.getInstance(this).sendBroadcast(i)
        }

        // 5=notify to cosigner, when get removed;
        else if (remoteMessage!!.data["notification_type"].equals("5")) {
            val intent = Intent(this, ThreeFactor::class.java)
            val bundle = Bundle()
            bundle.putBoolean(getString(R.string.is_sent), false)
            intent.putExtras(bundle);
            pendingIntent = PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT)

            //local broadacast
            val i = Intent(ConstantsUtils.threeFactorUpadte)
            i.putExtra("is_sentB", false)
            LocalBroadcastManager.getInstance(this).sendBroadcast(i)

        }
        // 6=notify to cosigners, on withdraw tx;
        else if (remoteMessage!!.data["notification_type"].equals("6")) {
            val intent = Intent(this, MainActivity::class.java)
            val bundle = Bundle()
            bundle.putBoolean(getString(R.string.showAuthPopup), true)
            bundle.putInt(getString(R.string.t_id), remoteMessage!!.data["tx_id"]!!.toInt())
            intent.putExtras(bundle);
            pendingIntent = PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT)

            //local broadacast
            val i = Intent(ConstantsUtils.showAuthpop)
            i.putExtra(getString(R.string.showAuthPopup), true)
            i.putExtra(getString(R.string.t_id), remoteMessage!!.data["tx_id"]!!.toInt())
            LocalBroadcastManager.getInstance(this).sendBroadcast(i)
        }
        //7=notify to `from`, on cosigner accept wihdraw req;
        else if (remoteMessage!!.data["notification_type"].equals("7") || remoteMessage!!.data["notification_type"].equals("8")
                || remoteMessage!!.data["notification_type"].equals("9") || remoteMessage!!.data["notification_type"].equals("10")
                || remoteMessage!!.data["notification_type"].equals("11") || remoteMessage!!.data["notification_type"].equals("12")
                || remoteMessage!!.data["notification_type"].equals("13") || remoteMessage!!.data["notification_type"].equals("14")
                || remoteMessage!!.data["notification_type"].equals("15") || remoteMessage!!.data["notification_type"].equals("16")) {
            val intent = Intent(this, TransactionDetail::class.java)
            val bundle = Bundle()
            bundle.putInt(getString(R.string.t_id), remoteMessage!!.data["tx_id"]!!.toInt())
            bundle.putString(getString(R.string.t_type), remoteMessage!!.data["tx_type"])
            intent.putExtras(bundle);
            pendingIntent = PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT)

            val i = Intent(ConstantsUtils.updateTransactionList)
            LocalBroadcastManager.getInstance(this).sendBroadcast(i)

            val ib = Intent(ConstantsUtils.updatetBalance)
            LocalBroadcastManager.getInstance(this).sendBroadcast(ib)

            val id = Intent(ConstantsUtils.updateDetail)
            LocalBroadcastManager.getInstance(this).sendBroadcast(id)

        } else if (remoteMessage!!.data["notification_type"].equals("17")) {
            val intent = Intent(this, BackupCosignerNotificationActivity::class.java)
            val bundle = Bundle()
            bundle.putInt(getString(R.string.fromuserid), remoteMessage!!.data["from_user_id"]!!.toInt())
            intent.putExtras(bundle);
            pendingIntent = PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT)

        }else if (remoteMessage!!.data["notification_type"].equals("18")) {
            val intent = Intent(this, MainActivity::class.java)
            val bundle = Bundle()
            bundle.putBoolean(getString(R.string.opensetting), true)
            intent.putExtras(bundle);
            pendingIntent = PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT)

            val ib = Intent(ConstantsUtils.updatetBackUpRequestList)
            LocalBroadcastManager.getInstance(this).sendBroadcast(ib)

        }else if (remoteMessage!!.data["notification_type"].equals("19")) {
            val intent = Intent(this, MainActivity::class.java)
            val bundle = Bundle()
            bundle.putBoolean(getString(R.string.opensetting), true)
            intent.putExtras(bundle);
            pendingIntent = PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT)

        }
        val mBuilder = NotificationCompat.Builder(this)
        val CHANNEL_ID = ctx.getResources().getString(R.string.default_notification_channel_id)
        val appname = getString(R.string.app_name)
        val importance = NotificationManager.IMPORTANCE_HIGH
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val mChannel = NotificationChannel(CHANNEL_ID, appname, importance)
            notificationManager.createNotificationChannel(mChannel)
        }
        mBuilder.setStyle(NotificationCompat.BigTextStyle().bigText(remoteMessage!!.data["title"]))
        mBuilder.setContentTitle(remoteMessage!!.data["title"])
        mBuilder.setChannelId(CHANNEL_ID)
        mBuilder.setContentIntent(pendingIntent)
        mBuilder.setSmallIcon(R.mipmap.ic_java_launcher_round)
        mBuilder.setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
        mBuilder.setPriority(Notification.PRIORITY_HIGH)
        mBuilder.setSound(soundUri)
        mBuilder.setAutoCancel(true)
        notificationManager.notify(0, mBuilder.build())
    }
}
