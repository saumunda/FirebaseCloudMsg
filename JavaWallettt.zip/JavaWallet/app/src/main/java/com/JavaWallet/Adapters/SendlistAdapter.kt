package com.JavaWallet.Adapters

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.networking.ManageWalletData
import kotlinx.android.synthetic.main.sendlist_item.view.*
import java.util.*
import kotlin.collections.ArrayList

/**
 * Created by user on 11/4/19.
 */

class SendlistAdapter(private val walletlist: ArrayList<ManageWalletData>, private val lstnr:  SendlistAdapter.Listner) : RecyclerView.Adapter< SendlistAdapter.ViewHolder>() {


    private lateinit var mContext: Context
    interface Listner {
        fun onCoin_Click(walletlist : ManageWalletData)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  SendlistAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.sendlist_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder:  SendlistAdapter.ViewHolder, position: Int) {
        var listdata=walletlist.get(position)
        holder.itemView.tv_coin.text= listdata.coinName

        try{
            val rnd = Random()
            val color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
            if(walletlist.get(position).coinImage==null){
                holder.itemView.iv_currencyicon.visibility=View.GONE
                holder.itemView.tv_roundr.visibility=View.VISIBLE
                val bgShape = holder.itemView.tv_roundr.getBackground() as GradientDrawable
                bgShape.setColor(color)
                holder.itemView.tv_roundr.text=walletlist.get(position).coinName.substring(0,1);
            }else{
                holder.itemView.iv_currencyicon.visibility=View.VISIBLE
                holder.itemView.tv_roundr.visibility=View.GONE
                (mContext as BaseActivity).loadPicture_circle(holder.itemView.iv_currencyicon, JavaWallet.IMAGEBASE_URL + listdata.coinImage)

            }

        }catch (e:Exception){
            e.printStackTrace()
        }


        holder.itemView.lnr_main.setOnClickListener {
            lstnr.onCoin_Click(listdata)
        }
        holder.bindItems()

    }

    override fun getItemCount(): Int {
        return walletlist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        init {
         mContext=itemView.context
        }
        fun bindItems() {

        }
    }
}