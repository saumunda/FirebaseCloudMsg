package com.JavaWallet.Adapters

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utilities.ItemTouchHelperAdapter
import com.JavaWallet.Utilities.OnCustomerListChangedListener
import com.JavaWallet.Utilities.OnStartDragListener
import com.JavaWallet.networking.CombinedManageWalletData
import com.JavaWallet.networking.ManageWalletData
import kotlinx.android.synthetic.main.manage_item.view.*
import java.util.*

/**
 * Created by user on 11/4/19.
 */

class ManageAdapter(private val walletListData: ArrayList<ManageWalletData>, private val Combinedwalletlist: ArrayList<CombinedManageWalletData>,
                    private val listener:  ManageAdapter.Listener, private val ishowDrag: Boolean,
                    private val dragLlistener: OnStartDragListener, private val listChangedListener: OnCustomerListChangedListener) : RecyclerView.Adapter< ManageAdapter.ViewHolder>()
        , ItemTouchHelperAdapter {


    private lateinit var mContext: Context

    interface Listener {

        fun onItemClick(walletListData: ManageWalletData, position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  ManageAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.manage_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder:  ManageAdapter.ViewHolder, position: Int) {
//        holder.bindItems()
        var listdata = walletListData.get(position)
        holder.itemView.tv_coin.text = listdata.coinName

        holder.itemView.tv_balancecrypto.text = "" + (mContext as BaseActivity).decimalConverterUpto(listdata.balance, 8) + " " + listdata.coinSymbol.toUpperCase()

        if (ishowDrag) {
            holder.itemView.iv_expand.visibility = View.VISIBLE
            holder.itemView.manage_swtch.visibility = View.GONE
        } else {
            holder.itemView.iv_expand.visibility = View.GONE
            holder.itemView.manage_swtch.visibility = View.VISIBLE
        }
        try {

            if (listdata.coinSymbol.equals("upl", true)) {
                holder.itemView.tv_balancefiat.text =
                        (mContext as BaseActivity).decimalConverterUpto(((listdata.balance) * (JavaWallet.mPreferenceDataModal.uplvalue)), 2) +
                                " " + listdata.currencyCode
            }else{
                holder.itemView.tv_balancefiat.text =
                        (mContext as  BaseActivity).decimalConverterUpto(((Combinedwalletlist[position].listbalance) * (Combinedwalletlist[position].current_price)), 2) +
                                " " + listdata.currencyCode
            }



        } catch (e: Exception) {
            e.printStackTrace()
            holder.itemView.tv_balancefiat.text = "0.00 " + listdata.currencyCode
        }




        holder.itemView.manage_swtch.isChecked = true


        val rnd = Random()
        val color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
        try{
            if(walletListData[position].coinImage==null){
                holder.itemView.iv_currency.visibility=View.INVISIBLE
                holder.itemView.tv_roundm.visibility=View.VISIBLE
                val bgShape = holder.itemView.tv_roundm.getBackground() as GradientDrawable
                bgShape.setColor(color)
                holder.itemView.tv_roundm.text=walletListData.get(position).coinName.substring(0,1);
            }else{
                holder.itemView.iv_currency.visibility=View.VISIBLE
                holder.itemView.tv_roundm.visibility=View.GONE
                (mContext as  BaseActivity).loadPicture_circle(holder.itemView.iv_currency, JavaWallet.IMAGEBASE_URL + listdata.coinImage)

            }

        }catch (e:Exception){
            e.printStackTrace()
        }



        holder.itemView.manage_swtch.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {
                if (!isChecked) {
                    listener.onItemClick(walletListData.get(position), position)
                }
            }

        })


    }

    override fun getItemCount(): Int {
        return walletListData.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context

        }

        fun bindItems() {

        }
    }

    override fun onItemMove(fromPosition: Int, toPosition: Int) {
        Collections.swap(walletListData, fromPosition, toPosition);
        listChangedListener.onNoteListChanged(walletListData)
        notifyItemMoved(fromPosition, toPosition);

    }

    override fun onItemDismiss(position: Int) {
    }


}