package com.JavaWallet.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.BaseActivity
import com.JavaWallet.R
import com.JavaWallet.networking.NotificationData
import kotlinx.android.synthetic.main.notification_item.view.*


/**
 * Created by user on 11/4/19.
 */

class NotificationAdapter(private val ntfcctnlist: ArrayList<NotificationData>, private val isthemeDark: Boolean,private val lstnr:  InviteListner) : RecyclerView.Adapter< NotificationAdapter.ViewHolder>() {

    private lateinit var mContext: Context
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.notification_item, parent, false)
        return ViewHolder(v)
    }
    interface InviteListner {
        fun oninvite_Click(
                userlist: ArrayList<NotificationData>, position: Int)

    }

    override fun onBindViewHolder(holder:  ViewHolder, position: Int) {
        val listdata = ntfcctnlist.get(position)
        holder.itemView.tv_deposit.text = listdata.message

        if (listdata.notificationType == 2) {
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_compeleted))
        } else if (listdata.notificationType == 3) {
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.cross_fialed))
        } else if (listdata.notificationType == 4) {
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.exclamtion))
            holder.itemView.iv_transactionstatus.setColorFilter(mContext.resources.getColor(R.color.red));
        } else if (listdata.notificationType == 5) {
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.cross_fialed))
        } else if (listdata.notificationType == 6) {
            holder.itemView.iv_transactionstatus.setColorFilter(mContext.resources.getColor(R.color.dred));
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_up_black))

        } else if (listdata.notificationType == 7) {
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_compeleted))
        } else if (listdata.notificationType == 8) {
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.cross_fialed))
        } else if (listdata.notificationType == 9) {
            holder.itemView.iv_transactionstatus.setColorFilter(mContext.resources.getColor(R.color.dred));
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_up_black))
        } else if (listdata.notificationType == 10) {
            holder.itemView.iv_transactionstatus.setColorFilter(mContext.resources.getColor(R.color.dred));
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_up_black))
        } else if (listdata.notificationType == 11) {
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.cross_fialed))
        } else if (listdata.notificationType == 12) {
            holder.itemView.iv_transactionstatus.setColorFilter(mContext.resources.getColor(R.color.greenbottom));
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_down_black))

        } else if (listdata.notificationType == 13) {
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.cross_fialed))
        } else if (listdata.notificationType == 14) {
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_compeleted))
        } else if (listdata.notificationType == 15) {
            holder.itemView.iv_transactionstatus.setColorFilter(mContext.resources.getColor(R.color.greenbottom));
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_down_black))
        } else if (listdata.notificationType == 16) {
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
        } else {
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_compeleted))
        }

        holder.itemView.tv_deposittime.text = "Received on: " + (mContext as BaseActivity).convertUTCtoDeviceZone(listdata.createdAt, "dd MMM, yyyy ' | 'hh:mm a")


        holder.itemView.rltv_item.setOnClickListener {
            lstnr.oninvite_Click(ntfcctnlist,position)
        }

    }

    override fun getItemCount(): Int {
        return ntfcctnlist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context

        }


    }
}