package com.JavaWallet.ui.fragments

import android.app.DatePickerDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.support.design.widget.BottomSheetDialog
import android.support.v4.content.LocalBroadcastManager
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.RelativeLayout
import com.JavaWallet.networking.*
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.transaction_frag.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import com.JavaWallet.*
import com.JavaWallet.Adapters.FilterWalletAdapter
import com.JavaWallet.Adapters.TransactionAdapter
import com.JavaWallet.ConstantsUtils
import com.JavaWallet.JavaWallet
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.Utility
import com.google.gson.Gson


class Transaction_frag : BaseFragment(), View.OnClickListener, FilterWalletAdapter.Listner {


    private lateinit var linearLayoutManager: LinearLayoutManager
    lateinit var transactionlist: ArrayList<TransactionData>

    var coinlist: ArrayList<CoinListData> = ArrayList()
    var coinlisttemp: ArrayList<CoinListData> = ArrayList()
    private var hasBeenVisibleOnce = false

    private var isthemeDark: Boolean = false
    var isApply = false

    private lateinit var localBroadcastManager: LocalBroadcastManager
    private lateinit var getB_Receiver: ListUpdateBroadcast
    private lateinit var lstFilter: IntentFilter

    inner class ListUpdateBroadcast : BroadcastReceiver() {

        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ConstantsUtils.updateTransactionList) {
                mActivity.isAcceptAuthRequestClicked = true
                getTrnasactionData()
                ConstantsUtils.ISUPDATEBALANCE = true
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.transaction_frag, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view!!, savedInstanceState)
        ConstantsUtils.isthemeCliked = false
        if (Utility.getTheme(mActivity).equals(mActivity.THEME_DARK)) {
            isthemeDark = true
            tv_inprogress.setTextColor(resources.getColor(R.color.Secondary_text_color_lightred_Darktheme))
            tv_filter.setTextColor(resources.getColor(R.color.white))
            iv_filter.setColorFilter(resources.getColor(R.color.white));
        } else if (Utility.getTheme(mActivity).equals(mActivity.THEME_LIGHT)) {
            isthemeDark = false
            tv_inprogress.setTextColor(resources.getColor(R.color.transtime_light))
            tv_filter.setTextColor(resources.getColor(R.color.logout_light))
            iv_filter.setColorFilter(resources.getColor(R.color.logout_light));
        } else {
            isthemeDark = true
            tv_inprogress.setTextColor(resources.getColor(R.color.Secondary_text_color_lightred_Darktheme ))
            tv_filter.setTextColor(resources.getColor(R.color.white))
            iv_filter.setColorFilter(resources.getColor(R.color.white));
        }
        linearLayoutManager = LinearLayoutManager(mActivity)
        rcycl_transactions.layoutManager = linearLayoutManager
        onClick()

        localBroadcastManager = LocalBroadcastManager.getInstance(mActivity)
        getB_Receiver = ListUpdateBroadcast()
        lstFilter = IntentFilter(ConstantsUtils.updateTransactionList)

    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        super.setUserVisibleHint(isVisibleToUser)

        if (this.isVisible) {
            if (isVisibleToUser) {
                ConstantsUtils.isthemeCliked = false
                JavaWallet.mPreferenceDataModal.ISSHOW_VIEW = false
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                mActivity.isAcceptAuthRequestClicked = true
                getTrnasactionData()
            }
        }

    }


    override fun onResume() {
        super.onResume()
        if (mActivity.isInternetConnected()) {
            //   getCoinList("")
        } else {
            mActivity.showDialog(getString(R.string.network_error), false)
        }
        localBroadcastManager.registerReceiver(getB_Receiver, lstFilter)
    }

    override fun onPause() {
        super.onPause()
        localBroadcastManager.unregisterReceiver(getB_Receiver)
    }

    private fun getCoinList(word: String) {

        var rqst = SearchRequest(word)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        mActivity.apiServiceWithAuthorization.getCoinList(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error); })
    }

    fun getTrnasactionData() {
        JavaWallet.mPreferenceDataModal.TRANS_WALLET = mActivity.coin_type
        JavaWallet.mPreferenceDataModal.TRANS_STATUS = mActivity.status
        JavaWallet.mPreferenceDataModal.TRANS_TYPE = mActivity.trnx_type
        JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)

        var rqst = TransactionRequest(mActivity.coin_type,
                mActivity.trnx_type, mActivity.convertime(JavaWallet.mPreferenceDataModal.FROM_DATE), mActivity.convertime(JavaWallet.mPreferenceDataModal.TO_DATE), mActivity.status)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.apiServiceWithAuthorization.getTransaction(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error); })


    }

    private lateinit var adptr: TransactionAdapter

    private fun handleResponse(it: Any) {
        when (it) {
            is TransactionResponse -> {

                if (!isApply) {
                    getCoinList("")
                }
                isApply = false
                transactionlist = it.data
                tv_inprogress.text = "${transactionlist.size} Transactions"
                if (transactionlist.size > 0) {
                    rcycl_transactions.visibility = View.VISIBLE
                    tv_notrnstn.visibility = View.GONE
                    adptr = TransactionAdapter(transactionlist, isthemeDark)
                    rcycl_transactions.adapter = adptr
                } else {
                    rcycl_transactions.visibility = View.GONE
                    tv_notrnstn.visibility = View.VISIBLE
                }


            }

            is CoinListResponse -> {
                coinlisttemp.clear()
                coinlist.clear()
                coinlist = it.data

                for (i in 0 until coinlist.size) {
                    var mdl = CoinListData(coinlist[i].coinId, coinlist[i].coinName, coinlist[i].coinSymbol, coinlist[i].coinImage,
                            coinlist[i].coinStatus, coinlist[i].isToken, coinlist[i].coinStatus, coinlist[i].coin_gicko_alias,
                            coinlist[i].userCoinId, false)
                    coinlisttemp.add(mdl)

                }
            }
        }
    }


    private fun onClick() {
        rltv_fltr.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {

        when (p0) {
            rltv_fltr -> {
                if (mActivity.isInternetConnected()) {
                    showfilter()
                } else {
                    mActivity.showDialog(getString(R.string.network_error), false)
                }
            }
        }

    }

    private fun showfilter() {

        val mBottomSheetDialog = BottomSheetDialog(activity!!)
        val sheetView = activity!!.layoutInflater.inflate(R.layout.filter_dialog, null)
        mBottomSheetDialog.setContentView(sheetView)
        mBottomSheetDialog.setCancelable(false)
        mBottomSheetDialog.show()


        val tv_trans_date = mBottomSheetDialog.findViewById<View>(R.id.tv_trans_date) as AppCompatTextView
        val tv_trans_status = mBottomSheetDialog.findViewById<View>(R.id.tv_trans_status) as AppCompatTextView
        val tv_wallet = mBottomSheetDialog.findViewById<View>(R.id.tv_wallet) as AppCompatTextView
        val tv_trans_type = mBottomSheetDialog.findViewById<View>(R.id.tv_trans_type) as AppCompatTextView
        val iv_closedialog = mBottomSheetDialog.findViewById<View>(R.id.iv_closedialog) as AppCompatImageView
        val vw_transtype = mBottomSheetDialog.findViewById<View>(R.id.vw_transtype) as RelativeLayout
        val rccyl_wallet = mBottomSheetDialog.findViewById<View>(R.id.rccyl_wallet) as RecyclerView
        val vw_transstatus = mBottomSheetDialog.findViewById<View>(R.id.vw_transstatus) as RelativeLayout
        val vw_date = mBottomSheetDialog.findViewById<View>(R.id.vw_date) as RelativeLayout

        val tv_reset = mBottomSheetDialog.findViewById<View>(R.id.tv_reset) as AppCompatTextView
        val tv_apply = mBottomSheetDialog.findViewById<View>(R.id.tv_apply) as AppCompatTextView

        val tv_fromvalue = mBottomSheetDialog.findViewById<View>(R.id.tv_fromvalue) as AppCompatTextView
        val tv_tovalue = mBottomSheetDialog.findViewById<View>(R.id.tv_tovalue) as AppCompatTextView

        val iv_calendarfrom = mBottomSheetDialog.findViewById<View>(R.id.iv_calendarfrom) as AppCompatImageView
        val iv_calendarto = mBottomSheetDialog.findViewById<View>(R.id.iv_calendarto) as AppCompatImageView

        val cb_pending = mBottomSheetDialog.findViewById<View>(R.id.cb_pending) as CheckBox
        val cb_ready = mBottomSheetDialog.findViewById<View>(R.id.cb_ready) as CheckBox
        val cb_inprogress = mBottomSheetDialog.findViewById<View>(R.id.cb_inprogress) as CheckBox
        val cb_complete = mBottomSheetDialog.findViewById<View>(R.id.cb_complete) as CheckBox
        val cb_failed = mBottomSheetDialog.findViewById<View>(R.id.cb_failed) as CheckBox

        val cb_all = mBottomSheetDialog.findViewById<View>(R.id.cb_all) as CheckBox
        val cb_deposit = mBottomSheetDialog.findViewById<View>(R.id.cb_deposit) as CheckBox
        val cb_withdraw = mBottomSheetDialog.findViewById<View>(R.id.cb_withdraw) as CheckBox


        val linearLayoutManager = LinearLayoutManager(mActivity)
        rccyl_wallet.layoutManager = linearLayoutManager
        rccyl_wallet.adapter = FilterWalletAdapter(coinlisttemp, this)

        tv_fromvalue.text = JavaWallet.mPreferenceDataModal.FROM_DATE
        tv_tovalue.text = JavaWallet.mPreferenceDataModal.TO_DATE

        if (isthemeDark) {
            iv_closedialog.setColorFilter(resources.getColor(R.color.blacknew));
            iv_calendarfrom.setColorFilter(resources.getColor(R.color.white));
            iv_calendarto.setColorFilter(resources.getColor(R.color.white));
        } else {
            iv_closedialog.setColorFilter(resources.getColor(R.color.transtime_light));
            iv_calendarfrom.setColorFilter(resources.getColor(R.color.colorPrimaryDark_Lighttheme));
            iv_calendarto.setColorFilter(resources.getColor(R.color.colorPrimaryDark_Lighttheme));
        }

        var data = JavaWallet.mPreferenceDataModal.TRANS_TYPE

        for (i in 0 until data.size) {

            if (data[i].equals("All", true)) {
                if (isthemeDark) {
                    cb_all.setTextColor(resources.getColor(R.color.white))
                    cb_deposit.setTextColor(resources.getColor(R.color.white))
                    cb_withdraw.setTextColor(resources.getColor(R.color.white))
                } else {
                    cb_all.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                    cb_deposit.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                    cb_withdraw.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                }


                cb_all.isChecked = true
                cb_deposit.isChecked = true
                cb_withdraw.isChecked = true
            } else if (data[i].equals("Deposit", true)) {
                if (isthemeDark) {
                    cb_deposit.setTextColor(resources.getColor(R.color.white))
                } else {
                    cb_deposit.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                }

                cb_deposit.isChecked = true
            } else if (data[i].equals("Withdraw", true)) {
                if (isthemeDark) {
                    cb_withdraw.setTextColor(resources.getColor(R.color.white))
                } else {
                    cb_withdraw.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                }
                cb_withdraw.isChecked = true
            }
        }


        var datastat = JavaWallet.mPreferenceDataModal.TRANS_STATUS

        for (i in 0 until datastat.size) {
            if (isthemeDark) {
                if (datastat[i].equals("Pending", true)) {
                    cb_pending.setTextColor(resources.getColor(R.color.white))
                    cb_pending.isChecked = true
                } else if (datastat[i].equals("approved", true)) {
                    cb_ready.setTextColor(resources.getColor(R.color.white))
                    cb_ready.isChecked = true
                } else if (datastat[i].equals("signed", true)) {
                    cb_inprogress.setTextColor(resources.getColor(R.color.white))
                    cb_inprogress.isChecked = true
                } else if (datastat[i].equals("Complete", true)) {
                    cb_complete.setTextColor(resources.getColor(R.color.white))
                    cb_complete.isChecked = true
                } else if (datastat[i].equals("failed", true)) {
                    cb_failed.setTextColor(resources.getColor(R.color.white))
                    cb_failed.isChecked = true
                }
            } else {
                if (datastat[i].equals("Pending", true)) {
                    cb_pending.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                    cb_pending.isChecked = true
                } else if (datastat[i].equals("approved", true)) {
                    cb_ready.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                    cb_ready.isChecked = true
                } else if (datastat[i].equals("signed", true)) {
                    cb_inprogress.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                    cb_inprogress.isChecked = true
                } else if (datastat[i].equals("Complete", true)) {
                    cb_complete.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                    cb_complete.isChecked = true
                } else if (datastat[i].equals("failed", true)) {
                    cb_failed.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                    cb_failed.isChecked = true
                }
            }


        }


        if (isthemeDark) {
            tv_wallet.setBackgroundColor(getResources().getColor(R.color.light_red))
            tv_trans_type.setBackgroundColor(getResources().getColor(R.color.dark_red))
            tv_trans_status.setBackgroundColor(getResources().getColor(R.color.dark_red))
            tv_trans_date.setBackgroundColor(getResources().getColor(R.color.dark_red))
            /*
            tv_wallet.setBackgroundColor(getResources().getColor(R.color.qPrimary_text_colorwhite_Darktheme))
            tv_trans_type.setBackgroundColor(getResources().getColor(R.color.lightnewgrey))
            tv_trans_status.setBackgroundColor(getResources().getColor(R.color.lightnewgrey))
            tv_trans_date.setBackgroundColor(getResources().getColor(R.color.lightnewgrey))*/

            tv_wallet.setTextColor(getResources().getColor(R.color.blacknew))
            tv_trans_type.setTextColor(getResources().getColor(R.color.white))
            tv_trans_status.setTextColor(getResources().getColor(R.color.white))
            tv_trans_date.setTextColor(getResources().getColor(R.color.white))
        } else {
            tv_wallet.setTextColor(getResources().getColor(R.color.colorPrimary_Lighttheme))
            tv_trans_type.setTextColor(getResources().getColor(R.color.logout_light))
            tv_trans_status.setTextColor(getResources().getColor(R.color.logout_light))
            tv_trans_date.setTextColor(getResources().getColor(R.color.logout_light))

            tv_wallet.setBackgroundColor(getResources().getColor(R.color.white))
            tv_trans_type.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
            tv_trans_status.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
            tv_trans_date.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
        }

        tv_wallet.setOnClickListener {
            rccyl_wallet.visibility = View.VISIBLE
            vw_transtype.visibility = View.GONE
            vw_transstatus.visibility = View.GONE
            vw_date.visibility = View.GONE
            if (isthemeDark) {

                tv_wallet.setBackgroundColor(getResources().getColor(R.color.light_red))
                tv_trans_type.setBackgroundColor(getResources().getColor(R.color.dark_red))
                tv_trans_status.setBackgroundColor(getResources().getColor(R.color.dark_red))
                tv_trans_date.setBackgroundColor(getResources().getColor(R.color.dark_red))

                tv_wallet.setTextColor(getResources().getColor(R.color.blacknew))
                tv_trans_type.setTextColor(getResources().getColor(R.color.white))
                tv_trans_status.setTextColor(getResources().getColor(R.color.white))
                tv_trans_date.setTextColor(getResources().getColor(R.color.white))

            } else {
                tv_wallet.setTextColor(getResources().getColor(R.color.colorPrimary_Lighttheme))
                tv_trans_type.setTextColor(getResources().getColor(R.color.logout_light))
                tv_trans_status.setTextColor(getResources().getColor(R.color.logout_light))
                tv_trans_date.setTextColor(getResources().getColor(R.color.logout_light))

                tv_wallet.setBackgroundColor(getResources().getColor(R.color.white))
                tv_trans_type.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
                tv_trans_status.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
                tv_trans_date.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
            }


        }
        tv_trans_type.setOnClickListener {
            vw_transtype.visibility = View.VISIBLE
            rccyl_wallet.visibility = View.GONE
            vw_transstatus.visibility = View.GONE
            vw_date.visibility = View.GONE

            if (isthemeDark) {

                tv_trans_type.setBackgroundColor(getResources().getColor(R.color.light_red))
                tv_wallet.setBackgroundColor(getResources().getColor(R.color.dark_red))
                tv_trans_status.setBackgroundColor(getResources().getColor(R.color.dark_red))
                tv_trans_date.setBackgroundColor(getResources().getColor(R.color.dark_red))

                tv_wallet.setTextColor(getResources().getColor(R.color.white))
                tv_trans_type.setTextColor(getResources().getColor(R.color.blacknew))
                tv_trans_status.setTextColor(getResources().getColor(R.color.white))
                tv_trans_date.setTextColor(getResources().getColor(R.color.white))
            } else {

                tv_trans_type.setTextColor(getResources().getColor(R.color.colorPrimary_Lighttheme))
                tv_wallet.setTextColor(getResources().getColor(R.color.logout_light))
                tv_trans_status.setTextColor(getResources().getColor(R.color.logout_light))
                tv_trans_date.setTextColor(getResources().getColor(R.color.logout_light))

                tv_wallet.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
                tv_trans_type.setBackgroundColor(getResources().getColor(R.color.white))
                tv_trans_status.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
                tv_trans_date.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
            }


        }
        tv_trans_status.setOnClickListener {
            vw_transstatus.visibility = View.VISIBLE
            vw_transtype.visibility = View.GONE
            rccyl_wallet.visibility = View.GONE
            vw_date.visibility = View.GONE

            if (isthemeDark) {
                tv_trans_type.setBackgroundColor(getResources().getColor(R.color.dark_red))
                tv_wallet.setBackgroundColor(getResources().getColor(R.color.dark_red))
                tv_trans_status.setBackgroundColor(getResources().getColor(R.color.light_red))
                tv_trans_date.setBackgroundColor(getResources().getColor(R.color.dark_red))

                tv_wallet.setTextColor(getResources().getColor(R.color.white))
                tv_trans_type.setTextColor(getResources().getColor(R.color.white))
                tv_trans_status.setTextColor(getResources().getColor(R.color.blacknew))
                tv_trans_date.setTextColor(getResources().getColor(R.color.white))
            } else {
                tv_trans_status.setTextColor(getResources().getColor(R.color.colorPrimary_Lighttheme))
                tv_wallet.setTextColor(getResources().getColor(R.color.logout_light))
                tv_trans_type.setTextColor(getResources().getColor(R.color.logout_light))
                tv_trans_date.setTextColor(getResources().getColor(R.color.logout_light))

                tv_wallet.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
                tv_trans_type.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
                tv_trans_status.setBackgroundColor(getResources().getColor(R.color.white))
                tv_trans_date.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
            }


        }

        tv_trans_date.setOnClickListener {
            vw_date.visibility = View.VISIBLE
            vw_transstatus.visibility = View.GONE
            vw_transtype.visibility = View.GONE
            rccyl_wallet.visibility = View.GONE

            if (isthemeDark) {
                tv_trans_type.setBackgroundColor(getResources().getColor(R.color.dark_red))
                tv_wallet.setBackgroundColor(getResources().getColor(R.color.dark_red))
                tv_trans_status.setBackgroundColor(getResources().getColor(R.color.dark_red))
                tv_trans_date.setBackgroundColor(getResources().getColor(R.color.light_red))

                tv_wallet.setTextColor(getResources().getColor(R.color.white))
                tv_trans_type.setTextColor(getResources().getColor(R.color.white))
                tv_trans_status.setTextColor(getResources().getColor(R.color.white))
                tv_trans_date.setTextColor(getResources().getColor(R.color.blacknew))

            } else {
                tv_trans_date.setTextColor(getResources().getColor(R.color.colorPrimary_Lighttheme))
                tv_wallet.setTextColor(getResources().getColor(R.color.logout_light))
                tv_trans_type.setTextColor(getResources().getColor(R.color.logout_light))
                tv_trans_status.setTextColor(getResources().getColor(R.color.logout_light))

                tv_wallet.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
                tv_trans_type.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
                tv_trans_status.setBackgroundColor(getResources().getColor(R.color.walletlightstroke))
                tv_trans_date.setBackgroundColor(getResources().getColor(R.color.white))

            }


        }

        iv_closedialog.setOnClickListener {
            mBottomSheetDialog.dismiss()
        }

        tv_reset.setOnClickListener {
            isApply = false
            mActivity.trnx_type.clear()
            mActivity.status.clear()
            mActivity.coin_type.clear()
            JavaWallet.mPreferenceDataModal.TRANS_WALLET = mActivity.coin_type
            JavaWallet.mPreferenceDataModal.TRANS_STATUS = mActivity.status
            JavaWallet.mPreferenceDataModal.TRANS_TYPE = mActivity.trnx_type
            JavaWallet.mPreferenceDataModal.FROM_DATE = ""
            JavaWallet.mPreferenceDataModal.TO_DATE = ""
            JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
            mBottomSheetDialog.dismiss()
            getTrnasactionData()
        }

        tv_apply.setOnClickListener {

            if (!tv_fromvalue.text.toString().trim().equals("") && !tv_tovalue.text.toString().trim().equals("")) {
                if (!mActivity.CheckDates(tv_fromvalue.text.toString().trim(), tv_tovalue.text.toString().trim())) {
                    mActivity.showDialog("Please check your dates", false)
                } else {
                    isApply = true
                    mBottomSheetDialog.dismiss()
                    getTrnasactionData()
                }
            } else {
                isApply = true
                mBottomSheetDialog.dismiss()
                getTrnasactionData()
            }


        }
        iv_calendarfrom.setOnClickListener {

            val dpd = DatePickerDialog(activity, DatePickerDialog.OnDateSetListener
            { view, selectedYear, selectedMonth, selectedDay ->
                val calendar = Calendar.getInstance()
                calendar.set(selectedYear, selectedMonth, selectedDay)
                val format = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH) //MM/dd/yyyy  yyyy-MM-dd
                val strDate = format.format(calendar.time)
                tv_fromvalue.text = strDate


                JavaWallet.mPreferenceDataModal.FROM_DATE = strDate
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)

            }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH))
            dpd.getDatePicker().setMaxDate(System.currentTimeMillis())
            dpd.show()
        }

        iv_calendarto.setOnClickListener {

            val dpd = DatePickerDialog(activity, DatePickerDialog.OnDateSetListener
            { view, selectedYear, selectedMonth, selectedDay ->
                val calendar = Calendar.getInstance()
                calendar.set(selectedYear, selectedMonth, selectedDay)
                val format = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH) //MM/dd/yyyy  yyyy-MM-dd
                val strDate = format.format(calendar.time)
                tv_tovalue.text = strDate

                JavaWallet.mPreferenceDataModal.TO_DATE = strDate
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)

            }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH))
            // dpd.getDatePicker().setMinDate(System.currentTimeMillis())
            dpd.getDatePicker().setMaxDate(System.currentTimeMillis())
            dpd.show()
        }


        cb_all.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {

                if (isthemeDark) {
                    if (isChecked) {
                        cb_all.setTextColor(resources.getColor(R.color.blacknew))
                        cb_deposit.setTextColor(resources.getColor(R.color.blacknew))
                        cb_withdraw.setTextColor(resources.getColor(R.color.blacknew))
                        cb_deposit.isChecked = true
                        cb_withdraw.isChecked = true
                        mActivity.trnx_type.clear()
                        mActivity.trnx_type.add("all")
                    } else {
                        cb_all.setTextColor(resources.getColor(R.color.white))
                        cb_deposit.setTextColor(resources.getColor(R.color.white))
                        cb_withdraw.setTextColor(resources.getColor(R.color.white))
                        cb_deposit.isChecked = false
                        cb_withdraw.isChecked = false
                        mActivity.trnx_type.remove("all")
                    }
                } else {
                    if (isChecked) {
                        cb_all.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                        cb_deposit.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                        cb_withdraw.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                        cb_deposit.isChecked = true
                        cb_withdraw.isChecked = true
                        mActivity.trnx_type.clear()
                        mActivity.trnx_type.add("all")
                    } else {
                        cb_all.setTextColor(resources.getColor(R.color.transtime_light))
                        cb_deposit.setTextColor(resources.getColor(R.color.transtime_light))
                        cb_withdraw.setTextColor(resources.getColor(R.color.transtime_light))
                        cb_deposit.isChecked = false
                        cb_withdraw.isChecked = false
                        mActivity.trnx_type.remove("all")
                    }
                }

            }

        })

        cb_deposit.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {

                if (isthemeDark) {
                    if (isChecked) {
                        cb_deposit.setTextColor(resources.getColor(R.color.blacknew))
                        if (cb_withdraw.isChecked) {
                            cb_all.setTextColor(resources.getColor(R.color.blacknew))
                            cb_withdraw.setTextColor(resources.getColor(R.color.blacknew))
                            cb_all.isChecked = true
                            cb_withdraw.isChecked = true
                            mActivity.trnx_type.clear()
                            mActivity.trnx_type.add("all")
                        } else {
                            cb_deposit.setTextColor(resources.getColor(R.color.white))
                            mActivity.trnx_type.clear()
                            mActivity.trnx_type.add("deposit")
                        }

                    } else {
                        cb_deposit.setTextColor(resources.getColor(R.color.white))
                        cb_all.setTextColor(resources.getColor(R.color.white))
                        cb_all.isChecked = false
                        mActivity.trnx_type.clear()
                    }
                } else {
                    if (isChecked) {
                        cb_deposit.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                        if (cb_withdraw.isChecked) {
                            cb_all.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                            cb_withdraw.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                            cb_all.isChecked = true
                            cb_withdraw.isChecked = true
                            mActivity.trnx_type.clear()
                            mActivity.trnx_type.add("all")
                        } else {
                            cb_deposit.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                            mActivity.trnx_type.clear()
                            mActivity.trnx_type.add("deposit")
                        }

                    } else {
                        cb_deposit.setTextColor(resources.getColor(R.color.transtime_light))
                        cb_all.setTextColor(resources.getColor(R.color.transtime_light))
                        cb_all.isChecked = false
                        mActivity.trnx_type.clear()
                    }
                }


            }

        })

        cb_withdraw.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {

                if (isthemeDark) {
                    if (isChecked) {
                        cb_withdraw.setTextColor(resources.getColor(R.color.blacknew))

                        if (cb_deposit.isChecked) {
                            cb_all.setTextColor(resources.getColor(R.color.blacknew))
                            cb_deposit.setTextColor(resources.getColor(R.color.blacknew))
                            cb_all.isChecked = true
                            cb_withdraw.isChecked = true
                            cb_deposit.isChecked = true
                            mActivity.trnx_type.clear()
                            mActivity.trnx_type.add("all")
                        } else {
                            cb_withdraw.setTextColor(resources.getColor(R.color.white))
                            mActivity.trnx_type.clear()
                            mActivity.trnx_type.add("withdraw")
                        }

                    } else {
                        cb_withdraw.setTextColor(resources.getColor(R.color.white))
                        cb_all.setTextColor(resources.getColor(R.color.white))
                        cb_all.isChecked = false
                        mActivity.trnx_type.clear()
                    }
                } else {
                    if (isChecked) {
                        cb_withdraw.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))

                        if (cb_deposit.isChecked) {
                            cb_all.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                            cb_deposit.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                            cb_all.isChecked = true
                            cb_withdraw.isChecked = true
                            cb_deposit.isChecked = true
                            mActivity.trnx_type.clear()
                            mActivity.trnx_type.add("all")
                        } else {
                            cb_withdraw.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                            mActivity.trnx_type.clear()
                            mActivity.trnx_type.add("withdraw")
                        }

                    } else {
                        cb_withdraw.setTextColor(resources.getColor(R.color.transtime_light))
                        cb_all.setTextColor(resources.getColor(R.color.transtime_light))
                        cb_all.isChecked = false
                        mActivity.trnx_type.clear()
                    }
                }


            }

        })
        cb_pending.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {

                if (isthemeDark) {
                    if (isChecked) {
                        cb_pending.setTextColor(resources.getColor(R.color.blacknew))
                        mActivity.status.add("pending")
                    } else {
                        cb_pending.setTextColor(resources.getColor(R.color.white))
                        mActivity.status.remove("pending")
                    }
                } else {
                    if (isChecked) {
                        cb_pending.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                        mActivity.status.add("pending")
                    } else {
                        cb_pending.setTextColor(resources.getColor(R.color.transtime_light))
                        mActivity.status.remove("pending")
                    }
                }

            }

        })

        cb_ready.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {
                if (isthemeDark) {
                    if (isChecked) {
                        cb_ready.setTextColor(resources.getColor(R.color.blacknew))
                        mActivity.status.add("approved")
                    } else {
                        cb_ready.setTextColor(resources.getColor(R.color.white))
                        mActivity.status.remove("approved")
                    }
                } else {
                    if (isChecked) {
                        cb_ready.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                        mActivity.status.add("approved")
                    } else {
                        cb_ready.setTextColor(resources.getColor(R.color.transtime_light))
                        mActivity.status.remove("approved")
                    }
                }


            }

        })
        cb_inprogress.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {
                if (isthemeDark) {
                    if (isChecked) {
                        cb_inprogress.setTextColor(resources.getColor(R.color.blacknew))
                        mActivity.status.add("unconfirmed")
                        mActivity.status.add("signed")
                    } else {
                        cb_inprogress.setTextColor(resources.getColor(R.color.white))
                        mActivity.status.remove("unconfirmed")
                        mActivity.status.remove("signed")
                    }
                } else {
                    if (isChecked) {
                        cb_inprogress.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                        mActivity.status.add("unconfirmed")
                        mActivity.status.add("signed")
                    } else {
                        cb_inprogress.setTextColor(resources.getColor(R.color.transtime_light))
                        mActivity.status.remove("unconfirmed")
                        mActivity.status.remove("signed")
                    }
                }

            }

        })
        cb_complete.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {
                if (isthemeDark) {
                    if (isChecked) {
                        cb_complete.setTextColor(resources.getColor(R.color.blacknew))
                        mActivity.status.add("complete")
                    } else {
                        cb_complete.setTextColor(resources.getColor(R.color.white))
                        mActivity.status.remove("complete")
                    }
                } else {
                    if (isChecked) {
                        cb_complete.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                        mActivity.status.add("complete")
                    } else {
                        cb_complete.setTextColor(resources.getColor(R.color.transtime_light))
                        mActivity.status.remove("complete")
                    }
                }

            }

        })
        cb_failed.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {
                if (isthemeDark) {
                    if (isChecked) {
                        cb_failed.setTextColor(resources.getColor(R.color.blacknew))
                        mActivity.status.add("rejected")
                        mActivity.status.add("failed")
                    } else {
                        cb_failed.setTextColor(resources.getColor(R.color.white))
                        mActivity.status.remove("rejected")
                        mActivity.status.remove("failed")
                    }
                } else {
                    if (isChecked) {
                        cb_failed.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                        mActivity.status.add("rejected")
                        mActivity.status.add("failed")
                    } else {
                        cb_failed.setTextColor(resources.getColor(R.color.transtime_light))
                        mActivity.status.remove("rejected")
                        mActivity.status.remove("failed")
                    }
                }

            }

        })


    }

    override fun onCoin_Click(walletlist: CoinListData, is_clc: Boolean) {

        if (is_clc) {
            mActivity.coin_type.add(walletlist.coinSymbol)
        } else {
            mActivity.coin_type.remove(walletlist.coinSymbol)
        }
    }


}