package com.JavaWallet.ui.fragments


import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.*
import android.os.Bundle
import android.support.design.widget.BottomSheetBehavior
import kotlinx.android.synthetic.main.wallet_frag.*
import android.support.design.widget.BottomSheetDialog
import android.support.design.widget.CoordinatorLayout
import android.view.*
import android.widget.FrameLayout
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.support.v4.app.DialogFragment
import android.support.v4.content.LocalBroadcastManager
import android.support.v4.view.ViewPager
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.animation.*
import android.widget.RelativeLayout
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import com.JavaWallet.*
import com.JavaWallet.Adapters.TransactionAdapterLimit
import com.JavaWallet.Adapters.WalletPagerAdapter
import com.JavaWallet.Adapters.WalletPagerAdapterData
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.Utilities.EndlessPagerAdapter
import com.JavaWallet.Utilities.PermissionCheck
import com.JavaWallet.networking.*
import com.JavaWallet.ui.activities.*
import kotlinx.android.synthetic.main.request_dialog.*
import kotlinx.android.synthetic.main.walletcoin_pager.*
import kotlinx.android.synthetic.main.walletscrollitem.*
import org.json.JSONArray
import java.util.*
import kotlin.collections.ArrayList
import com.JavaWallet.Utilities.ViewAnimationUtils;

class Wallet_frag : BaseFragment(), View.OnClickListener, View.OnTouchListener, PermissionInterface, WalletPagerAdapterData.Listner {

    private lateinit var admin_address: String
    private var pgr_position: Int = 0

    private var current_price: String = "0"
    private var current_pricedata: String = "0"
    private lateinit var transactionListView: RelativeLayout
    private var currentPage: Int = 0
    private var istotaladded: Boolean = false
    private var usd_total: Double = 0.0
    private lateinit var mBottomSheetDialog: BottomSheetDialog
    private var acceptDecline_Status: Int = 1
    internal val MIN_DISTANCE = 40
    var DownPT = PointF() // Record Mouse Position When Pressed Down
    var StartPT = PointF() // Record Start Position of 'img'
    var OrginalPT = PointF()
    var OrginalPT1 = PointF()
    var OrginalPT2 = PointF()
    var position = 0
    var isSwipUp = false
    var isValueSet = false
    var shouldClick = false

    lateinit var pCheck: PermissionCheck

    lateinit var walletlist: ArrayList<ManageWalletData>
    lateinit var authrequestlist: ArrayList<WithdrawauthData>
    private lateinit var linearLayoutManager: LinearLayoutManager
    private var isthemeDark: Boolean = false

    lateinit var transactionlist: ArrayList<TransactionsWalletData>

    var isshowauthfromnotification = false


    private lateinit var pgrAdptr: WalletPagerAdapter
    private lateinit var pgrAdptrdata: WalletPagerAdapterData


    private lateinit var localBroadcastManager: LocalBroadcastManager
    private lateinit var getB_Receiver: BalanceUpdateBroadcast
    private lateinit var balanceFilter: IntentFilter

    inner class BalanceUpdateBroadcast : BroadcastReceiver() {

        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ConstantsUtils.updatetBalance) {
                if (mActivity.isInternetConnected()) {
                    if (!JavaWallet.mPreferenceDataModal.JWTToken.equals("")) {
                        istotaladded = false
                        usd_total = 0.0
                        getWalletList()
                    }
                }
            }
        }
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.wallet_frag, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view!!, savedInstanceState)
        ConstantsUtils.isthemeCliked = false
        rlSlide1.visibility = View.GONE
        rlSlide2.visibility = View.GONE
        rlSlide3.visibility = View.GONE
        setPager(total_val)
        onClick()
        mBottomSheetDialog = BottomSheetDialog(activity!!)
        linearLayoutManager = LinearLayoutManager(mActivity)
        recycl_transaction.layoutManager = linearLayoutManager
        recycl_transaction.isNestedScrollingEnabled = false
        pCheck = PermissionCheck(mActivity, this)
        if (mActivity.isInternetConnected()) {
            if (JavaWallet.mPreferenceDataModal.JWTToken.equals("")) {
                createUserApi()
            }
        } else {
            mActivity.showDialog(getString(R.string.network_error), false)
        }

        localBroadcastManager = LocalBroadcastManager.getInstance(mActivity)
        getB_Receiver = BalanceUpdateBroadcast()
        balanceFilter = IntentFilter(ConstantsUtils.updatetBalance)

    }


    override fun onResume() {
        super.onResume()

        if (Utility.getTheme(mActivity).equals(mActivity.THEME_DARK)) {
            iv_menu.setColorFilter(resources.getColor(R.color.white));
            iv_all.setColorFilter(resources.getColor(R.color.Secondary_text_color_lightblue_Darktheme));
            tv_recent.setTextColor(resources.getColor(R.color.Secondary_text_color_lightblue_Darktheme))
            tv_all.setTextColor(resources.getColor(R.color.Secondary_text_color_lightblue_Darktheme))
            isthemeDark = true
        } else if (Utility.getTheme(mActivity).equals(mActivity.THEME_LIGHT)) {
            iv_menu.setColorFilter(resources.getColor(R.color.logout_light));
            iv_all.setColorFilter(resources.getColor(R.color.white));
            tv_recent.setTextColor(resources.getColor(R.color.white))
            tv_all.setTextColor(resources.getColor(R.color.white))
            isthemeDark = false
        } else {
            iv_menu.setColorFilter(resources.getColor(R.color.white));
            iv_all.setColorFilter(resources.getColor(R.color.Secondary_text_color_lightblue_Darktheme));
            tv_recent.setTextColor(resources.getColor(R.color.Secondary_text_color_lightblue_Darktheme))
            tv_all.setTextColor(resources.getColor(R.color.Secondary_text_color_lightblue_Darktheme))
            isthemeDark = true
        }


        JavaWallet.mPreferenceDataModal.ISSIGNIN = true
        JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
        if (mActivity.isInternetConnected()) {
            if (!JavaWallet.mPreferenceDataModal.JWTToken.equals("")) {
                getWalletList()
            }
        } else {
            mActivity.showDialog(getString(R.string.network_error), false)
        }
        if (mActivity.isNFC()) {
            iv_nfc.alpha = 1.0f
            iv_nfc.isEnabled = true
        } else {
            iv_nfc.alpha = 0.4f
            iv_nfc.isEnabled = false
        }
        nsvmain.parent.requestDisallowInterceptTouchEvent(true);
        localBroadcastManager.registerReceiver(getB_Receiver, balanceFilter)

    }

    private fun disableCoinsApi() {

        var rqst = disablecoinRequest(JavaWallet.mPreferenceDataModal.DEVICEToken, 0)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.apiServiceWithAuthorization.disablewallets(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error);mActivity.hideLoading() })
    }

    override fun onPause() {
        super.onPause()
        localBroadcastManager.unregisterReceiver(getB_Receiver)

    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        super.setUserVisibleHint(isVisibleToUser)

        if (this.isVisible) {
            if (isVisibleToUser) {
                if (ConstantsUtils.ISUPDATEBALANCE) {
                    ConstantsUtils.ISUPDATEBALANCE = false
                    if (mActivity.isInternetConnected()) {
                        if (!JavaWallet.mPreferenceDataModal.JWTToken.equals("")) {
                            istotaladded = false
                            usd_total = 0.0
                            getWalletList()
                        }
                    }
                }
            }
        }

    }

    private fun onClick() {
        ivwallet_add.setOnClickListener(this)
        rltv_manage.setOnClickListener(this)
        rltv_bottomgreen.setOnClickListener(this)
        iv_closepopup.setOnClickListener(this)
    }


    fun startAnimation() {
        var anim = TranslateAnimation(0f, 0f,
                0f, -15f)
        anim.duration = 800
        anim.isFillEnabled = true
        anim.fillAfter = true
        anim.interpolator = LinearInterpolator()
        anim.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationRepeat(p0: Animation?) {
            }

            override fun onAnimationEnd(p0: Animation?) {
                var animRepeat = TranslateAnimation(0f, 0f,
                        -15f, 0f)
                animRepeat.duration = 800
                animRepeat.isFillEnabled = true
                animRepeat.fillBefore = true
                animRepeat.interpolator = LinearInterpolator()
                animRepeat.setAnimationListener(object : Animation.AnimationListener {
                    override fun onAnimationRepeat(p0: Animation?) {

                    }

                    override fun onAnimationEnd(p0: Animation?) {
                        if (!mActivity.isAcceptAuthRequestClicked) {
                            startAnimation()
                        }
                    }

                    override fun onAnimationStart(p0: Animation?) {
                    }

                })
                rltv_bottomgreen.animation = animRepeat
            }

            override fun onAnimationStart(p0: Animation?) {
            }
        })
        rltv_bottomgreen.animation = anim

    }


    private fun createUserApi() {
        var rqst = createUserRequest()
        rqst.address = JavaWallet.mPreferenceDataModal.COIN_ADDRESS
        rqst.type = "eth"
        rqst.is_active = ConstantsUtils.isActive
        rqst.device_token = JavaWallet.mPreferenceDataModal.DEVICEToken
        rqst.device_type = 1
        rqst.is_production = 0


        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.showLoading()
        mActivity.apiServiceWithAuthorization.createUser(cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error);mActivity.hideLoading() })
    }

    private fun getWalletList() {
        mActivity.apiServiceWithAuthorization.managewallet(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error);mActivity.hideLoading() })

    }

    public fun getAuthRequestApi(tx_id: Int, from: String) {
        if (mBottomSheetDialog.isShowing) {
            mBottomSheetDialog.dismiss()
        }
        //isshowauthfromnotification = tx_id != 0
        if (tx_id == 0) {
            isshowauthfromnotification = false
        } else {
            if (from.equals(getString(R.string.fromNotifctnListClick))) {
                isshowauthfromnotification = true
            } else if (from.equals(getString(R.string.frombroadcast))) {
                mActivity.isAcceptAuthRequestClicked = false
                isshowauthfromnotification = false
            }
        }
        var rqst = authwithdrawRequest(tx_id)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.apiServiceWithAuthorization.checkWithdrawAuthReqests(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error);mActivity.hideLoading() })
    }

    private fun AcceptdeclineAuthApi(status: Int) {
        acceptDecline_Status = status
        var rqst = AcceptDeclineAuthRequest(authrequestlist[0].fromId, authrequestlist[0].withdrawCosignReqId, status,
                authrequestlist[0].trnxWithdrawId)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.apiServiceWithAuthorization.AcceptDeclineAuthReqests(JavaWallet.mPreferenceDataModal.JWTToken, authrequestlist[0].coinSymbol, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error);mActivity.hideLoading() })

    }

    private fun upDateToken() {

        var rqst = TokenRequest(JavaWallet.mPreferenceDataModal.DEVICEToken, 1, 0)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.apiServiceWithAuthorization.updateuserdevicetoken(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error) })
    }

    private fun handleResponse(it: Any) {
        when (it) {
            is CreateUserResponse -> {
                mActivity.hideLoading()
                if (it.status) {
                    JavaWallet.mPreferenceDataModal.JWTToken = it.data.jwtToken
                    JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                   /* mActivity.getCoinList()
                    Handler().postDelayed({
                        getWalletList()
                    }, 1500)*/

                    disableCoinsApi()

                } else {
                    mActivity.showDialog(it.message, false)
                }
            }
            is ManageWalletResponse -> {

                if (it.status) {
                    admin_address=it.admin_address
                    walletlist = it.data

                    for (i in 0 until walletlist.size) {
                        if (walletlist[i].coinSymbol.equals("btc", true)) {
                            JavaWallet.mPreferenceDataModal.BTC_BALANCE = walletlist[i].balance
                            JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                        } else if (walletlist[i].coinSymbol.equals("eth", true)) {
                            JavaWallet.mPreferenceDataModal.ETH_BALANCE = walletlist[i].balance
                            JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                        }

                    }

                    if (walletlist.size > 2) {
                        pgrAdptrdata = WalletPagerAdapterData(mActivity, walletlist, this)
                        // Disable clip to padding
                        wallet_datapager.setClipToPadding(false);
                        // set padding manually, the more you set the padding the more you see of prev & next page
                        wallet_datapager.setPadding(85, 0, 85, 0);
                        // sets a margin b/w individual pages to ensure that there is a gap b/w them
                        wallet_datapager.setPageMargin(20);
                        val endlessPagerAdapter = EndlessPagerAdapter(pgrAdptrdata, wallet_datapager);
                        wallet_datapager.adapter = endlessPagerAdapter
                        wallet_datapager.setCurrentItem(1)
                        // wallet_datapager.setPageTransformer(true, PageTransformer());
                        updateTotal()

                    } else {
                        pgrAdptrdata = WalletPagerAdapterData(mActivity, walletlist, this)
                        // Disable clip to padding
                        wallet_datapager.setClipToPadding(false);
                        // set padding manually, the more you set the padding the more you see of prev & next page
                        wallet_datapager.setPadding(60, 0, 60, 0);
                        // sets a margin b/w individual pages to ensure that there is a gap b/w them
                        wallet_datapager.setPageMargin(20);
                        wallet_datapager.adapter = pgrAdptrdata
                        updateTotal()

                    }

                    wallet_datapager?.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {

                        override fun onPageScrollStateChanged(state: Int) {
                        }

                        override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {


                        }

                        override fun onPageSelected(position: Int) {
                            pgr_position = position
                            Log.e("w_pos", "" + pgr_position)

                        }

                    })
                    upDateToken()
                    /* makeDynamicView()
                     rlSlide3.setOnTouchListener(this)*/

                    if (walletlist.size > 0) {
                        tv_walletsize.visibility = View.VISIBLE
                        tv_addnewwallet.visibility = View.GONE
                        wallet_datapager.visibility = View.VISIBLE
                        rltv_manage.visibility = View.VISIBLE
                        if (walletlist.size == 0 || walletlist.size == 1) {
                            tv_walletsize.text = "${walletlist.size} Wallet"
                        } else {
                            tv_walletsize.text = "${walletlist.size} Wallets"
                        }
                    } else {
                        tv_walletsize.visibility = View.GONE
                        tv_addnewwallet.visibility = View.VISIBLE
                        rltv_manage.visibility = View.GONE
                        wallet_datapager.visibility = View.GONE
                    }
                    getAuthRequestApi(0, "")
                }
            }
            is WithdrawauthResponse -> {
                if (it.status) {
                    authrequestlist = it.data
                    if (isshowauthfromnotification) {
                        showAuthPopup()
                    } else {
                        if (authrequestlist.size > 0) {
                            rltv_bottomgreen.visibility = View.VISIBLE
                            startAnimation()
                        } else {
                            rltv_bottomgreen.visibility = View.GONE
                        }

                    }
                }
            }
            is Authacceptresponse -> {
                if (it.status) {
                    if (acceptDecline_Status == 1) {
                        mActivity.showDialog("Authentication Request approved successfully.", false)
                    } else if (acceptDecline_Status == 2) {
                        mActivity.showDialog("Authentication Request declined successfully.", false)
                    }
                    mActivity.isAcceptAuthRequestClicked = false
                    getAuthRequestApi(0, "")

                }

            }
            is updateTokenResponse -> {
                if (it.status) {

                }
            }

            is BaseResponse -> {
                if (it.status) {
                    mActivity.getCoinList()
                    Handler().postDelayed({
                        getWalletList()
                    }, 1500)
                }
            }


        }
    }


    private lateinit var transaction_adptr: TransactionAdapterLimit

    override fun onTouch(swipeRl: View, event: MotionEvent): Boolean {
        val eid = event.action
        when (eid) {
            MotionEvent.ACTION_MOVE -> {
                rlMain.parent.requestDisallowInterceptTouchEvent(true)
                val mv = PointF(event.x, event.y - DownPT.y)
                val UpPT = PointF(DownPT.x, DownPT.y - event.y)
                val deltaY = UpPT.y

                // swipe vertical?
                if (Math.abs(deltaY) > MIN_DISTANCE) {
                    shouldClick = false
                    // top or down
                    val movePlusY = (StartPT.y + mv.y).toInt()
                    if (deltaY < 0) {
                        Handler(Looper.getMainLooper()).post {
                            if (!isValueSet) {
                                isSwipUp = true
                                swipeRl.translationY = movePlusY.toFloat()
                                rlSlide1.translationY = OrginalPT1.y + (JavaWallet.height / 40.32).toInt()
                                rlSlide2.translationY = OrginalPT2.y - (JavaWallet.height / 15.53).toInt()
                                StartPT = PointF(swipeRl.x, swipeRl.translationY)
                                if (swipeRl.translationY >= (JavaWallet.height / 26.92).toInt()) {
                                    rlSlide2.alpha = 1.0f
                                } else {
                                    swipeRl.alpha = 1.0f
                                    rlSlide1.alpha = 1.0f
                                    rlSlide2.alpha = 0.6f
                                }

                                if (swipeRl.translationY >= (JavaWallet.height / 25.23).toInt()) {
                                    Handler(Looper.getMainLooper()).post {
                                        isValueSet = true
                                        swipeRl.alpha = 1.0f
                                        swipeRl.translationY = (OrginalPT.y)
                                        rlSlide1.translationY = OrginalPT1.y
                                        rlSlide2.translationY = OrginalPT2.y
                                        if (position == 0) {
                                            position = walletlist.size - 1
                                        } else {
                                            position--
                                        }
                                        makeDynamicView()
                                    }
                                }
                            }
                        }
                        return true
                    }
                    if (deltaY > 0) {
                        Handler(Looper.getMainLooper()).post {
                            if (!isValueSet) {
                                isSwipUp = false
                                swipeRl.translationY = (movePlusY.toFloat())
                                rlSlide1.translationY = OrginalPT1.y + (JavaWallet.height / 25.23).toInt()
                                rlSlide2.translationY = OrginalPT2.y - (JavaWallet.height / 100.95).toInt()
                                StartPT = PointF(swipeRl.x, swipeRl.translationY)

                                if (swipeRl.translationY <= -(JavaWallet.height / 26.92).toInt()) {
                                    rlSlide1.alpha = 1.0f
                                } else {
                                    swipeRl.alpha = 1.0f
                                    rlSlide1.alpha = 0.6f
                                    rlSlide2.alpha = 0.6f
                                }
                                if (swipeRl.translationY <= -(JavaWallet.height / 25.23).toInt()) {
                                    Handler(Looper.getMainLooper()).post {
                                        isValueSet = true
                                        swipeRl.alpha = 1.0f
                                        swipeRl.translationY = (OrginalPT.y)
                                        rlSlide1.translationY = OrginalPT1.y
                                        rlSlide2.translationY = OrginalPT2.y
                                        if (position == walletlist.size - 1) {
                                            position = 0
                                        } else {
                                            position++
                                        }
                                        makeDynamicView()
                                    }
                                    ;
                                }
                            }
                        }
                        return true
                    }
                } else {
                }
            }
            MotionEvent.ACTION_DOWN -> {
                shouldClick = true
                DownPT.y = event.y
                StartPT = PointF(swipeRl.x, swipeRl.translationY)
                OrginalPT = PointF(swipeRl.x, swipeRl.translationY)
                OrginalPT1 = PointF(rlSlide1.x, rlSlide1.translationY)
                OrginalPT2 = PointF(rlSlide2.x, rlSlide2.translationY)
                isValueSet = false
            }
            MotionEvent.ACTION_UP -> {
                Handler(Looper.getMainLooper()).post {
                    if (shouldClick) {
                        if (rltv_trnsctn.visibility == View.GONE) {
                            rltv_options.visibility = View.VISIBLE
                            ViewAnimationUtils.expand(rltv_trnsctn)
                            rlSlide3.setOnTouchListener(null)
                            transactionlist = walletlist.get(position).transactions
                            if (transactionlist.size > 0) {
                                rltv_subitem.visibility = View.VISIBLE
                                transaction_adptr = TransactionAdapterLimit(transactionlist, isthemeDark, this)
                                recycl_transaction.adapter = transaction_adptr
                            } else {
                                try {
                                    transactionlist.clear()
                                    rltv_subitem.visibility = View.GONE
                                    transaction_adptr = TransactionAdapterLimit(transactionlist, isthemeDark, this)
                                    recycl_transaction.adapter = transaction_adptr
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
//                            nsvmain.isSmoothScrollingEnabled = false
//                            var bitmap = Bitmap.createBitmap(mActivity.window.decorView.rootView.drawingCache)
//                            var canvas = Canvas(bitmap)
//                            var scale = resources.displayMetrics.density
//                            var p = Paint()
//                            p.color = Color.BLUE
//                            p.textSize = 48 * scale
//                            canvas.drawText("Hello", (mActivity.window.windowManager.defaultDisplay.width / 2).toFloat(),
//                                    (mActivity.window.windowManager.defaultDisplay.height / 2).toFloat(), p)
//                         //   imageView.setImageBitmap(imageBitmap)
                            nsvmain.isEnableScrolling = false
                            ivwallet_add.visibility = View.GONE


                            Handler().postDelayed({
                                nsvmain.fullScroll(View.FOCUS_DOWN)

                            }, 400)
//                            nsvmain.fullScroll(View.FOCUS_DOWN)
                        }
                    } else {

                        if (!isValueSet) {
                            isValueSet = true
                            if (isSwipUp) {
                                if (swipeRl.translationY >= (JavaWallet.height / 25.23).toInt()) {
                                    if (position == 0) {
                                        position = walletlist.size - 1
                                    } else {
                                        position--
                                    }
                                    makeDynamicView()
                                }
                            } else {
                                if (swipeRl.translationY <= -(JavaWallet.height / 25.23).toInt()) {
                                    if (position == walletlist.size - 1) {
                                        position = 0
                                    } else {
                                        position++
                                    }
                                    makeDynamicView()
                                }
                            }
                        }
                    }
                }
                swipeRl.alpha = 1.0f
                rlSlide1.alpha = 0.6f
                rlSlide2.alpha = 0.6f

                swipeRl.translationY = (OrginalPT.y)
                rlSlide1.translationY = OrginalPT1.y
                rlSlide2.translationY = OrginalPT2.y

            }

        }
        return true
    }

    fun makeDynamicView() {

        if (walletlist.size == 0) {
            rlSlide1.visibility = View.GONE
            rlSlide2.visibility = View.GONE
            rlSlide3.visibility = View.GONE
        } else if (walletlist.size == 1) {
            rlSlide1.visibility = View.GONE
            rlSlide2.visibility = View.GONE
            rlSlide3.visibility = View.VISIBLE
            //me tvSlide3
            centerItem()
        } else if (walletlist.size == 2) {
            rlSlide1.visibility = View.VISIBLE
            rlSlide2.visibility = View.GONE
            rlSlide3.visibility = View.VISIBLE
            if (position == 0) {
                bottomItem(walletlist.size - 1)
            } else {
                bottomItem(position - 1)
            }
            //me tvSlide3
            centerItem()
        } else {
            rlSlide1.visibility = View.VISIBLE
            rlSlide2.visibility = View.VISIBLE
            rlSlide3.visibility = View.VISIBLE
            if (position == 0) {
                bottomItem(walletlist.size - 1)
            } else {
                bottomItem(position - 1)
            }
            //me tvSlide3
            centerItem()
            if (position == walletlist.size - 1) {
                topItem(0)
            } else {
                topItem(position + 1)
            }
        }

    }

    fun centerItem() {

    }


    private fun updateTotal() {
        //  istotaladded = true
        usd_total = 0.0
        try {
//            walletlist.sumBy { it.balance * }
            for (i in 0 until walletlist.size) {

                if (!JavaWallet.mPreferenceDataModal.CRYPTODATA.equals("")) {
                    val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.CRYPTODATA)
                    try {
                        for (j in 0 until jsonarray.length()) {
                            var jsnobj = jsonarray.getJSONObject(j)
                            if (walletlist[i].coinSymbol.equals(jsnobj.getString("symbol"))) {

                                var v = mActivity.decimalConverterUpto(walletlist[i].balance, 8)
                                var vv = v.replace(",", ".")
                                val j = jsnobj.getString("current_price").toString().replace(",", ".")
                                usd_total = usd_total + mActivity.decimalConverterUpto((vv.toDouble()) * (j.toDouble()), 2).replace(",", ".").toDouble()

                            }
                        }

                        if(walletlist[i].coinSymbol.equals( "upl")){
                            var v = mActivity.decimalConverterUpto(walletlist[i].balance, 8)
                            var vv = v.replace(",", ".")
                            val j = JavaWallet.mPreferenceDataModal.uplvalue
                            usd_total = usd_total + mActivity.decimalConverterUpto((vv.toDouble()) * (j.toDouble()), 2).replace(",", ".").toDouble()

                        }

                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                }
            }
            setPager(usd_total)
        } catch (e: Exception) {
            e.printStackTrace()
        }


    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        pCheck.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun permissionAccepted() {
        val intent = Intent(activity!!, QrcodeScannerActivity::class.java)
        activity!!.startActivityForResult(intent, mActivity.WALLET_QRCODE)
        closeFullview()

        // mActivity.callActivityforResult(QrcodeScannerActivity::class.java, mActivity.WALLET_QRCODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == mActivity.WALLET_QRCODE && resultCode == Activity.RESULT_OK) {

            dataWithAddress(data, "wallet", "address")

        }
    }

    public fun dataWithAddress(data: Intent?, from: String, address: String) {
        if (!JavaWallet.mPreferenceDataModal.CRYPTODATA.equals("")) {
            val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.CRYPTODATA)
            try {
                //  for (i in 0 until jsonObject.length()) {
                /*  var jsnobj = jsonObject.getJSONObject(walletlist[position].coinSymbol.toUpperCase())
                  var jUSD = jsnobj.getJSONObject(JavaWallet.mPreferenceDataModal.DefaultCurrency)*/
                if (walletlist.size < 3) {

                } else {
                    if (pgr_position == 0) {
                        pgr_position = 0
                    } else {
                        pgr_position = pgr_position - 1
                    }
                }

                for (i in 0 until jsonarray.length()) {
                    var jsnobj = jsonarray.getJSONObject(i)
                    if (walletlist[pgr_position].coinSymbol.equals(jsnobj.getString("symbol"))) {
                        current_pricedata = jsnobj.getString("current_price")
                        break
                    } else {
                        current_pricedata = "0"
                    }
                }
                var bndl = Bundle()
                bndl.putString(getString(R.string.coin_name), walletlist[pgr_position].coinName)
                bndl.putString(getString(R.string.coinamount_crypto), "" + mActivity.decimalConverterUpto(walletlist[pgr_position].balance, 8) + " " + walletlist[pgr_position].coinSymbol.toUpperCase())
                bndl.putString(getString(R.string.coinamount_fiat), mActivity.decimalConverterUpto(((walletlist[pgr_position].balance) * (current_pricedata.toDouble())), 2) +
                        " " + walletlist[pgr_position].currencyCode)
                bndl.putString(getString(R.string.coin_icon), walletlist[pgr_position].coinImage)
                bndl.putString(getString(R.string.coin_sym), walletlist[pgr_position].coinSymbol.toUpperCase())
                if (from.equals("wallet")) {
                    bndl.putString(getString(R.string.coin_address), data?.getStringExtra(ConstantsUtils.QRCODE))
                } else {
                    bndl.putString(getString(R.string.coin_address), address)
                }

                bndl.putString(getString(R.string.current_price), current_pricedata)
                bndl.putString(getString(R.string.token_address), walletlist[pgr_position].tokenAddress)
                bndl.putString("decimals", walletlist[pgr_position].decimals.toString())

                bndl.putDouble("min_fee", walletlist[pgr_position].min_fee)
                bndl.putDouble("max_fee", walletlist[pgr_position].max_fee)
                bndl.putString("percentage_fee", walletlist[pgr_position].percentage_fee)
                bndl.putString("admin_address",admin_address)
                bndl.putString("wallet_address",walletlist[pgr_position].wallet_address)

                mActivity.callActivityWithData(Send::class.java, bndl)
                closeFullview()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    }

    fun topItem(position: Int) {
        tv_name_one.text = walletlist[position].coinName
        mActivity.loadPicture_circle(iv_icon_one, JavaWallet.IMAGEBASE_URL + walletlist[position].coinImage)
    }


    fun bottomItem(position: Int) {
        tv_name_two.text = walletlist[position].coinName
        mActivity.loadPicture_circle(iv_icon_two, JavaWallet.IMAGEBASE_URL + walletlist[position].coinImage)
    }


    private var total_val: Double = 0.00
    private fun setPager(total_val: Double) {
        pgrAdptr = WalletPagerAdapter(mActivity, JavaWallet.mPreferenceDataModal.ISSHOW_VIEW, total_val)
        wallet_vpager.adapter = pgrAdptr
        indicator.setViewPager(wallet_vpager);
        if (JavaWallet.mPreferenceDataModal.ISSHOW_VIEW) {
            indicator.visibility = View.VISIBLE
        } else {
            indicator.visibility = View.INVISIBLE
        }


    }

    override fun onClick(p0: View?) {
        when (p0) {
            ivwallet_add -> {
                position = 0

                mActivity.startNewActivity(AddNewWallet())
                closeFullview()
            }
            rltv_manage -> {

                position = 0
                mActivity.startNewActivity(ManageWallet())
                closeFullview()
            }

            rltv_bottomgreen -> {

                rltv_bottomgreen.visibility = View.GONE
                showAuthPopup()

            }
            iv_closepopup -> {
                closeFullview()

            }
        }
    }

    public fun closeFullview() {

        if (rltv_trnsctn.visibility == View.VISIBLE) {
            rltv_options.visibility = View.GONE
            ivwallet_add.visibility = View.VISIBLE
            ViewAnimationUtils.collapse(rltv_trnsctn)
            rlSlide3.setOnTouchListener(this)
            nsvmain.isEnableScrolling = true
        }
    }

    @SuppressLint("ValidFragment")
    inner class FullWallet : DialogFragment() {
        override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
            return super.onCreateView(inflater, container, savedInstanceState)
            val window = getDialog().getWindow();
            // set "origin" to top left corner, so to speak
            window.setGravity(Gravity.BOTTOM);
            window.setDimAmount(0.70f);
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
            val view = inflater.inflate(R.layout.walletcoin_pager, container, false);
            initViews(view);
            return view;
        }

        private fun initViews(view: View) {


        }

    }


    override fun onData_Click(position: Int, view: RelativeLayout, mainView: RelativeLayout) {

        /* Blurry.with(context).radius(10).sampling(2)
                 .async()
                 .capture(rlMainLay)
                 .into(blr_img)*/


        val location = IntArray(2)
        wallet_datapager.getLocationOnScreen(location)
        val x = location[0]
        val size_y = location[1]
        var rectangle = Rect();
        val window_status = mActivity.window
        window_status.getDecorView().getWindowVisibleDisplayFrame(rectangle);
        var statusBarHeight = rectangle.top
        showFulldialog(position, size_y - statusBarHeight)
        /* val w_dialog = FullWallet()
         w_dialog.show(fragmentManager, "")*/
    }

    private fun showFulldialog(position: Int, size_y: Int) {

        var dialog = Dialog(mActivity)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        dialog.window.setDimAmount(0.8f)


        val windw = dialog.window.attributes
        windw.gravity = Gravity.TOP
        windw.y = size_y


        dialog.setContentView(R.layout.walletcoin_pager)

        dialog.rltv_options.visibility = View.VISIBLE
        dialog.rltv_trnsctn.visibility = View.GONE

        ViewAnimationUtils.expand(dialog.rltv_trnsctn)


        linearLayoutManager = LinearLayoutManager(mActivity)
        dialog.recycl_transaction.layoutManager = linearLayoutManager

        transactionlist = walletlist.get(position).transactions
        if (transactionlist.size > 0) {
            dialog.rltv_subitem.visibility = View.VISIBLE
            transaction_adptr = TransactionAdapterLimit(transactionlist, isthemeDark, this)
            dialog.recycl_transaction.adapter = transaction_adptr
        } else {
            try {
                transactionlist.clear()
                dialog.rltv_subitem.visibility = View.GONE
                transaction_adptr = TransactionAdapterLimit(transactionlist, isthemeDark, this)
                dialog.recycl_transaction.adapter = transaction_adptr
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }


        dialog.iv_closepopup.setOnClickListener {

            ViewAnimationUtils.collapse(dialog.rltv_trnsctn)

            try {
                Handler(Looper.getMainLooper()).postDelayed(Runnable { dialog.dismiss() }, 300)

            } catch (e: Exception) {
                e.toString()
            }


            /* Blurry.with(context).radius(1).sampling(1)
                     .async()
                     .capture(blr_imgremove)
                     .into(blr_img)*/
        }


        if (mActivity.isNFC()) {
            dialog.iv_nfc.alpha = 1.0f
            dialog.iv_nfc.isEnabled = true
        } else {
            dialog.iv_nfc.alpha = 0.4f
            dialog.iv_nfc.isEnabled = false
        }


        if (isthemeDark) {
            dialog.iv_all.setColorFilter(resources.getColor(R.color.black));
            dialog.tv_recent.setTextColor(resources.getColor(R.color.black))
            dialog.tv_all.setTextColor(resources.getColor(R.color.black))
        } else {

            dialog.iv_all.setColorFilter(resources.getColor(R.color.white));
            dialog.tv_recent.setTextColor(resources.getColor(R.color.white))
            dialog.tv_all.setTextColor(resources.getColor(R.color.white))
        }

        dialog.tv_name.text = walletlist[position].coinName

        /*try{
            if(walletlist[position].coinImage==null){
                dialog.iv_currency.visibility=View.INVISIBLE
                tv_roundw.visibility=View.VISIBLE
                tv_roundw.text=walletlist.get(position).walletlist.substring(0,1);
            }else{
                dialog.iv_currency.visibility=View.VISIBLE
                tv_roundw.visibility=View.GONE


            }

        }catch (e:Exception){
            e.printStackTrace()
        }*/

        val rnd = Random()
        val color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
        try {
            if (walletlist[position].coinImage == null) {
                dialog.iv_currency.visibility = View.INVISIBLE
                dialog.tv_roundWlt.visibility = View.VISIBLE
                val bgShape = dialog.tv_roundWlt.getBackground() as GradientDrawable
                bgShape.setColor(color)
                dialog.tv_roundWlt.text = walletlist.get(position).coinName.substring(0, 1);
            } else {
                dialog.iv_currency.visibility = View.VISIBLE
                dialog.tv_roundWlt.visibility = View.GONE
                mActivity.loadPicture_circle(dialog.iv_currency, JavaWallet.IMAGEBASE_URL + walletlist[position].coinImage)

            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        dialog.tv_balancecrypto.text = "" + mActivity.decimalConverterUpto(walletlist[position].balance, 8) + " " + walletlist[position].coinSymbol.toUpperCase()
        if (!JavaWallet.mPreferenceDataModal.CRYPTODATA.equals("")) {
            try {
                val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.CRYPTODATA)
                if(jsonarray.length()==0){
                    if(walletlist[position].coinSymbol.equals( "upl")){

                        if (JavaWallet.mPreferenceDataModal.uplpercenr > 0) {
                            dialog.tv_crncystatus.text = (mActivity as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplpercenr, 2) + "%"
                            dialog.tv_crncystatus.setTextColor(mActivity.resources.getColor(R.color.qPrimary_text_colorwhite_Darktheme))
                            dialog.iv_status.setImageDrawable(mActivity.resources.getDrawable(R.drawable.ic_bitcoin_currency_arrow))
                        } else {
                            dialog.tv_crncystatus.text = (mActivity as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplpercenr, 2) + "%"
                            dialog.tv_crncystatus.setTextColor(mActivity.resources.getColor(R.color.red))
                            dialog.iv_status.setImageDrawable(mActivity.resources.getDrawable(R.drawable.down_red))
                        }
                        dialog.tv_balancefiat.text =
                                (mActivity as BaseActivity).decimalConverterUpto(((walletlist[position].balance) * (JavaWallet.mPreferenceDataModal.uplvalue)), 2) +
                                        " " + walletlist[position].currencyCode
                        dialog.tv_marketvalue.text = "= " + (mActivity as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplvalue, 2) + " " + JavaWallet.mPreferenceDataModal.DefaultCurrency
                        current_price = JavaWallet.mPreferenceDataModal.uplvalue.toString()


                    }

                }else{
                    for (i in 0 until jsonarray.length()) {
                        var jsnobj = jsonarray.getJSONObject(i)
                        if (walletlist[position].coinSymbol.equals(jsnobj.getString("symbol"))) {
                            if (jsnobj.getString("price_change_percentage_24h").toDouble() > 0) {
                                dialog.tv_crncystatus.text = mActivity.decimalConverterUpto(jsnobj.getString("price_change_percentage_24h").toDouble(), 2) + "%"
                                dialog.tv_crncystatus.setTextColor(mActivity.resources.getColor(com.JavaWallet.R.color.qPrimary_text_colorwhite_Darktheme))
                                dialog.iv_status.setImageDrawable(mActivity.resources.getDrawable(com.JavaWallet.R.drawable.ic_bitcoin_currency_arrow))
                            } else {
                                /* dialog.tv_crncystatus.text = (mActivity as BaseActivity).decimalConverterUpto(jsnobj.getString("price_change_percentage_24h").replace("-", "").toDouble(), 2) + "%"
                                 dialog.tv_crncystatus.setTextColor(mActivity.resources.getColor(com.JavaWallet.R.color.red))
                                 dialog.iv_status.setImageDrawable(mActivity.resources.getDrawable(com.JavaWallet.R.drawable.down_red))
                            */
                                if (Utility.getTheme(WalletPagerAdapterData.mContext).equals("dark")) {
                                    dialog.tv_crncystatus.text = (WalletPagerAdapterData.mContext as BaseActivity).decimalConverterUpto(jsnobj.getString("price_change_percentage_24h").replace("-","").toDouble(), 2) + "%"
                                    dialog.tv_crncystatus.setTextColor(WalletPagerAdapterData.mContext.resources.getColor(R.color.dark_grey))
                                    dialog.iv_status.setImageDrawable(WalletPagerAdapterData.mContext.resources.getDrawable(R.drawable.ic_arrow_drop_down))

                                } else {
                                    dialog.tv_crncystatus.text = (WalletPagerAdapterData.mContext as BaseActivity).decimalConverterUpto(jsnobj.getString("price_change_percentage_24h").replace("-","").toDouble(), 2) + "%"
                                    dialog.tv_crncystatus.setTextColor(WalletPagerAdapterData.mContext.resources.getColor(R.color.red))
                                    dialog.iv_status.setImageDrawable(WalletPagerAdapterData.mContext.resources.getDrawable(R.drawable.down_red))
                                }

                            }
                            dialog.tv_balancefiat.text =
                                    mActivity.decimalConverterUpto(((walletlist[position].balance) * (jsnobj.getString("current_price").toDouble())), 2) +
                                            " " + walletlist[position].currencyCode
                            current_price = jsnobj.getString("current_price")
                            dialog.tv_marketvalue.text = "= " + mActivity.decimalConverterUpto(jsnobj.getString("current_price").toDouble(), 8) + " " + JavaWallet.mPreferenceDataModal.DefaultCurrency
                            break
                        } else if(walletlist[position].coinSymbol.equals( "upl")){
                            if (JavaWallet.mPreferenceDataModal.uplpercenr > 0) {
                                dialog.tv_crncystatus.text = (mActivity as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplpercenr, 2) + "%"
                                dialog.tv_crncystatus.setTextColor(mActivity.resources.getColor(R.color.qPrimary_text_colorwhite_Darktheme))
                                dialog.iv_status.setImageDrawable(mActivity.resources.getDrawable(R.drawable.ic_bitcoin_currency_arrow))
                            } else {
                                dialog.tv_crncystatus.text = (mActivity as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplpercenr, 2) + "%"
                                dialog.tv_crncystatus.setTextColor(mActivity.resources.getColor(R.color.red))
                                dialog.iv_status.setImageDrawable(mActivity.resources.getDrawable(R.drawable.down_red))
                            }
                            dialog.tv_balancefiat.text =
                                    (mActivity as BaseActivity).decimalConverterUpto(((walletlist[position].balance) * (JavaWallet.mPreferenceDataModal.uplvalue)), 2) +
                                            " " + walletlist[position].currencyCode
                            dialog.tv_marketvalue.text = "= " + (mActivity as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplvalue, 2) + " " + JavaWallet.mPreferenceDataModal.DefaultCurrency
                            current_price = JavaWallet.mPreferenceDataModal.uplvalue.toString()

                        }


                        else {
                            current_price = "0"
                        }

                    }
                }



                dialog.lnr_send.setOnClickListener {
                    var bndl = Bundle()
                    bndl.putString(getString(R.string.coin_name), walletlist[position].coinName)
                    bndl.putString(getString(R.string.coinamount_crypto), "" + mActivity.decimalConverterUpto(walletlist[position].balance, 8) + " " + walletlist[position].coinSymbol.toUpperCase())
                    bndl.putString(getString(R.string.coinamount_fiat), mActivity.decimalConverterUpto(((walletlist[position].balance) * (current_price.toDouble())), 2) +
                            " " + walletlist[position].currencyCode)
                    bndl.putString(getString(R.string.coin_icon), walletlist[position].coinImage)
                    bndl.putString(getString(R.string.coin_sym), walletlist[position].coinSymbol.toUpperCase())
                    bndl.putString(getString(R.string.current_price), current_price)
                    bndl.putString(getString(R.string.token_address), walletlist[position].tokenAddress)
                    bndl.putString("decimals", walletlist[position].decimals.toString())

                    bndl.putDouble("min_fee", walletlist[position].min_fee)
                    bndl.putDouble("max_fee", walletlist[position].max_fee)
                    bndl.putString("percentage_fee", walletlist[position].percentage_fee)
                    bndl.putString("admin_address",admin_address)
                    bndl.putString("wallet_address",walletlist[position].wallet_address)
                    mActivity.callActivityWithData(Send::class.java, bndl)
                    closeDialog(dialog)
                }
                dialog.lnr_receive.setOnClickListener {
                    var bndl = Bundle()
                    bndl.putString(getString(R.string.coin_name), walletlist[position].coinName)
                    bndl.putString(getString(R.string.coinamount_crypto), "" + mActivity.decimalConverterUpto(walletlist[position].balance, 8) + " " + walletlist[position].coinSymbol.toUpperCase())
                    bndl.putString(getString(R.string.coinamount_fiat), mActivity.decimalConverterUpto(((walletlist[position].balance) * (current_price.toDouble())), 2) +
                            " " + walletlist[position].currencyCode)
                    bndl.putString(getString(R.string.coin_icon), walletlist[position].coinImage)
                    bndl.putString(getString(R.string.coin_sym), walletlist[position].coinSymbol.toUpperCase())
                    bndl.putString("wallet_address",walletlist[position].wallet_address)
                    mActivity.callActivityWithData(Receive::class.java, bndl)
                    closeDialog(dialog)
                }
                dialog.tv_all.setOnClickListener {
                    var bndl = Bundle()
                    bndl.putString(getString(R.string.coinSymbol), walletlist[position].coinSymbol)
                    bndl.putString(getString(R.string.coinName), walletlist[position].coinName)
                    mActivity.callActivityWithData(Transaction_activity::class.java, bndl)
                    closeDialog(dialog)


                }
                dialog.iv_all.setOnClickListener {
                    var bndl = Bundle()
                    bndl.putString(getString(R.string.coinSymbol), walletlist[position].coinSymbol)
                    bndl.putString(getString(R.string.coinName), walletlist[position].coinName)
                    mActivity.callActivityWithData(Transaction_activity::class.java, bndl)
                    closeDialog(dialog)

                }
                dialog.iv_qrcode.setOnClickListener {
                    pCheck.checkPermission(arrayOf(android.Manifest.permission.CAMERA), this)

                }

                dialog.iv_nfc.setOnClickListener {
                    mActivity.enbleNfc()
                    if (mActivity.mNfcAdapter_base.isEnabled) {
                        mActivity.mNfcReadFragmentbase = NFCReadFragment.newInstance("frag")
                        mActivity.mNfcReadFragmentbase.show(mActivity.fragmentManager, NFCReadFragment.TAG)
                    } else {
                        mActivity.showDialog(getString(R.string.enablenfc), false)
                    }

                }
            } catch (e: Exception) {
                e.printStackTrace()
                dialog.tv_crncystatus.text = "0.00 " + JavaWallet.mPreferenceDataModal.DefaultCurrency
                dialog.tv_crncystatus.setTextColor(resources.getColor(R.color.green))
                dialog.iv_status.setImageDrawable(mActivity.resources.getDrawable(R.drawable.ic_bitcoin_currency_arrow))
                dialog.tv_balancefiat.text = "0.00 " + walletlist[position].currencyCode
                dialog.tv_marketvalue.text = "= 0.00 " + JavaWallet.mPreferenceDataModal.DefaultCurrency
            }
        }





        dialog.show()

    }

    private fun closeDialog(dialog: Dialog) {
        try {
            Handler(Looper.getMainLooper()).postDelayed(Runnable { dialog.dismiss() }, 1000)
        } catch (e: Exception) {
            e.toString()
        }
    }

    private fun showAuthPopup() {
        mActivity.isAcceptAuthRequestClicked = true

        val sheetView = activity!!.layoutInflater.inflate(R.layout.request_dialog, null)
        mBottomSheetDialog.setContentView(sheetView)

//              mBottomSheetDialog.setCancelable(false)
        val params = (sheetView.getParent() as View).layoutParams as CoordinatorLayout.LayoutParams
        params.setMargins(65, 0, 65, 0)
        (sheetView.getParent() as View).setBackgroundColor(getResources().getColor(android.R.color.transparent))

        mBottomSheetDialog.setOnShowListener(DialogInterface.OnShowListener { dialog ->
            val d = dialog as BottomSheetDialog
            val bottomSheet = d.findViewById<View>(android.support.design.R.id.design_bottom_sheet) as FrameLayout?
            BottomSheetBehavior.from(bottomSheet!!).state = BottomSheetBehavior.STATE_EXPANDED
        })

        mBottomSheetDialog.show()


        mBottomSheetDialog.tv_authusername.text = "${authrequestlist[0].fromName} Sent you"
        mBottomSheetDialog.tv_time.text = mActivity.convertUTCtoDeviceZone(authrequestlist[0].createdAt, "dd MMM, yyyy ' | 'hh:mm a")
        mBottomSheetDialog.tv_fromaddress.text = authrequestlist[0].fromAdrs
        mBottomSheetDialog.tv_toaddress.text = authrequestlist[0].toAdrs
        mBottomSheetDialog.tv_cryptoamount.text = "" + mActivity.decimalConverterUpto(authrequestlist[0].amount,8) + " " + authrequestlist[0].coinSymbol
        if (!authrequestlist[0].fromName.equals("")) {
            mBottomSheetDialog.tv_fromname.text = "From: ${authrequestlist[0].fromName}"
        } else {
            mBottomSheetDialog.tv_fromname.text = "From"
        }
        if (!authrequestlist[0].toName.equals("")) {
            mBottomSheetDialog.tv_toname.text = "To: ${authrequestlist[0].toName}"
        } else {
            mBottomSheetDialog.tv_toname.text = "To"
        }
        if (!JavaWallet.mPreferenceDataModal.CRYPTODATA.equals("")) {
            val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.CRYPTODATA)
            try {
                for (i in 0 until jsonarray.length()) {
                    var jsnobj = jsonarray.getJSONObject(i)
                    if (authrequestlist[0].coinSymbol.equals(jsnobj.getString("symbol"))) {
                        mBottomSheetDialog.tv_usdamount.text = mActivity.decimalConverterUpto(((authrequestlist[0].amount) * (jsnobj.getString("current_price").toDouble())), 2) +
                                " " + walletlist[position].currencyCode
                    }
                }

//                var jsnobj = jsonObject.getJSONObject(walletlist[position].coinSymbol.toUpperCase())
//                jUSD = jsnobj.getJSONObject(JavaWallet.mPreferenceDataModal.DefaultCurrency)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        mBottomSheetDialog.tv_authenticate.setOnClickListener {
            mBottomSheetDialog.dismiss()
            AcceptdeclineAuthApi(1)
        }
        mBottomSheetDialog.tv_decline.setOnClickListener {
            mBottomSheetDialog.dismiss()
            AcceptdeclineAuthApi(2)
        }
        mBottomSheetDialog.iv_closedialog.setOnClickListener {
            mBottomSheetDialog.dismiss()
            if (authrequestlist.size > 0) {
                rltv_bottomgreen.visibility = View.VISIBLE
                if (authrequestlist.size > 1) {
                    mActivity.isAcceptAuthRequestClicked = false
                    startAnimation()
                }
            } else {
                rltv_bottomgreen.visibility = View.GONE
            }
        }

    }


}