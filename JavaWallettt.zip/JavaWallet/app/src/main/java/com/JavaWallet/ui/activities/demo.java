package com.JavaWallet.ui.activities;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.JavaWallet.R;


public class demo extends AppCompatActivity {


    EditText edtMobileNo, edtMessage;
    Button btnSend, btnClear;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.demo);


        edtMessage = (EditText) findViewById(R.id.edtMessage);
        edtMobileNo = (EditText) findViewById(R.id.edtMobileNo);

        btnClear = (Button) findViewById(R.id.btnClear);
        btnSend = (Button) findViewById(R.id.btnSend);


        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               /* ERC20 contract = ERC20.load(tokenAddress, web3j, txManager, gasPriceProvider);
                BigInteger balance = contract.balanceOf(account).send();*/



            }
        });


    }
    public static boolean isValidAddress(String addr)
    {
        String regex = "^0x[0-9a-f]{40}$";

        //Print for testing purpose and more verbose output
        System.out.println("Incoming Address " + addr);

        if(addr.matches(regex))
        {
            return true;
        }
        return false;

    }


}
