package com.JavaWallet.Adapters

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.TextView
import com.JavaWallet.BaseActivity
import com.JavaWallet.R
import com.JavaWallet.networking.ReceiveAuthReq
import kotlinx.android.synthetic.main.recive_item.view.*
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

/**
 * Created by user on 11/4/19.
 */

class RequsetReceived_Adapter(private val userlist: ArrayList<ReceiveAuthReq>, private val lstnr: RequsetReceived_Adapter.InviteListner) : RecyclerView.Adapter< RequsetReceived_Adapter.ViewHolder>() {
    private lateinit var mContext: Context

    interface InviteListner {
        fun onaccept_Click(userlist: ArrayList<ReceiveAuthReq>, position: Int, isremove: Boolean)
        fun ondecline_Click(userlist: ArrayList<ReceiveAuthReq>, position: Int, isremove: Boolean)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RequsetReceived_Adapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.recive_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder: RequsetReceived_Adapter.ViewHolder, position: Int) {
        var listdata = userlist.get(position)
        holder.itemView.tv_name.text = listdata.fromUser.name
        holder.itemView.tv_number.text = listdata.fromUser.mobile

        var oldfa_date=(mContext as BaseActivity).convertUTCtoDeviceZone(listdata.updatedAt, "MM/dd/yyyy HH:mm:ss")
        val sdf = SimpleDateFormat("MM/dd/yyyy HH:mm:ss")
        val c = Calendar.getInstance()
        try {
            c.time = sdf.parse(oldfa_date)
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        c.add(Calendar.DATE, 1);
        var newDate = sdf.format(c.getTime());

        val c_new = Calendar.getInstance()
        var diff = (mContext as BaseActivity).getHoursminutes(sdf.format(c_new.getTime()),newDate)

// status = 1 accepted
        if (listdata.status == 1) {
            holder.itemView.lnr_deleted.visibility = View.GONE
            holder.itemView.lnr_active.visibility = View.VISIBLE

            holder.itemView.tv_remove.visibility = View.VISIBLE
            holder.itemView.lnritem.visibility = View.GONE
            holder.itemView.receive_time.visibility = View.GONE
            holder.itemView.tv_invite.text = "Active  "
            holder.itemView.tv_invite.setTextColor(mContext.resources.getColor(R.color.greenbottom))
        } else if (listdata.status == 3) {
            holder.itemView.lnr_deleted.visibility = View.VISIBLE
            holder.itemView.lnr_active.visibility = View.GONE
            holder.itemView.tv_timediffrecv.text=diff
            holder.itemView.itemm.alpha=0.5f

        } else if (listdata.status == 0) {
            holder.itemView.lnr_deleted.visibility = View.GONE
            holder.itemView.lnr_active.visibility = View.VISIBLE

            holder.itemView.tv_remove.visibility = View.GONE
            holder.itemView.lnritem.visibility = View.VISIBLE
            holder.itemView.receive_time.visibility = View.VISIBLE
            holder.itemView.tv_invite.text = "Invitation Received"
            holder.itemView.tv_invite.setTextColor(mContext.resources.getColor(R.color.white))
        }
        holder.itemView.receive_time.text = (mContext as BaseActivity).convertUTCtoDeviceZone(listdata.createdAt, "dd-MM-yyyy")

        holder.itemView.tv_intial.text = listdata.label.get(0).toUpperCase().toString()
        holder.itemView.tv_accept.setOnClickListener {

            var dialog = Dialog(mContext)
            dialog.setCancelable(false)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setContentView(R.layout.logout_dialog)
            val dialog_message = dialog.findViewById<View>(R.id.dialog_message) as TextView
            val dialog_yes = dialog.findViewById<View>(R.id.dialog_yes) as TextView
            val dialog_no = dialog.findViewById<View>(R.id.dialog_no) as TextView
            dialog_message.text = "Do you want to accept Invitation from  ${listdata.fromUser.name}?"
            dialog_yes.setOnClickListener {
                dialog.dismiss()
                lstnr.onaccept_Click(userlist, position, false)

            }
            dialog_no.setOnClickListener { dialog.dismiss() }
            dialog.show()
        }

        holder.itemView.tv_decline.setOnClickListener {
            var dialog = Dialog(mContext)
            dialog.setCancelable(false)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setContentView(R.layout.logout_dialog)
            val dialog_message = dialog.findViewById<View>(R.id.dialog_message) as TextView
            val dialog_yes = dialog.findViewById<View>(R.id.dialog_yes) as TextView
            val dialog_no = dialog.findViewById<View>(R.id.dialog_no) as TextView
            dialog_message.text = "Do you want to decline Invitation from  ${listdata.fromUser.name}?"
            dialog_yes.setOnClickListener {
                dialog.dismiss()
                lstnr.ondecline_Click(userlist, position, false)

            }
            dialog_no.setOnClickListener { dialog.dismiss() }
            dialog.show()


        }
        holder.itemView.tv_remove.setOnClickListener {

            var dialog = Dialog(mContext)
            dialog.setCancelable(false)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setContentView(R.layout.logout_dialog)
            val dialog_message = dialog.findViewById<View>(R.id.dialog_message) as TextView
            val dialog_yes = dialog.findViewById<View>(R.id.dialog_yes) as TextView
            val dialog_no = dialog.findViewById<View>(R.id.dialog_no) as TextView
            dialog_message.text = "Do you want to remove  ${listdata.fromUser.name}?"
            dialog_yes.setOnClickListener {
                dialog.dismiss()
                lstnr.ondecline_Click(userlist, position, true)

            }
            dialog_no.setOnClickListener { dialog.dismiss() }
            dialog.show()

        }


    }

    override fun getItemCount(): Int {
        return userlist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context
        }

        fun bindItems() {

        }
    }
}