package com.JavaWallet.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.R
import kotlinx.android.synthetic.main.mnemonic_item.view.*

/**
 * Created by user on 11/4/19.
 */

class MnemonicsConfirmAdptr(private val addresslist: List<String>, private val lstnr:  MnemonicListnerConfirm) : RecyclerView.Adapter< MnemonicsConfirmAdptr.ViewHolder>() {

    private lateinit var mContext: Context

    interface MnemonicListnerConfirm {
        fun onconfirm_Click(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.mnemonic_item_confirm, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val listdata = addresslist.get(position)

        holder.itemView.m_txt.text = addresslist.get(position)

            holder.itemView.setOnClickListener {
                lstnr.onconfirm_Click(position)

        }


    }

    override fun getItemCount(): Int {
        return addresslist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context
        }

        fun bindItems() {

        }
    }
}