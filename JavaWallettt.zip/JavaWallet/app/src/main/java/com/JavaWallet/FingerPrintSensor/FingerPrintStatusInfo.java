package com.JavaWallet.FingerPrintSensor;

/**
 * Created by Ravneet Singh on 10/1/18.
 */

public class FingerPrintStatusInfo {

    public static int FINGER_PRINT_NO_SUPPORTED=0;
    public static int FINGER_PRINT_OTHER_ERROR=1;
}
