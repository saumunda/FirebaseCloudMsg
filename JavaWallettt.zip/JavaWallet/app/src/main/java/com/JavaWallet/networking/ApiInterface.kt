package com.JavaWallet.networking

import com.JavaWallet.ConstantsUtils
import com.google.gson.JsonElement
import io.reactivex.Observable
import retrofit2.http.*

/**
 * Created by user on 10/5/19.
 */
interface ApiInterface {


    @FormUrlEncoded
    @POST(ConstantsUtils.CREATEUSER_URL)
    fun createUser(@Field("data") model: String): Observable<CreateUserResponse>

    @POST(ConstantsUtils.GETCURRENCYLIST_URL)
    fun getCurrencyList(@Header("Authorization") token: String): Observable<CurrencyListResponse>

    @POST(ConstantsUtils.BackupcosignerStatus)
    fun getBackupwalletStatus(@Header("Authorization") token: String): Observable<BaseResponse>

    @POST(ConstantsUtils.BackupcosignerList)
    fun getBackupCosignerList(@Header("Authorization") token: String): Observable<BackupcosignerlistResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.backuprequestcosigneragain)
    fun BackupCosignerRequestAgain(@Header("Authorization") Authorization: String, @Field("data") model: String): Observable<BaseResponse>


    @FormUrlEncoded
    @POST(ConstantsUtils.SAVEUSERCURRENCY_URL)
    fun saveUserCurrencyList(@Header("Authorization") Authorization: String, @Field("data") model: String): Observable<BaseResponse>

    @POST(ConstantsUtils.MANAGEWALLET_URL)
    fun managewallet(@Header("Authorization") token: String): Observable<ManageWalletResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.GETOINLIST_URL)
    fun getCoinList(@Header("Authorization") token: String, @Field("data") search: String): Observable<CoinListResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.DISABLECOIN_URL)
    fun disablecoin(@Header("Authorization") token: String,@Field("data") search: String): Observable<BaseResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.CREATEADDRESS_URL)
    fun createAddress(@Header("Authorization") token: String, @Field("data") search: String): Observable<BaseResponse>

    /*@GET(ConstantsUtils.multiful)
    fun getCryptoComapre(@Query("fsyms") fsym: String, @Query("tsyms") tsym: String): Observable<JsonElement>*/

    @GET(ConstantsUtils.multiful)
    fun getCryptoComapre(@Query("ids") fsym: String, @Query("vs_currency") tsym: String): Observable<JsonElement>

    @GET(ConstantsUtils.contractAddress)
    fun getCustomToken(@Query("contractaddress") contractaddress: String): Observable<ContractResponse>


    @FormUrlEncoded
    @POST(ConstantsUtils.SETWITHDRAWLIMIT_URL)
    fun setWithdrawLimit(@Header("Authorization") token: String, @Field("data") search: String): Observable<BaseResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.ADDADDRESS_URL)
    fun addAddres(@Header("Authorization") token: String, @Field("data") search: String): Observable<BaseResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.GETADDADDRESS_URL)
    fun getAddreses(@Header("Authorization") token: String, @Field("data") search: String): Observable<AddressResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.REMOVEADDADDRESS_URL)
    fun removeAddreses(@Header("Authorization") token: String, @Field("data") payee_id: String): Observable<BaseResponsenew>


    @FormUrlEncoded
    @POST(ConstantsUtils.gasEstimation)
    fun gasEstimation(@Header("Authorization") authorization: String, @Path("coin") coin: String, @Field("data") payee_id: String): Observable<GasResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.gasNonce)
    fun getNonce(@Header("Authorization") authorization: String, @Path("coin") coin: String,
                 @Field("data") amount: String): Observable<NonceResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.withdrawauthreqacceptdecline)
    fun AcceptDeclineAuthReqests(@Header("Authorization") authorization: String,@Path("coin") coin: String,
                                 @Field("data") data: String): Observable<Authacceptresponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.send)
    fun sendCoin(@Header("Authorization") authorization: String, @Path("coin") coin: String,
                 @Field("data") model: String): Observable<SendResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.GETTRANSACTION_URL)
    fun getTransaction(@Header("Authorization") authorization: String,  @Field("data") data: String): Observable<TransactionResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.sendafterauthbycosign)
    fun sendCoinbycosign(@Header("Authorization") authorization: String,  @Field("data") data: String): Observable<SendResponse>


    @FormUrlEncoded
    @POST(ConstantsUtils.deletetransaction)
    fun deleteTransaction(@Header("Authorization") authorization: String, @Path("coin") coin: String,
                 @Field("data") model: String): Observable<BaseResponse>

    @POST(ConstantsUtils.sentthreefactorauthreq_URL)
    fun sentthreefactorauthreq(@Header("Authorization") authorization: String): Observable<SentThreeFaqResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.GETTRANSACTIONDETAIL_URL)
    fun getTransactionDetail(@Header("Authorization") authorization: String,@Field("data") data: String): Observable<TransactionDetailResponse>


    @FormUrlEncoded
    @POST(ConstantsUtils.GETRAWDATA_URL)
    fun getERCDATA(@Header("Authorization") authorization: String,@Field("data") data: String): Observable<ErcDataResponse>


    @FormUrlEncoded
    @POST(ConstantsUtils.threefactorauthlinkrefcode)
    fun addReferalCode(@Header("Authorization") authorization: String,@Field("data") data: String): Observable<BaseResponse>


    @FormUrlEncoded
    @POST(ConstantsUtils.GETCOUNTRYCODE_URL)
    fun getCountryCode(@Header("Authorization") authorization: String,@Field("data") data: String): Observable<CountryCodeResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.resendnotification)
    fun requestAgain(@Header("Authorization") authorization: String,@Field("data") data: String): Observable<BaseResponsenew>

    @POST(ConstantsUtils.GETREFERCODE_URL)
    fun getReferCode(@Header("Authorization") authorization: String): Observable<ReferCodeResponse>

    @POST(ConstantsUtils.receivedthreefactorauthreq)
    fun getReceivedRequests(@Header("Authorization") authorization: String): Observable<ReceivedRequestsResponse>


    @FormUrlEncoded
    @POST(ConstantsUtils.invitethreefactorauth_url)
    fun invite_ThreeFactor(@Header("Authorization") authorization: String,  @Field("data") data: String): Observable<InviteResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.inviteagainthreefa_URL)
    fun invite_again(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<InviteAgainResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.threefactorauthchangestatus)
    fun acceptDeclineThreeFactor(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<InviteAgainResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.removethreefa_URL)
    fun removethreefa(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<RemoveResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.threefactorauthonoff)
    fun onOffAuthenticator(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<AuthenticatorResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.sort_URL)
    fun sortWallet(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<BaseResponsenew>

    @FormUrlEncoded
    @POST(ConstantsUtils.withdrawauthreqests)
    fun checkWithdrawAuthReqests(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<WithdrawauthResponse>


    @FormUrlEncoded
    @POST(ConstantsUtils.bkrequests)
    fun checkbkrequests(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<BackupnotificationResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.bkrequestacceptdecline)
    fun checkbkrequestacceptdecline(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<Authacceptresponse>



    @FormUrlEncoded
    @POST(ConstantsUtils.uplSend)
    fun uplSend(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<BaseResponseUplSend>

    @FormUrlEncoded
    @POST(ConstantsUtils.uplouterwithdraw)
    fun uplSendouterwithdraw(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<BaseResponseUplSendOuter>

    @FormUrlEncoded
    @POST(ConstantsUtils.upliswalletaddress)
    fun upliswalletaddress(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<BaseResponseisUpl>

    @POST(ConstantsUtils.getusercontact_URL)
    fun getUserContact(@Header("Authorization") authorization: String): Observable<UserContactResponse>

    @GET(ConstantsUtils.clearnotifications)
    fun clearNotifications(@Header("Authorization") authorization: String): Observable<BaseResponse>

    @GET(ConstantsUtils.notifications_URL)
    fun getNotification(@Header("Authorization") authorization: String): Observable<NotificationResponse>

    @GET(ConstantsUtils.ABOUTUS_URL)
    fun getABOUTUS(): Observable<LinksResponse>

    @GET(ConstantsUtils.TERMS_URL)
    fun getTERMS(): Observable<LinksResponse>

    @GET(ConstantsUtils.PRIVACY_URL)
    fun getPRIVACY(): Observable<LinksResponse>

    @GET(ConstantsUtils.FAQ_URL)
    fun getFAQ(): Observable<LinksResponse>


    @GET(ConstantsUtils.searchToken)
    fun getSearchToken(@Query("q") q: String): Observable<ArrayList<SearchTokenResponse>>


    @GET(ConstantsUtils.coingeekosearch)
    fun getCoingeekosearch(): Observable<ArrayList<CoinGeekoList>>

    @FormUrlEncoded
    @POST(ConstantsUtils.addToken)
    fun addTokenApi(@Header("Authorization") authorization: String, @Field("data") data: String): Observable<BaseResponse>


    @FormUrlEncoded
    @POST(ConstantsUtils.updateuserdevicetoken)
    fun updateuserdevicetoken(@Header("Authorization") authorization: String,@Field("data") data: String): Observable<updateTokenResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.coindetail)
    fun getCoindetail(@Header("Authorization") authorization: String,@Field("data") data: String): Observable<CoinDetailResponse>

    @GET(ConstantsUtils.getcommissiondetails)
    fun getCommissiondetail(@Header("Authorization") authorization: String): Observable<CommisionResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.aftersend)
    fun sendContract(@Header("Authorization") authorization: String,@Path("coin") coin: String, @Field("data") data: String): Observable<sendContractResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.savetrnx)
    fun savetrnx(@Header("Authorization") authorization: String, @Path("coin") coin: String,
                 @Field("data") model: String): Observable<SendBtcResponse>

    @FormUrlEncoded
    @POST(ConstantsUtils.updatetrnxidaftercosignerauth)
    fun updatetrnxidaftercosignerauth(@Header("Authorization") authorization: String,
                                      @Field("data") model: String): Observable<SendBtcResponse>



    @FormUrlEncoded
    @POST(ConstantsUtils.disablewallets)
    fun disablewallets(@Header("Authorization") authorization: String,
                       @Field("data") model: String): Observable<BaseResponse>

    @GET(ConstantsUtils.getUnspent)
    fun getUnspent(@Path("address") address: String): Observable<UnspentResponseLocal>


    @FormUrlEncoded
    @POST(ConstantsUtils.getuplfiatprice)
    fun getuplfiatprice(@Header("Authorization") authorization: String,
                         @Field("data") model: String): Observable<uplResponse>
}