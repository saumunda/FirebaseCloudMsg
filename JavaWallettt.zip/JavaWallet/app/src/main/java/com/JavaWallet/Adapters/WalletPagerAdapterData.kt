package com.JavaWallet.Adapters

import android.content.Context
import android.support.v4.view.PagerAdapter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.networking.ManageWalletData
import kotlinx.android.synthetic.main.walletcoin_pager.view.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.RelativeLayout
import com.JavaWallet.BaseActivity
import com.JavaWallet.Utility
import org.json.JSONArray
import java.util.*
import kotlin.collections.ArrayList


class WalletPagerAdapterData(mContext: Context, walletlist: ArrayList<ManageWalletData>, private val lstnr: Listner) : PagerAdapter() {
    private var layoutInflater: LayoutInflater? = null

    init {
        Companion.mContext = mContext
        Companion.walletlist = walletlist

    }

    interface Listner {
        fun onData_Click(position: Int,view:RelativeLayout,mainView:RelativeLayout)
    }

    companion object {
        lateinit var mContext: Context
        lateinit var walletlist: ArrayList<ManageWalletData>

    }
    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        layoutInflater = mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = layoutInflater!!.inflate(R.layout.walletcoin_pager, container, false)
        container.addView(view)
        view.rltv_main.setOnClickListener {
           lstnr.onData_Click(position,view.rltv_trnsctn,view.rltv_main)
        }
        view.tv_name.text = walletlist[position].coinName
        val rnd = Random()
        val color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
        try{
            if(walletlist[position].coinImage==null){
                view.iv_currency.visibility=View.INVISIBLE
                view.tv_roundWlt.visibility=View.VISIBLE
                val bgShape = view.tv_roundWlt.getBackground() as GradientDrawable
                bgShape.setColor(color)
                view.tv_roundWlt.text= walletlist.get(position).coinName.substring(0,1);
            }else{
                view.iv_currency.visibility=View.VISIBLE
                view.tv_roundWlt.visibility=View.GONE
                (mContext as BaseActivity).loadPicture_circle(view.iv_currency, JavaWallet.IMAGEBASE_URL + walletlist[position].coinImage)

            }

        }catch (e:Exception){
            e.printStackTrace()
        }

        view.tv_balancecrypto.text = "" + (mContext as BaseActivity).decimalConverterUpto(walletlist[position].balance, 8) + " " + walletlist[position].coinSymbol.toUpperCase()

        if (!JavaWallet.mPreferenceDataModal.CRYPTODATA.equals("")) {
            val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.CRYPTODATA)
            try {
                if(jsonarray.length()==0){
                    if(walletlist[position].coinSymbol.equals( "upl")){
                        if (JavaWallet.mPreferenceDataModal.uplpercenr > 0) {
                            view.tv_crncystatus.text = (mContext as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplpercenr, 2) + "%"
                            view.tv_crncystatus.setTextColor(mContext.resources.getColor(R.color.qPrimary_text_colorwhite_Darktheme))
                            view.iv_status.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_bitcoin_currency_arrow))
                        } else {
                            view.tv_crncystatus.text = (mContext as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplpercenr, 2) + "%"
                            view.tv_crncystatus.setTextColor(mContext.resources.getColor(R.color.red))
                            view.iv_status.setImageDrawable(mContext.resources.getDrawable(R.drawable.down_red))
                        }
                        view.tv_balancefiat.text =
                                (mContext as BaseActivity).decimalConverterUpto(((walletlist[position].balance) * (JavaWallet.mPreferenceDataModal.uplvalue)), 2) +
                                        " " + walletlist[position].currencyCode
                        view.tv_marketvalue.text = "= " + (mContext as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplvalue, 2) + " " + JavaWallet.mPreferenceDataModal.DefaultCurrency

                    }
                }else{
                    for (i in 0 until jsonarray.length()){
                        var jsnobj = jsonarray.getJSONObject(i)
                        if( walletlist[position].coinSymbol.equals(jsnobj.getString("symbol"))){
                            if (jsnobj.getString("price_change_percentage_24h").toDouble() > 0) {
                                view.tv_crncystatus.text = (mContext as BaseActivity).decimalConverterUpto(jsnobj.getString("price_change_percentage_24h").toDouble(), 2) + "%"
                                view.tv_crncystatus.setTextColor(mContext.resources.getColor(R.color.qPrimary_text_colorwhite_Darktheme))
                                view.iv_status.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_bitcoin_currency_arrow))
                            } else {
                                if (Utility.getTheme(mContext).equals("dark")) {
                                    view.tv_crncystatus.text = (mContext as BaseActivity).decimalConverterUpto(jsnobj.getString("price_change_percentage_24h").replace("-","").toDouble(), 2) + "%"
                                    view.tv_crncystatus.setTextColor(mContext.resources.getColor(R.color.dark_grey))
                                    view.iv_status.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_arrow_drop_down))
                                } else {
                                    view.tv_crncystatus.text = (mContext as BaseActivity).decimalConverterUpto(jsnobj.getString("price_change_percentage_24h").replace("-","").toDouble(), 2) + "%"
                                    view.tv_crncystatus.setTextColor(mContext.resources.getColor(R.color.red))
                                    view.iv_status.setImageDrawable(mContext.resources.getDrawable(R.drawable.down_red))
                                }


                            }
                            view.tv_balancefiat.text =
                                    (mContext as BaseActivity).decimalConverterUpto(((walletlist[position].balance) * (jsnobj.getString("current_price").toDouble())), 2) +
                                            " " + walletlist[position].currencyCode
                            view.tv_marketvalue.text = "= " + (mContext as BaseActivity).decimalConverterUpto(jsnobj.getString("current_price").toDouble(), 8) + " " + JavaWallet.mPreferenceDataModal.DefaultCurrency

                        } else if(walletlist[position].coinSymbol.equals( "upl")){
                            if (JavaWallet.mPreferenceDataModal.uplpercenr > 0) {
                                view.tv_crncystatus.text = (mContext as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplpercenr, 2) + "%"
                                view.tv_crncystatus.setTextColor(mContext.resources.getColor(R.color.qPrimary_text_colorwhite_Darktheme))
                                view.iv_status.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_bitcoin_currency_arrow))
                            } else {
                                view.tv_crncystatus.text = (mContext as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplpercenr, 2) + "%"
                                view.tv_crncystatus.setTextColor(mContext.resources.getColor(R.color.red))
                                view.iv_status.setImageDrawable(mContext.resources.getDrawable(R.drawable.down_red))
                            }
                            view.tv_balancefiat.text =
                                    (mContext as BaseActivity).decimalConverterUpto(((walletlist[position].balance) * (JavaWallet.mPreferenceDataModal.uplvalue)), 2) +
                                            " " + walletlist[position].currencyCode
                            view.tv_marketvalue.text = "= " + (mContext as BaseActivity).decimalConverterUpto(JavaWallet.mPreferenceDataModal.uplvalue, 2) + " " + JavaWallet.mPreferenceDataModal.DefaultCurrency

                        }

                    }
                }


            } catch (e: Exception) {
                e.printStackTrace()
                view.tv_crncystatus.text = "0.00 " + JavaWallet.mPreferenceDataModal.DefaultCurrency
                view.tv_crncystatus.setTextColor(mContext.resources.getColor(R.color.qPrimary_text_colorwhite_Darktheme))
                view.iv_status.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_bitcoin_currency_arrow))
                view.tv_balancefiat.text = "0.00 " + walletlist[position].currencyCode
                view.tv_marketvalue.text = "= 0.00 " + JavaWallet.mPreferenceDataModal.DefaultCurrency
            }
        }

        return view
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun getCount(): Int {
        return walletlist.size
    }


    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        val view = `object` as View
        container.removeView(view)
    }

    override fun getItemPosition(`object`: Any): Int {
        return POSITION_NONE
    }


}