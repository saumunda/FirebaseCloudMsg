package com.JavaWallet.Adapters

import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.R
import com.JavaWallet.networking.TransactionsWalletData
import com.JavaWallet.ui.activities.TransactionDetail
import kotlinx.android.synthetic.main.transaction_item.view.*
import com.JavaWallet.ui.fragments.Wallet_frag
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


/**
 * Created by user on 11/4/19.
 */

class TransactionAdapterLimit(private val transactionlist: ArrayList<TransactionsWalletData>, private val isthemeDark: Boolean, private val frag: Wallet_frag) : RecyclerView.Adapter<TransactionAdapterLimit.ViewHolder>() {

    private lateinit var mContext: Context


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.transaction_itemlimit, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        var listdata = transactionlist.get(position)
        holder.bindItems(listdata)
        if (isthemeDark) {
            holder.itemView.tv_deposittime.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.black))
        } else {
            holder.itemView.tv_deposittime.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.white))
        }

        if (listdata.type.equals("withdraw")) {
            holder.itemView.tv_deposit.text = mContext.getString(R.string.Transfer_title)+" "  + decimalConverterUpto(listdata.amount.toDouble(), 8) + " " + listdata.coinSymbol.toUpperCase()
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.ic_up_white))
            holder.itemView.tv_deposittime.text = "Sent on: " + convertUTCtoDeviceZone(listdata.createdAt, "dd MMM, yyyy ' | 'hh:mm a")
        } else {
            holder.itemView.tv_deposit.text = mContext.getString(R.string.Deposit_title)+" " + decimalConverterUpto(listdata.amount.toDouble(), 8) + " " + listdata.coinSymbol.toUpperCase()
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.ic_down_white))
            holder.itemView.tv_deposittime.text = "Received on: " + convertUTCtoDeviceZone(listdata.createdAt, "dd MMM, yyyy ' | 'hh:mm a")
        }

        var status = listdata.status
        var blockchain_status = listdata.blockchainStatus

        if (status.equals("pending", true)) {
            holder.itemView.tv_status.text = mContext.getString(R.string.Pending)
            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.orange_progress))
            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.ic_in_progress))
        } else if (status.equals("approved", true)) {
            holder.itemView.tv_status.text = mContext.getString(R.string.broadcast)
            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.orange_progress))
            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.ic_in_progress))
        } else if (status.equals("complete", true) || status.equals("signed", true) || status.equals("unconfirmed", true)) {
            if (blockchain_status == null) {
                if (listdata.type.equals("withdraw", true) && blockchain_status == null) {
                    if (status.equals("complete", true)) {
                        holder.itemView.tv_status.text = mContext.getString(R.string.inProgress)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))

                    } else if (status.equals("signed", true) && blockchain_status == null) {
                        holder.itemView.tv_status.text = mContext.getString(R.string.inProgress)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
                    } else {
                        holder.itemView.tv_status.text = mContext.getString(R.string.complete)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.greenbottom))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_compeleted))
                    }
                } else if (listdata.type.equals("deposit", true)) {
                    if (status.equals("complete", true)) {
                        holder.itemView.tv_status.text = mContext.getString(R.string.complete)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.greenbottom))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_compeleted))
                    } else {
                        holder.itemView.tv_status.text =mContext.getString(R.string.inProgress)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
                    }

                } else {
                    holder.itemView.tv_status.text = mContext.getString(R.string.inProgress)
                    holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
                    holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
                }
            } else {
                if (blockchain_status.equals("confirmed", true)) {
                    holder.itemView.tv_status.text = mContext.getString(R.string.complete)
                    holder.itemView.tv_status.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.greenbottom))
                    holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.ic_compeleted))
                } else {
                    if (listdata.type.equals("withdraw", true)) {
                        if (status.equals("complete", true)) {
                            holder.itemView.tv_status.text = mContext.getString(R.string.complete)
                            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.greenbottom))
                            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.ic_compeleted))
                        } else {
                            holder.itemView.tv_status.text = mContext.getString(R.string.inProgress)
                            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.orange_progress))
                            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.ic_in_progress))
                        }
                    } else if (listdata.type.equals("deposit", true)) {
                        if (status.equals("complete", true)) {
                            holder.itemView.tv_status.text = mContext.getString(R.string.complete)
                            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.greenbottom))
                            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.ic_compeleted))
                        } else {
                            holder.itemView.tv_status.text =mContext.getString(R.string.inProgress)
                            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.orange_progress))
                            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.ic_in_progress))
                        }
                    } else {
                        holder.itemView.tv_status.text = mContext.getString(R.string.inProgress)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.orange_progress))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.ic_in_progress))
                    }

                }
            }


        } else if (status.equals("confirmed")) {

        } else {
            if(isthemeDark){
                holder.itemView.tv_status.text = mContext.getString(R.string.failed)
                holder.itemView.tv_status.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.dark_grey))
                holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.ic_cancel_black_24dp)) }
            else {
                holder.itemView.tv_status.text = mContext.getString(R.string.failed)
                holder.itemView.tv_status.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.red))
                holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(com.JavaWallet.R.drawable.cross_fialed)) }
        }


    }

    override fun getItemCount(): Int {
        if (transactionlist.size >= 2) {
            return 2
        } else {
            return transactionlist.size
        }

    }

    fun decimalConverterUpto(value: Double, places: Int): String {
        val decimalFormatter = DecimalFormat("##.#")
        decimalFormatter.minimumFractionDigits = 2
        decimalFormatter.maximumFractionDigits = places
        return decimalFormatter.format(value)
    }

    fun convertUTCtoDeviceZone(date: String, output: String): String {
        //"yyyy-MM-dd'T'HH:mm:ss.sssZ"
        return try {
            var dateReturn = ""
            if (!date.isEmpty()) {
                val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH)
                sdf.timeZone = TimeZone.getTimeZone("UTC")
                val output = SimpleDateFormat(output, Locale.ENGLISH)
                val d = sdf.parse(date.trimStart())
                sdf.timeZone = TimeZone.getDefault()
                dateReturn = output.format(d)
            }
            dateReturn
        } catch (e: Exception) {
            date
        }

    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context
        }

        fun bindItems(listdata: TransactionsWalletData) {
            itemView.rltv_item.setOnClickListener {


                val intent = Intent(mContext, TransactionDetail::class.java)
                intent.putExtra(mContext.getString(R.string.t_id), listdata.id)
                intent.putExtra(mContext.getString(R.string.t_type), listdata.type)
                intent.putExtra("coinSymbol", listdata.coinSymbol)
                mContext.startActivity(intent)
                /*var bndl = Bundle()
                bndl.putInt("t_id", listdata.id)
                bndl.putString("t_type", listdata.type)
                startActivity(mContext,TransactionDetail::class.java,bndl)
*/
                //callActivityWithData(TransactionDetail::class.java, bndl)
                // frag.closeFullview()
            }
        }
    }
}