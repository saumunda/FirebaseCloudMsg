package com.JavaWallet.Utilities;

import android.content.Context;
import android.support.v4.widget.NestedScrollView;
import android.view.MotionEvent;

public class MyNestedScrollView extends NestedScrollView {
    private boolean topZone = false;

    public MyNestedScrollView(Context context) {
        super(context);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            topZone = (getPaddingTop() - getScrollY() > ev.getY());
        }

        if (topZone) {
            if (ev.getAction() == MotionEvent.ACTION_UP) {
                topZone = false;
            }
            return false;
        }
        return super.onTouchEvent(ev);
    }

}