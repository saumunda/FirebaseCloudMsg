package com.JavaWallet.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.*
import com.JavaWallet.BaseActivity
import com.JavaWallet.R
import com.JavaWallet.ui.activities.Receive
import com.JavaWallet.ui.activities.Send
import kotlinx.android.synthetic.main.walletcoin_pager.view.*


/**
 * Created by user on 11/4/19.
 */

class CarasuolAdapter(mContext: Context) : RecyclerView.Adapter< CarasuolAdapter.ViewHolder>() {

    init {
         CarasuolAdapter.Companion.mContext = mContext
    }

    companion object {
        lateinit var mContext: Context
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.walletcoin_pager, parent, false)
        return  ViewHolder(v)
    }


    private var lastPosition: Int=-1

    override fun onBindViewHolder(holder:  CarasuolAdapter.ViewHolder, position: Int) {
        holder.itemView.tv_name.text="Bitcoin: "+position
        /*holder.itemView.rltv_mainpager.setOnClickListener {

            holder.itemView.rltv_options.visibility=View.VISIBLE
            holder.itemView.rltv_trnsctn.visibility=View.VISIBLE


        }
        holder.itemView.iv_closepopup.setOnClickListener {

            holder.itemView.rltv_options.visibility=View.GONE
            holder.itemView.rltv_trnsctn.visibility=View.GONE
        }*/

        holder.itemView.lnr_send.setOnClickListener {
            ( CarasuolAdapter.Companion.mContext as BaseActivity).startNewActivity(Send())
        }

        holder.itemView.lnr_receive.setOnClickListener {
            ( CarasuolAdapter.Companion.mContext as  BaseActivity).startNewActivity(Receive())

        }

        holder.bindItems()

//        val animation = AnimationUtils.loadAnimation(mContext,
//                if (position > lastPosition)
//                    R.anim.up_from_bottom
//                else
//                    R.anim.down_from_top)
//        holder.itemView.startAnimation(animation)
//        lastPosition = position
//        setScaleAnimation(holder.itemView)
    }

    override fun getItemCount(): Int {
        return 6
    }

//    override fun onViewDetachedFromWindow(holder: ViewHolder?) {
//        super.onViewDetachedFromWindow(holder)
//        holder!!.itemView.clearAnimation();
//    }
private fun setScaleAnimation(view: View) {
    var animset=AnimationSet(true)
    val anim1 = AlphaAnimation(0.0f, 1.0f)
    anim1.duration = 1000
    animset.addAnimation(anim1)
    val anim = ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f)
    anim.duration = 1000
    animset.addAnimation(anim)
    animset.startNow()
}
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bindItems() {

        }
    }
}