package com.JavaWallet.ui.fragments

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.TextView
import com.JavaWallet.*
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.Utilities.Preference
import com.JavaWallet.networking.BaseResponse
import com.JavaWallet.networking.TokenRequest
import com.JavaWallet.networking.addreferalRequest
import com.JavaWallet.networking.updateTokenResponse
import com.JavaWallet.ui.activities.*
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_setting.*
import kotlinx.android.synthetic.main.darktheme_cb.*
import kotlinx.android.synthetic.main.lighttheme_cb.*
import kotlinx.android.synthetic.main.logout_dialog.*
import retrofit2.HttpException


class Setting_frag : BaseFragment(), View.OnClickListener {


    //Overriden method onCreateView
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.activity_setting, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // ConstantsUtils.CurrentScreen = 2
        mActivity.isAcceptAuthRequestClicked = true
        if (Utility.getTheme(mActivity).equals(mActivity.THEME_DARK)) {
            tv_themename.text = "Dark"
            in_dark.visibility = View.VISIBLE
            in_light.visibility = View.GONE
            iv_logout.setColorFilter(resources.getColor(R.color.logout_dark));

        } else if (Utility.getTheme(mActivity).equals(mActivity.THEME_LIGHT)) {
            tv_themename.text = "Light"
            in_dark.visibility = View.GONE
            in_light.visibility = View.VISIBLE
            iv_logout.setColorFilter(resources.getColor(R.color.logout_light));

        } else {
            tv_themename.text = "Dark"
            in_dark.visibility = View.VISIBLE
            in_light.visibility = View.GONE
            iv_logout.setColorFilter(resources.getColor(R.color.logout_dark));
        }
        rltv_currency.setOnClickListener {
            ConstantsUtils.isthemeCliked=false
            mActivity.startNewActivity(DefaultCurrency())
        }
        rltv_changepin.setOnClickListener {
            ConstantsUtils.isthemeCliked=false
            mActivity.startNewActivity(ChangePin())
        }
        rltv_backup.setOnClickListener {
            //BackupWallet
            /*var bndl = Bundle()
            bndl.putBoolean("isfromSend", false)
            bndl.putBoolean("isfromTransaction", false)
            bndl.putBoolean("isfromSetting", true)
            mActivity.callActivityWithData(NewPinAfterImport::class.java, bndl)*/
            ConstantsUtils.isthemeCliked=false
            var bndl = Bundle()
            bndl.putBoolean(getString(R.string.isfromcreate), false)
            bndl.putBoolean(getString(R.string.isfromsetting), true)
            mActivity.callActivityWithData(Backupnow::class.java, bndl)


        }
        rltv_3step.setOnClickListener {
            ConstantsUtils.isthemeCliked=false
            mActivity.startNewActivity(ThreeFactor())
        }


    }



    override fun onResume() {
        super.onResume()
        JavaWallet.mPreferenceDataModal = Preference.getInstance(mActivity).sharedPreference
        tvcoinselected.text = JavaWallet.mPreferenceDataModal.DefaultCurrency

        onClickk()

        rl_darktheme.setOnClickListener {
            mActivity.setTheme(R.style.AppTheme_Dark)
            Utility.setTheme(mActivity, "dark")
            ConstantsUtils.isthemeCliked = true
            mActivity.recreateActivity();
        }

        rl_lightheme.setOnClickListener {
            mActivity.setTheme(R.style.AppTheme_Light)
            Utility.setTheme(mActivity, "light")
            ConstantsUtils.isthemeCliked = true
            mActivity.recreateActivity();
        }
    }


    private fun onClickk() {
        rltv_logout.setOnClickListener(this)
        rltv_about.setOnClickListener(this)
        rltv_terms.setOnClickListener(this)
        rltv_privacy.setOnClickListener(this)
        rltv_faq.setOnClickListener(this)
        rltv_cosigner.setOnClickListener(this)


    }

    override fun onClick(p0: View?) {
        when (p0) {

            rltv_logout -> {
                var dialog = Dialog(mActivity)
                dialog.setCancelable(false)
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.setContentView(R.layout.logout_dialog)
                val dialog_no = dialog.findViewById<View>(R.id.dialog_no) as TextView
                val dialog_yes = dialog.findViewById<View>(R.id.dialog_yes) as TextView
                dialog_no.setOnClickListener { dialog.dismiss() }
                dialog_yes.setOnClickListener {
                    dialog.dismiss()
                    upDateToken()
                    JavaWallet.mPreferenceDataModal.WALLET_PIN = ""
                    JavaWallet.mPreferenceDataModal.JWTToken = ""
                    JavaWallet.mPreferenceDataModal.COIN_MNEMONICS = ""
                    JavaWallet.mPreferenceDataModal.COIN_ADDRESS = ""
                    JavaWallet.mPreferenceDataModal.BTC_ADDRESS = ""
                    JavaWallet.mPreferenceDataModal.DefaultCurrency = "USD"
                    JavaWallet.mPreferenceDataModal.ISGENERATEMNEMONICSAT_SIGNIN = false
                    JavaWallet.mPreferenceDataModal.ISSIGNIN = false
                    JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                    mActivity.startNewActivityClearTask(SigninActivity())
                    // ConstantsUtils.CurrentScreen = 0

                }
                dialog.show()
            }

            rltv_faq -> {
                ConstantsUtils.isthemeCliked=false
                var bndl = Bundle()
                bndl.putString(mActivity.resources.getString(R.string.links_title), mActivity.resources.getString(R.string.settingfaq))
                bndl.putString(mActivity.resources.getString(R.string.links_url), ConstantsUtils.FAQ_URL)
                mActivity.callActivityWithData(LinksActivity::class.java, bndl)

            }

            rltv_about -> {
                ConstantsUtils.isthemeCliked=false
                var bndl = Bundle()
                bndl.putString(mActivity.resources.getString(R.string.links_title), mActivity.resources.getString(R.string.settingaboutus))
                bndl.putString(mActivity.resources.getString(R.string.links_url), ConstantsUtils.ABOUTUS_URL)
                mActivity.callActivityWithData(LinksActivity::class.java, bndl)

            }

            rltv_privacy -> {
                ConstantsUtils.isthemeCliked=false
                var bndl = Bundle()
                bndl.putString(mActivity.resources.getString(R.string.links_title), mActivity.resources.getString(R.string.settingprivacy))
                bndl.putString(mActivity.resources.getString(R.string.links_url), ConstantsUtils.PRIVACY_URL)
                mActivity.callActivityWithData(LinksActivity::class.java, bndl)

            }

            rltv_terms -> {
                ConstantsUtils.isthemeCliked=false
                var bndl = Bundle()
                bndl.putString(mActivity.resources.getString(R.string.links_title), mActivity.resources.getString(R.string.settingterms))
                bndl.putString(mActivity.resources.getString(R.string.links_url), ConstantsUtils.TERMS_URL)
                mActivity.callActivityWithData(LinksActivity::class.java, bndl)

            }

            rltv_cosigner -> {
                ConstantsUtils.isthemeCliked=false
                cosignerDialog()

            }

        }

    }

    private fun upDateToken() {

        var rqst = TokenRequest("", 1, 0)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.apiServiceWithAuthorization.updateuserdevicetoken(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponsetoken(it) },
                        { error -> mActivity.handleError(error) })
    }

    private fun handleResponsetoken(it: updateTokenResponse?) {

        if (it!!.status) {

        }
    }

    private fun cosignerDialog() {

        var dialog = Dialog(mActivity)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.logout_dialog)
        val dialog_no = dialog.findViewById<View>(R.id.dialog_no) as TextView
        val dialog_yes = dialog.findViewById<View>(R.id.dialog_yes) as TextView
        dialog.title.text = getString(R.string.do_you_have_a_referral_code)
        dialog.dialog_message.text = getString(R.string.please_enter_referral_code)
        dialog_yes.text = "Cancel"
        dialog_no.text = "Submit"
        dialog_no.isClickable = false
        dialog_no.setTextColor(mActivity.resources.getColor(R.color.view_invite))
        dialog.edt_ref.visibility = View.VISIBLE

        dialog.edt_ref.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {

            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
                if (charSequence.toString().length > 4) {
                    dialog_no.isClickable = true
                    dialog_no.setTextColor(mActivity.resources.getColor(R.color.colorPrimaryDark_Lighttheme))

                } else {
                    dialog_no.isClickable = false
                    dialog_no.setTextColor(mActivity.resources.getColor(R.color.view_invite))
                }

            }

            override fun afterTextChanged(editable: Editable) {

            }
        })

        dialog_no.setOnClickListener {

            if (dialog.edt_ref.text.toString().trim().equals("")) {
                mActivity.showDialog("Please enter code", false)
            } else {
                dialog.dismiss()
                addRefralCode(dialog.edt_ref.text.toString().trim())
            }

        }
        dialog_yes.setOnClickListener {
            dialog.dismiss()


        }
        dialog.show()
    }

    private fun addRefralCode(code: String) {
        mActivity.showLoading()
        var rqst = addreferalRequest(code)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.apiServiceWithAuthorization.addReferalCode(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.hideLoading();handleError(error) })
    }

    private fun handleError(error: Throwable?) {

        when (error) {
            is HttpException -> {
                when {

                    error.code() == 400 -> {
                        val responseBody = error.response().errorBody()?.string()
                        var message = Gson().fromJson<BaseResponse>(responseBody, BaseResponse::class.java)
                        //mActivity.showToast(message.message)
                        showCodeDialogAgain()

                    }


                }
            }
        }

    }

    private fun handleResponse(it: BaseResponse?) {
        mActivity.hideLoading()
        if (it!!.status) {
            mActivity.showDialog("Referral code Linked Successfully.\n Please Check 3-Factor Authentication Section in Settings.", false)

        }
    }

    private fun showCodeDialogAgain() {
        var dialog = Dialog(mActivity)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.logout_dialog)
        val dialog_no = dialog.findViewById<View>(R.id.dialog_no) as TextView
        val dialog_yes = dialog.findViewById<View>(R.id.dialog_yes) as TextView
        dialog.dialog_message.text = getString(R.string.error_referral_code)
        dialog.edt_ref.visibility = View.GONE

        dialog_no.setOnClickListener {
            dialog.dismiss()

        }
        dialog_yes.setOnClickListener {
            dialog.dismiss()
            cosignerDialog()

        }
        dialog.show()
    }


}
