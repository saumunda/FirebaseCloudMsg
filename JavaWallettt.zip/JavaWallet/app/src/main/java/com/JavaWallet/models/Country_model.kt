package com.JavaWallet.models

/**
 * Created by user on 10/5/19.
 */

class Country_model {

    var countryName = ""
    var isoCountry = ""
    var country = ""

    constructor(countryName: String, isoCountry: String, country: String) {
        this.countryName = countryName
        this.isoCountry = isoCountry
        this.country = country
    }
}