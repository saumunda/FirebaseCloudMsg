package com.JavaWallet.ui.fragments

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.BaseFragment
import com.JavaWallet.R
import com.JavaWallet.JavaWallet
import kotlinx.android.synthetic.main.wallet_pager_two.view.*

@SuppressLint("ValidFragment")
class Demo_frag @SuppressLint("ValidFragment") constructor
(private val total_val: Double) : BaseFragment() {


    private lateinit var viewvv: View

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        viewvv = inflater!!.inflate(R.layout.wallet_pager_two, container, false)
        return viewvv
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view!!, savedInstanceState)
        viewvv.tv_total.text = "" + total_val + " " + JavaWallet.mPreferenceDataModal.DefaultCurrency
    }


}