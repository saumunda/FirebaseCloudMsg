package com.JavaWallet.ui.activities

import android.os.Bundle
import android.text.Html
import com.JavaWallet.BaseActivity
import com.JavaWallet.R
import com.JavaWallet.Utility
import com.JavaWallet.networking.LinksResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_links.*
import kotlinx.android.synthetic.main.header_title.*

class LinksActivity : BaseActivity() {

    private var titlee: String? = null
    private var url: String? = null
     var txt = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_links)

        try {
            var b: Bundle? = Bundle()
            b = intent.extras
            titlee = b!!.getString(getString(R.string.links_title))
            url = b!!.getString(getString(R.string.links_url))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        tv_title.text = titlee
        iv_back.setOnClickListener {
            finish()
        }
        if (isInternetConnected()) {
            getData()
        } else {
            showDialog(getString(R.string.network_error), false)
        }
        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
        } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        }
    }

    private fun getData() {

//        scroll.setEnableScrolling(true)
        if (titlee.equals(getString(R.string.settingaboutus))) {
             showLoading()
            apiServiceWithAuthorization_LINks.getABOUTUS()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponse(it) },
                            { error -> handleError(error); hideLoading() })
        } else if (titlee.equals(getString(R.string.settingterms))) {
             showLoading()
            apiServiceWithAuthorization_LINks.getTERMS()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponse(it) },
                            { error -> handleError(error); hideLoading() })
        } else if (titlee.equals(getString(R.string.settingprivacy))) {
             showLoading()
            apiServiceWithAuthorization_LINks.getPRIVACY()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponse(it) },
                            { error -> handleError(error); hideLoading() })
        } else if (titlee.equals(getString(R.string.settingfaq))) {
             showLoading()
            apiServiceWithAuthorization_LINks.getFAQ()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponse(it) },
                            { error -> handleError(error); hideLoading() })
        }


    }

    private fun handleResponse(it: LinksResponse) {
        hideLoading()
        if (it.status) {
            tv_data.text = Html.fromHtml(it.data.content.replace("\r\n\t", ""))
           /* if (isfaq) {
                txt = it.data.content.replace("\r\n\t", "<br>");*//*.replace("<p>", "").replace("</p>", "").replace("<strong>", "<p><strong>").replace("</strong>", "</p></strong>")*//*
            } else {
                txt = it.data.content.replace("\n", "<br>");
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                tv_data.text = Html.fromHtml(txt, Html.FROM_HTML_MODE_COMPACT)
            } else {
                tv_data.text = Html.fromHtml(txt)
            }*/

        } else {
            showDialog(it.message, false)
        }

    }
}
