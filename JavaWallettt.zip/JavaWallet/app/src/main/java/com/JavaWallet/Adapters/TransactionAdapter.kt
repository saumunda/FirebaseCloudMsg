package com.JavaWallet.Adapters

import android.content.Context
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.BaseActivity
import com.JavaWallet.R
import com.JavaWallet.networking.TransactionData
import com.JavaWallet.ui.activities.TransactionDetail
import kotlinx.android.synthetic.main.transaction_item.view.*

/**
 * Created by user on 11/4/19.
 */

class TransactionAdapter(private val transactionlist: ArrayList<TransactionData>, private val isthemeDark: Boolean) : RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {

    private lateinit var mContext: Context


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.transaction_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        var listdata = transactionlist.get(position)
        holder.bindItems(listdata)
        if (listdata.type.equals("withdraw")) {
            holder.itemView.tv_deposit.text =mContext.getString(R.string.Transfer_title)+" " + (mContext as BaseActivity).decimalConverterUpto(listdata.amount.toDouble(), 8) + " " + listdata.coinSymbol.toUpperCase()
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_up_white))
            holder.itemView.iv_transactionstatus.setColorFilter(mContext.resources.getColor(R.color.dred));
            holder.itemView.tv_deposittime.text = "Sent on: " + (mContext as BaseActivity).convertUTCtoDeviceZone(listdata.createdAt, "dd MMM, yyyy ' | 'hh:mm a")
        } else {
            holder.itemView.tv_deposit.text = mContext.getString(R.string.Deposit_title)+" " + (mContext as BaseActivity).decimalConverterUpto(listdata.amount.toDouble(), 8) + " " + listdata.coinSymbol.toUpperCase()
            holder.itemView.iv_transactionstatus.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_down_white))
            holder.itemView.iv_transactionstatus.setColorFilter(mContext.resources.getColor(R.color.greenbottom));
            holder.itemView.tv_deposittime.text = "Received on: " + (mContext as BaseActivity).convertUTCtoDeviceZone(listdata.createdAt, "dd MMM, yyyy ' | 'hh:mm a")
        }


        var status = listdata.status
        var blockchain_status = listdata.blockchainStatus

        if (status.equals("pending", true)) {
            holder.itemView.tv_status.text = mContext.getString(R.string.Pending)
            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
        } else if (status.equals("approved", true)) {
            holder.itemView.tv_status.text = mContext.getString(R.string.broadcast)
            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
        } else if (status.equals("complete", true) || status.equals("signed", true) || status.equals("unconfirmed", true)) {
            if (blockchain_status == null) {
                if (listdata.type.equals("withdraw", true)) {
                    if (status.equals("complete", true) && blockchain_status == null) {
                        holder.itemView.tv_status.text = mContext.getString(R.string.inProgress)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
                    } else if (status.equals("signed", true) && blockchain_status == null) {
                        holder.itemView.tv_status.text =mContext.getString(R.string.inProgress)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
                    } else {
                        holder.itemView.tv_status.text = mContext.getString(R.string.complete)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.greenbottom))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_compeleted))
                    }
                } else if (listdata.type.equals("deposit", true)) {
                    if (status.equals("complete", true)) {
                        holder.itemView.tv_status.text = mContext.getString(R.string.complete)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.greenbottom))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_compeleted))
                    } else {
                        holder.itemView.tv_status.text = mContext.getString(R.string.inProgress)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
                    }

                } else {
                    holder.itemView.tv_status.text = mContext.getString(R.string.inProgress)
                    holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
                    holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
                }
            } else {
                if (blockchain_status.equals("confirmed")) {
                    holder.itemView.tv_status.text = mContext.getString(R.string.complete)
                    holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.greenbottom))
                    holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_compeleted))
                } else {
                    if (listdata.type.equals("withdraw", true)) {
                        if (status.equals("complete", true)) {
                            holder.itemView.tv_status.text = mContext.getString(R.string.complete)
                            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.greenbottom))
                            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_compeleted))
                        } else {
                            holder.itemView.tv_status.text = mContext.getString(R.string.inProgress)
                            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
                            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
                        }
                    } else if (listdata.type.equals("deposit", true)) {
                        if (status.equals("complete", true)) {
                            holder.itemView.tv_status.text = mContext.getString(R.string.complete)
                            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.greenbottom))
                            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_compeleted))
                        } else {
                            holder.itemView.tv_status.text = mContext.getString(R.string.inProgress)
                            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
                            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
                        }

                    } else {
                        holder.itemView.tv_status.text = mContext.getString(R.string.inProgress)
                        holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.orange_progress))
                        holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_in_progress))
                    }

                }
            }


        } else if (status.equals("confirmed")) {

        } else {
            holder.itemView.tv_status.text = mContext.getString(R.string.failed)
            holder.itemView.tv_status.setTextColor(mContext.resources.getColor(R.color.red))
            holder.itemView.ivstatus_symbol.setImageDrawable(mContext.resources.getDrawable(R.drawable.cross_fialed))

        }


    }

    override fun getItemCount(): Int {
        return transactionlist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context
        }

        fun bindItems(listdata: TransactionData) {
            itemView.rltv_item.setOnClickListener {
                var bndl = Bundle()
                bndl.putInt(mContext.getString(R.string.t_id), listdata.id)
                bndl.putString(mContext.getString(R.string.t_type), listdata.type)
                bndl.putString("coinSymbol", listdata.coinSymbol)
                (mContext as BaseActivity).callActivityWithData(TransactionDetail::class.java, bndl)
            }
        }
    }
}

