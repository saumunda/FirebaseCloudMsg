package com.HdWaalet

import java.io.File

/**
 * Created by user on 9/5/19.
 */

object FileUtils {
    fun deleteFile(path: String) {
        try {
            val file = File(path)
            if (file.exists())
                file.delete()
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    fun createDirIfNotExists(path: String): Boolean {
        var ret = true
        val file = File(path)
        if (!file.exists()) {
            if (!file.mkdirs()) {
                ret = false
            }
        }
        return ret
    }

}
