package com.JavaWallet

/**
 * Created by user on 16/5/19.
 */
interface PermissionInterface {
    fun permissionAccepted()

}