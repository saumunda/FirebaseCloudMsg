package com.JavaWallet.ui.activities

import android.app.Activity
import android.os.Bundle
import com.JavaWallet.BaseActivity
import com.JavaWallet.ConstantsUtils
import com.JavaWallet.R
import com.google.zxing.Result
import kotlinx.android.synthetic.main.activity_qrcode_scanner.*
import me.dm7.barcodescanner.zxing.ZXingScannerView

/**
 * Created by user on 16/5/19.
 */
class QrcodeScannerActivity: BaseActivity(), ZXingScannerView.ResultHandler {


    private var mScannerView: ZXingScannerView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mScannerView = ZXingScannerView(this)
        setContentView(R.layout.activity_qrcode_scanner)
        frame.addView(mScannerView)
        txtCancel.setOnClickListener {
            finish()
        }
    }

    override fun handleResult(result: Result?) {
        var data = intent
         data.putExtra(ConstantsUtils.QRCODE, result!!.text)
        setResult(Activity.RESULT_OK, data)
        finish()
    }
    override fun onResume() {
        super.onResume()
        mScannerView!!.setResultHandler(this) // Register ourselves as a handler for scan results.
        mScannerView!!.startCamera()
    }

    override fun onPause() {
        super.onPause()
        mScannerView!!.stopCamera()
    }
}