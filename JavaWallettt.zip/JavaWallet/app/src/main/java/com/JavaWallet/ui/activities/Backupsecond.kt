package com.JavaWallet.ui.activities

import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.view.View
import com.JavaWallet.Adapters.MnemonicsAdptr
import com.JavaWallet.Adapters.MnemonicsConfirmAdptr
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utility
import kotlinx.android.synthetic.main.activity_backupsecond.*
import kotlinx.android.synthetic.main.header_title.*
import java.util.*

class Backupsecond : BaseActivity(), MnemonicsAdptr.MnemonicListner, MnemonicsConfirmAdptr.MnemonicListnerConfirm, View.OnClickListener {


    private lateinit var adapter: MnemonicsAdptr
    private lateinit var confirm_adapter: MnemonicsConfirmAdptr
    private lateinit var mnemonics: List<String>
    private val shuffleList = ArrayList<String>()
    private val confirmList = ArrayList<String>()
    private var isfrom: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_backupsecond)
/*gravity ramp catatlog mistake reason family express tray spot frost aunt flatk*/
        try {
            var b: Bundle? = Bundle()
            b = intent.extras
            isfrom = b!!.getBoolean(getString(R.string.isfromcreate))

        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
            tv_title.setTextColor(resources.getColor(R.color.qPrimary_text_colorwhite_Darktheme))
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
            tv_title.setTextColor(resources.getColor(R.color.qPrimary_text_colorwhite_Darktheme))
        } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
            tv_title.setTextColor(resources.getColor(R.color.qPrimary_text_colorwhite_Darktheme))
        }

        mnemonics = JavaWallet.mPreferenceDataModal.COIN_MNEMONICS.split(" ")
        shuffleList.addAll(mnemonics)
        Collections.shuffle(shuffleList)

        val layoutManager = GridLayoutManager(this, 3)
        val confirmlayoutManager = GridLayoutManager(this, 3)
        recl_mnmncssecond.layoutManager = layoutManager
        rv_mnemonics_data.layoutManager = confirmlayoutManager

        adapter = MnemonicsAdptr(shuffleList, this, true)
        recl_mnmncssecond.adapter = adapter

        confirm_adapter = MnemonicsConfirmAdptr(confirmList, this)
        rv_mnemonics_data.adapter = confirm_adapter

        iv_back.setOnClickListener(this)

        tv_donecnfrm.setOnClickListener {
            if (confirmList.size > 0) {
                if (isfrom) {
                    if (mnemonics.equals(confirmList)) {
                        startNewActivity(ReviewActivity())
                    } else {
                        showDialog(getString(R.string.themnemonicsincorrect), false)
                    }

                } else {
                    if (mnemonics.equals(confirmList)) {
                        rltv_welldone.visibility = View.VISIBLE
                        tv_okaycnfrm.visibility = View.VISIBLE
                        lnr_one_two.visibility = View.GONE
                        tv_donecnfrm.visibility = View.GONE
                        iv_back.visibility = View.GONE
                    } else {
                        showDialog(getString(R.string.themnemonicsincorrect), false)
                    }
                }


            } else {
                showDialog(getString(R.string.entermnemonics), false)
            }
        }
        tv_okaycnfrm.setOnClickListener {
            var bndl = Bundle()
            bndl.putBoolean(getString(R.string.opensetting), true)
            callActivityWithDataCleartask(MainActivity::class.java, bndl)
        }
    }

    override fun onAddress_Click(position: Int) {


        confirmList.add(shuffleList.get(position));
        adapter.notifyDataSetChanged()
        shuffleList.removeAt(position)
        confirm_adapter.notifyDataSetChanged()


    }

    override fun onconfirm_Click(position: Int) {

        shuffleList.add(confirmList.get(position))
        confirmList.removeAt(position)
        adapter.notifyDataSetChanged()
        confirm_adapter.notifyDataSetChanged()

    }

    override fun onBackPressed() {
        if (tv_okaycnfrm.visibility == View.GONE) {
            super.onBackPressed()
        }
    }

    override fun onClick(v: View?) {

        when (v) {

            iv_back -> {

                finish()

            }
        }
    }
}
