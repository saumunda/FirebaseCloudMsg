package com.JavaWallet.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.R
import com.JavaWallet.networking.SearchTokenResponse
import kotlinx.android.synthetic.main.token_item.view.*

/**
 * Created by user on 11/4/19.
 */

class Addnewtokenadapter(private val coinlist: ArrayList<SearchTokenResponse>, private val listener:  Listener) : RecyclerView.Adapter< Addnewtokenadapter.ViewHolder>() {

    interface Listener {

        fun onItemClick(position: Int)
    }

    private lateinit var mContext: Context
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.token_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder:  ViewHolder, position: Int) {

        holder.itemView.tv_tokenname.text=coinlist[position].name + " ("+coinlist[position].symbol + ")"
        holder.itemView.tv_tokeaddres.text=coinlist[position].contractAddressHash
        holder.itemView.main_rltv.setOnClickListener {
            listener.onItemClick(position)
        }

    }

    override fun getItemCount(): Int {
        return coinlist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context

        }

    }
}