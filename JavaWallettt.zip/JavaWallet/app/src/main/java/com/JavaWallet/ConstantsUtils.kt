package com.JavaWallet

object ConstantsUtils {

    // var CurrentScreen: Int = 0
    var isActive: Int = 0
    var isthemeCliked = false
    var PREFS_NAME = "appname_pref";
    const val QRCODE = "qr"
    const val FINGERPRINT_SUCCESS = "com.JavaWallet.fingerprint_success"
    const val FINGERPRINT_fail = "com.JavaWallet.fingerprint_failed"
    var ISUPDATEBALANCE: Boolean = false
     const val CREATEUSER_URL = "createuser"
    const val GETCURRENCYLIST_URL = "getcurrencylist"
    const val GETOINLIST_URL = "getcoinlist"
    const val SAVEUSERCURRENCY_URL = "userdefaultcurrency"
    const val MANAGEWALLET_URL = "managewallet"
    const val DISABLECOIN_URL = "activeinactivecoin"
    const val CREATEADDRESS_URL = "createaddress"
    const val SETWITHDRAWLIMIT_URL = "setwithdrawlimit"
    const val ADDADDRESS_URL = "addpayee"
    const val GETADDADDRESS_URL = "getuserpayee"
    const val REMOVEADDADDRESS_URL = "removeuserpayee"
    const val GETTRANSACTION_URL = "transactions"
    const val GETTRANSACTIONDETAIL_URL = "transactiondetails"
    const val GETRAWDATA_URL = "getrawdatastring"
    const val GETCOUNTRYCODE_URL = "get_country_code"
    const val GETREFERCODE_URL = "ref_code"
    const val invitethreefactorauth_url = "invitethreefactorauth"
    const val inviteagainthreefa_URL = "inviteagainthreefa"
    const val getusercontact_URL = "getusercontact"
    const val notifications_URL = "notifications"
    const val removethreefa_URL = "removethreefa"
    const val sort_URL = "sortuserwallet"
    const val FAQ_URL = "getfaq"
    const val ABOUTUS_URL = "getaboutus"
    const val PRIVACY_URL = "getprivacypolicy"
    const val TERMS_URL = "getterms"
    const val sentthreefactorauthreq_URL = "sentthreefactorauthreq"
    const val threefactorauthlinkrefcode = "threefactorauthlinkrefcode"
    const val receivedthreefactorauthreq = "receivedthreefactorauthreq"
    const val threefactorauthchangestatus = "threefactorauthchangestatus"
    const val threefactorauthonoff = "threefactorauthonoff"
    const val withdrawauthreqests = "withdrawauthreqests"
    const val resendnotification = "resendnotification"
    const val sendafterauthbycosign = "sendafterauthbycosign"
    const val clearnotifications = "clearnotifications"
    const val gasEstimation = "{coin}/gasestimation"
    const val gasNonce = "{coin}/nonce"
    const val withdrawauthreqacceptdecline = "{coin}/withdrawauthreqacceptdecline"
    const val send = "{coin}/send"
    const val deletetransaction = "{coin}/deletetransaction"
    //const val multiful="https://min-api.cryptocompare.com/data/pricemultifull"
    const val multiful = "https://api.coingecko.com/api/v3/coins/markets"
    const val contractAddress = "https://blockscout.com/eth/mainnet/api?module=token&action=getToken"
    const val searchToken = "https://blockscout.com/eth/mainnet/token_autocomplete"
    const val coingeekosearch = "https://api.coingecko.com/api/v3/coins/list"


    const val BackupcosignerStatus = "bkrequestcosigner"
    const val BackupcosignerList = "bkrequestcosignerdetails"
    const val backuprequestcosigneragain = "bkrequestcosigneragain"
    const val bkrequests = "bkrequests"
    const val bkrequestacceptdecline = "bkrequestacceptdecline"
    const val addToken = "addtoken"
    const val updateuserdevicetoken = "updateuserdevicetoken"
    const val coindetail = "coindetail"
    const val savetrnx = "{coin}/savetrnx"
    const val updatetrnxidaftercosignerauth = "updatetrnxidaftercosignerauth"

    const val getcommissiondetails = "getcommissiondetails"
    const val aftersend = "{coin}/aftersend"

    const val disablewallets = "disablewallets"
    const val getUnspent= "bitpay/{address}"
    const val uplSend= "centralize/upl/send"
    const val uplouterwithdraw= "centralize/upl/outerwithdraw"
    const val upliswalletaddress= "centralize/upl/iswalletaddress"
    const val getuplfiatprice= "getuplfiatprice"



    // pin screens
    const val NewPinAfterImport_Screen = "com.JavaWallet.ui.activities.NewPinAfterImport"
    const val Splash_Screen = "com.JavaWallet.ui.activities.Splash"

    // Fcm notifications broadcast filters
    const val showAuthpop = "com.JavaWallet.showAuthPopup"
    const val updateTransactionList = "com.JavaWallet.updatetransactionlist"
    const val updatetBalance = "com.JavaWallet.updatetbalance"
    const val updateDetail = "com.JavaWallet.updatedetail"
    const val updatetBackUpRequestList = "com.JavaWallet.updatetBackUpRequestList"
    const val threeFactorUpadte="com.JavaWallet.threefactorUpadte"

    //Transaction broadcast data
    const val broadTransaction = "com.JavaWallet.broadTransaction"
    const val broad_synced = "com.JavaWallet.broad_synced"
    const val broad_syncing = "com.JavaWallet.broad_syncing"
    const val broad_fee_error = "com.JavaWallet.fee_error"
}