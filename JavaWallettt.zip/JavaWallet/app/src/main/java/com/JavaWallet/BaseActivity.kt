package com.JavaWallet

import android.app.Activity
import android.app.Dialog
import android.app.PendingIntent
import android.app.ProgressDialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.nfc.NfcAdapter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.preference.PreferenceManager
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v7.app.AppCompatActivity
import android.text.Selection
import android.text.Spannable
import android.text.SpannableString
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.Utilities.DialogUtils
import com.JavaWallet.models.Country_model
import com.JavaWallet.networking.*
import com.JavaWallet.ui.fragments.NFCReadFragment
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.google.gson.JsonElement
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.update_popup.*
import org.json.JSONArray
import retrofit2.HttpException
import java.text.DecimalFormat
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

/**
 * Created by user on 4/4/19.
 */

open class BaseActivity : AppCompatActivity() {
    val THEME_DARK = "dark"
    val THEME_LIGHT = "light"
    private lateinit var currentTheme: String
    private lateinit var sharedPref: SharedPreferences
    var mActivity: Activity = this
    lateinit var fm: FragmentManager
    val apiServiceWithAuthorization by lazy { Apiclient.apiInterfaceWithAuthorization(mActivity) }
    val apiServiceWithAuthorization_LINks by lazy { Apiclient.apiInterfaceWithAuthorization_LINKS(mActivity) }
    val apiInterfaceWithAuthorization_Token by lazy { Apiclient.apiInterfaceWithAuthorization_Token(mActivity) }
    lateinit var progressDialog: ProgressDialog
    lateinit var coinlistbase: ArrayList<CoinListData>
    private var CurrencyCoins: String = ""

    var coin_type: ArrayList<String> = ArrayList()
    var trnx_type: ArrayList<String> = ArrayList()
    var status: ArrayList<String> = ArrayList()

    var countryString: ArrayList<Country_model> = ArrayList()
    val WALLET_QRCODE: Int = 99
    val Invite_again: Int = 999

    lateinit var mNfcAdapter_base: NfcAdapter
    var mNfcReadFragmentbase: NFCReadFragment =  NFCReadFragment()
    var isAcceptAuthRequestClicked: Boolean = false
    private val addressPattern = "^0x[0-9a-f]{40}$"

    fun getWalletApplication():  JavaWallet {
        return application as  JavaWallet
    }



    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //updateTheme()
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        mActivity = this
        // getCountries()
        sharedPref = PreferenceManager.getDefaultSharedPreferences(this)
        currentTheme = sharedPref.getString( R.string.prefs_theme_key.toString(), "dark")
        setAppTheme(currentTheme)
        if (isNFC()) {
            mNfcAdapter_base = NfcAdapter.getDefaultAdapter(mActivity);
        }


    }

    override fun onResume() {

        super.onResume()
        val theme = sharedPref.getString( R.string.prefs_theme_key.toString(), "dark")
        if (currentTheme != theme)
            recreate()
        if (isInternetConnected()) {
            getCoinList()
        }

    }

    override fun onStop() {
        super.onStop()

    }



    override fun onRestart() {
        super.onRestart()
    }

    override fun onDestroy() {
        super.onDestroy()

    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (ComponentCallbacks2.TRIM_MEMORY_BACKGROUND == level ||
                ComponentCallbacks2.TRIM_MEMORY_COMPLETE == level ||
                ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN == level) {
            //  showToast("onClose")

        }
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        //showToast("onOpen")
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()

    }


    private fun setAppTheme(currentTheme: String) {
        if (currentTheme.equals("dark")) {
            setTheme( R.style.AppTheme_Dark)
        } else {
            setTheme( R.style.AppTheme_Light)
        }
    }

    fun isValidAddress(addr: String): Boolean {
        println("Incoming Address $addr")
        return if (addr.matches(addressPattern.toRegex())) {
            true
        } else false
    }

    fun getCoinList() {
        if (! JavaWallet.Companion.mPreferenceDataModal.JWTToken.equals("")) {
            CurrencyCoins = ""
            var rqst = SearchRequest("")
            val plainText = Gson().toJson(rqst)
            val cryptLib =  CryptLib()
            val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
            apiServiceWithAuthorization.getCoinList( JavaWallet.Companion.mPreferenceDataModal.JWTToken, cipherText)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponsebase(it) },
                            { error -> handleError(error) })
        }

    }

    fun getCryptodata(Coins: String, currency: String) {
        apiServiceWithAuthorization.getCryptoComapre(Coins, currency)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponsecrypto(it) },
                        { error -> handleError(error) })

    }

    private fun handleResponsebase(it: CoinListResponse) {
        if (it.status) {
            coinlistbase = it.data
            for (i in 0 until coinlistbase.size) {
                if (coinlistbase.get(i).status == 1) {
                    CurrencyCoins = CurrencyCoins + "," + coinlistbase.get(i).coin_gicko_alias
                }
            }
            getCryptodata(CurrencyCoins,  JavaWallet.Companion.mPreferenceDataModal.DefaultCurrency.toUpperCase())
        }
    }

    private fun handleResponsecrypto(it: JsonElement?) {
        val jsonarray = JSONArray(Gson().toJson(it))
         JavaWallet.Companion.mPreferenceDataModal.CRYPTODATA = jsonarray.toString()
         JavaWallet.Companion.setPreference( JavaWallet.Companion.mPreferenceDataModal)
        getuplRate()

    }
    private fun getuplRate() {

        var rqst = uplRequest("upl", JavaWallet.mPreferenceDataModal.DefaultCurrency)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.getuplfiatprice(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponseupl(it) },
                        { error -> handleError(error) })
    }

    private fun handleResponseupl(it: uplResponse) {

        JavaWallet.mPreferenceDataModal.uplvalue = it.data.value
        JavaWallet.mPreferenceDataModal.uplpercenr = it.data.percentChange
        JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)

    }

    fun startNewActivity(activity: Activity) {
        startActivity(Intent(this, activity.javaClass))
    }

    fun startNewActivityClearTask(activity: Activity) {
        startActivity(Intent(this, activity.javaClass).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
    }

    fun callActivityWithData(name: Class<*>, bundle: Bundle) {
        val intent = Intent(this, name)
        intent.putExtras(bundle)
        startActivity(intent)

    }

    fun callActivityWithDataCleartask(name: Class<*>, bundle: Bundle) {
        val intent = Intent(this, name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        intent.putExtras(bundle)
        startActivity(intent)

    }


    fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    fun recreateActivity() {

        val theme = sharedPref.getString( R.string.prefs_theme_key.toString(), "dark")
        if (currentTheme != theme)
            recreate()


        /* val intent = intent
         intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
         finish()
         overridePendingTransition(0, 0)
         startActivity(intent)
         overridePendingTransition(0, 0)*/
    }

    fun setFragment(fragment: Fragment, frag_name: String) {
        fm = supportFragmentManager
        val ft = fm.beginTransaction()
        ft.replace( R.id.factor_frame, fragment)
        ft.commit()
    }

    fun getSharedStr(key: String): String {
        val prefs = mActivity.getSharedPreferences( ConstantsUtils.PREFS_NAME, 0)
        return prefs.getString(key, "")
    }


    fun setSharedStr(key: String, value: String) {
        val sharedPref = mActivity.getSharedPreferences( ConstantsUtils.PREFS_NAME, 0)
        val editor = sharedPref.edit()
        editor.putString(key, value)
        editor.apply()
    }

    fun callActivityforResult(name: Class<*>, reqCode: Int) {
        val intent = Intent(this, name)
        startActivityForResult(intent, reqCode)

    }

    fun callActivityforResultData(name: Class<*>, reqCode: Int, bundle: Bundle) {
        val intent = Intent(this, name)
        intent.putExtras(bundle)
        startActivityForResult(intent, reqCode)

    }

    fun showDialog(message: String, close: Boolean) {
        var dialog = Dialog(this)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        // dialog.window.setGravity(Gravity.BOTTOM)
        dialog.setContentView( R.layout.error_dialog)

        val dialog_message = dialog.findViewById<View>( R.id.dialog_message) as TextView
        val dialog_ok = dialog.findViewById<View>( R.id.dialog_ok) as TextView
        dialog_message.text = message
        dialog_ok.setOnClickListener {
            if (close) {
                dialog.dismiss()
                finish()
            } else {
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    fun isInternetConnected(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE)
        return if (connectivityManager is ConnectivityManager) {
            val networkInfo: NetworkInfo? = connectivityManager.activeNetworkInfo
            networkInfo?.isConnected ?: false
        } else false
    }

    fun convertUTCtoDeviceZone(date: String, output: String): String {
        //"yyyy-MM-dd'T'HH:mm:ss.sssZ"
        return try {
            var dateReturn = ""
            if (!date.isEmpty()) {
                val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH)
                sdf.timeZone = TimeZone.getTimeZone("UTC")
                val output = SimpleDateFormat(output, Locale.ENGLISH)
                val d = sdf.parse(date.trimStart())
                sdf.timeZone = TimeZone.getDefault()
                dateReturn = output.format(d)
            }
            dateReturn
        } catch (e: Exception) {
            date
        }

    }

    fun converttimeformat(date: String, output: String): String {
        //"yyyy-MM-dd'T'HH:mm:ss.sssZ"
        return try {
            var dateReturn = ""
            if (!date.isEmpty()) {
                val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH)
                val output = SimpleDateFormat(output, Locale.ENGLISH)
                val d = sdf.parse(date.trimStart())
                dateReturn = output.format(d)
            }
            dateReturn
        } catch (e: Exception) {
            date
        }

    }

    fun convertime(date: String): String {
        //"yyyy-MM-dd'T'HH:mm:ss.sssZ"
        return try {
            var dateReturn = ""
            if (!date.isEmpty()) {
                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)
                sdf.timeZone = TimeZone.getTimeZone("UTC")
                val output = SimpleDateFormat("yyyy-MM-dd")
                val d = sdf.parse(date.trimStart())
                sdf.timeZone = TimeZone.getDefault()
                dateReturn = output.format(d)
            }
            dateReturn
        } catch (e: Exception) {
            date
        }

    }

    fun isNFC(): Boolean {


        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_NFC)
        return false
    }

    fun hidekeyboard(view: View) {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0)
    }

    fun handleError(error: Throwable) {

        when (error) {
            is HttpException -> {
                when {

                    error.code() == 400 -> {
                        /* val responseBody = error.response().errorBody()?.string()
                         var message = Gson().fromJson<BaseResponse>(responseBody, BaseResponse::class.java)
                         showToast(message.message)*/

                    }
                    else -> {

                        /*val responseBody = error.response().errorBody()?.string()
                        var message = Gson().fromJson<ErrorResponse>(responseBody, BaseResponse::class.java)
                        showToast(message.message)*/


                    }

                }
            }
        }
    }

    fun showLoading(message: String) {
        try {
            Handler(Looper.getMainLooper()).post {
                progressDialog = DialogUtils.showLoading(this, message)
            }
        } catch (e: Exception) {
            e.toString()
        }
    }

    fun showLoading() {
        try {
            Handler(Looper.getMainLooper()).post {
                progressDialog = DialogUtils.showLoading(this)
            }
        } catch (e: Exception) {
            e.toString()
        }
    }

    fun hideLoading() {
        try {
            Handler(Looper.getMainLooper()).post {
                try {
                    if (progressDialog != null && progressDialog!!.isShowing) {
                        progressDialog!!.cancel()
                    }
                } catch (e: Exception) {
                    e.toString()
                }

            }
        } catch (e: Exception) {
            e.toString()
        }
    }

    fun loadPicture_circle(imageView: ImageView, url: String) {
        Glide.with(mActivity).load(url)
                .into(imageView)
    }

    fun decimalConverterUpto(value: Double, places: Int): String {
        val decimalFormatter = DecimalFormat("##.#")
        decimalFormatter.minimumFractionDigits = 2
        decimalFormatter.maximumFractionDigits = places
        return decimalFormatter.format(value)
    }

    fun getCountries() {
        try {
            val locales = Locale.getISOCountries()
            for (countryCode in locales) {
                val obj = Locale("", countryCode)
                countryString.add(Country_model(obj.displayCountry, obj.isO3Country, obj.country))
            }
            countryString.sortBy { it.countryName }
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    fun enbleNfc() {
        if (isNFC()) {
            var tagDetected = IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
            var ndefDetected = IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
            var techDetected = IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED);
            val nfcIntentFilter = arrayOf(techDetected, tagDetected, ndefDetected)
            var pendingIntent = PendingIntent.getActivity(
                    this, 0, Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
            if (mNfcAdapter_base != null)
                mNfcAdapter_base.enableForegroundDispatch(this, pendingIntent, nfcIntentFilter, null);
        }
    }

    fun getHours(lastrecorddate: String, currentdate: String): Long {

        /*String dateStart = "01/14/2012 09:29:58";
            String dateStop = "01/15/2012 10:31:48";*/

        //HH converts hour in 24 hours format (0-23), day calculation
        //SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        val format = SimpleDateFormat("MM/dd/yyyy HH:mm:ss")

        var d1: Date? = null
        var d2: Date? = null
        var hours: Long = 0
        try {
            d1 = format.parse(lastrecorddate)
            d2 = format.parse(currentdate)

            //in milliseconds
            val diff = d2!!.time - d1!!.time

            val seconds = diff / 1000
            val minutes = seconds / 60
            hours = minutes / 60
            val days = hours / 24


        } catch (e: Exception) {
            e.printStackTrace()
        }

        return hours

    }


    fun getHoursminutes(lastrecorddate: String, currentdate: String): String {

        val format = SimpleDateFormat("MM/dd/yyyy HH:mm:ss")
        var d1: Date? = null
        var d2: Date? = null
        var hoursmin: String = ""
        try {
            d1 = format.parse(lastrecorddate)
            d2 = format.parse(currentdate)
            //in milliseconds
            val diff = d2!!.time - d1!!.time
            val diffSeconds = diff / 1000 % 60
            val diffMinutes = diff / (60 * 1000) % 60
            val diffHours = diff / (60 * 60 * 1000) % 24
            val diffDays = diff / (24 * 60 * 60 * 1000)
            hoursmin = diffHours.toString() + ":" + diffMinutes.toString()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return hoursmin
    }

    fun CheckDates(startDate: String, endDate: String): Boolean {

        val dfDate = SimpleDateFormat("dd/MM/yyyy")

        var b = false

        try {
            if (dfDate.parse(startDate).before(dfDate.parse(endDate))) {
                b = true  // If start date is before end date.
            } else if (dfDate.parse(startDate) == dfDate.parse(endDate)) {
                b = true  // If two dates are equal.
            } else {
                b = false // If start date is after the end date.
            }
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return b
    }

    fun TextView.makeLinks(vararg links: Pair<String, View.OnClickListener>) {
        val spannableString = SpannableString(this.text)
        for (link in links) {
            val clickableSpan = object : ClickableSpan() {
                override fun onClick(view: View) {
                    Selection.setSelection((view as TextView).text as Spannable, 0)
                    view.invalidate()
                    link.second.onClick(view)
                }
            }
            val startIndexOfLink = this.text.toString().indexOf(link.first)
            spannableString.setSpan(clickableSpan, startIndexOfLink, startIndexOfLink + link.first.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            spannableString.setSpan(ForegroundColorSpan(getResources().getColor( R.color.colorAccent_Darktheme)), startIndexOfLink, startIndexOfLink + link.first.length, 0);

        }
        this.movementMethod = LinkMovementMethod.getInstance() // without LinkMovementMethod, link can not click
        this.setText(spannableString, TextView.BufferType.SPANNABLE)
    }

    fun showVersionCheckDialog() {
        try {
            if (JavaWallet.mPreferenceDataModal.NEW_VERSON) {
                JavaWallet.mPreferenceDataModal.NEW_VERSON = false
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                Handler(Looper.getMainLooper()).post {
                    val dialog = Dialog(this)
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                    dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
                    dialog.setContentView(R.layout.update_popup)
                    dialog.tvLatter.setOnClickListener {
                        dialog.cancel()
                    }
                    dialog.tvUpdate.setOnClickListener {
                        dialog.cancel()
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.JavaWallet"))
                        startActivity(intent)
                    }
                    dialog.window!!.setLayout(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    dialog.window!!.setGravity(Gravity.CENTER)
                    dialog.setCancelable(false)
                    dialog.show()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }





}

