package com.JavaWallet.Utilities;

import com.JavaWallet.networking.ManageWalletData;

import java.util.ArrayList;

public interface OnCustomerListChangedListener {
    void onNoteListChanged(ArrayList<ManageWalletData> customers);
}