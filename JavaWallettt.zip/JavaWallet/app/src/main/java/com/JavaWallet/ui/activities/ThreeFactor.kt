package com.JavaWallet.ui.activities

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v4.content.LocalBroadcastManager
import android.view.View
import com.JavaWallet.BaseActivity
import com.JavaWallet.ConstantsUtils
import com.JavaWallet.R
import com.JavaWallet.Utility
import com.JavaWallet.ui.fragments.RequestReceived_frag
import com.JavaWallet.ui.fragments.RequestSent_frag
import kotlinx.android.synthetic.main.activity_three_factor.*
import kotlinx.android.synthetic.main.header_title.*

class ThreeFactor : BaseActivity(), View.OnClickListener {

    private var isthemeDark: Boolean = true

    private lateinit var localBroadcastManager: LocalBroadcastManager
    private lateinit var getB_Receiver: GetBroadcast
    private lateinit var threeFactorFilter: IntentFilter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_three_factor)

        tv_title.text = getString(R.string.titlethreefa)
        iv_back.setOnClickListener {
            finish()
        }

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            isthemeDark = true
            iv_back.setColorFilter(resources.getColor(R.color.white));
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            isthemeDark = false
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
        } else {
            isthemeDark = true
            iv_back.setColorFilter(resources.getColor(R.color.white));
        }

        localBroadcastManager = LocalBroadcastManager.getInstance(mActivity)
        getB_Receiver = GetBroadcast()
        threeFactorFilter = IntentFilter(ConstantsUtils.threeFactorUpadte)


    }

    override fun onResume() {
        super.onResume()
        try {
            var b: Bundle? = Bundle()
            b = intent.extras
            var is_sent = b!!.getBoolean(getString(R.string.is_sent))
            if (is_sent) {
                sentFrag()
            } else {
                Rec_frag()
            }

        } catch (e: Exception) {
            e.printStackTrace()
            sentFrag()
        }

        onClick()
        localBroadcastManager.registerReceiver(getB_Receiver, threeFactorFilter)
    }

    override fun onPause() {
        super.onPause()
        localBroadcastManager.unregisterReceiver(getB_Receiver)
    }


    private fun onClick() {

        tv_sent.setOnClickListener(this)
        tv_received.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {

        when (p0) {
            tv_sent -> {
                sentFrag()
            }
            tv_received -> {
                Rec_frag()

            }


        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        var fragment = supportFragmentManager.findFragmentById(R.id.factor_frame) as RequestSent_frag
        fragment.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    private fun Rec_frag() {

        if (isthemeDark) {
            tv_received.setTextColor(ContextCompat.getColor(this, R.color.blacknew));
            tv_sent.setTextColor(ContextCompat.getColor(this, R.color.white));
        } else {
            tv_received.setTextColor(ContextCompat.getColor(this, R.color.qPrimary_text_colorwhite_Darktheme));
            tv_sent.setTextColor(ContextCompat.getColor(this, R.color.blacknew));
        }
        setFragment(RequestReceived_frag(), "R_RECEIVE")
    }

    private fun sentFrag() {
        if (isthemeDark) {
            tv_sent.setTextColor(ContextCompat.getColor(this, R.color.blacknew));
            tv_received.setTextColor(ContextCompat.getColor(this, R.color.white));
        } else {
            tv_sent.setTextColor(ContextCompat.getColor(this, R.color.qPrimary_text_colorwhite_Darktheme));
            tv_received.setTextColor(ContextCompat.getColor(this, R.color.blacknew));
        }


        setFragment(RequestSent_frag(), "R_SENT")

    }

    inner class GetBroadcast : BroadcastReceiver() {

        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ConstantsUtils.threeFactorUpadte) {

                val is_sentB = intent.extras!!.getBoolean("is_sentB")
                if (is_sentB) {
                    sentFrag()
                } else if (!is_sentB) {
                    Rec_frag()
                } else {
                    sentFrag()
                }


            }
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Invite_again) {
            val fragment = supportFragmentManager.findFragmentById(R.id.factor_frame)
//                    val activeFragment = adapter.getItem(0)
            (fragment!! as RequestSent_frag).onActivityResult(requestCode, resultCode, data)
        }
    }
}
