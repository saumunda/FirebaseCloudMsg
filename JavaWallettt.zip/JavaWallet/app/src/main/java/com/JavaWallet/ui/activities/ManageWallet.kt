package com.JavaWallet.ui.activities

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.helper.ItemTouchHelper
import android.view.View
import android.view.Window
import android.widget.TextView
import com.JavaWallet.*
import com.JavaWallet.Adapters.ManageAdapter
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.Utilities.OnCustomerListChangedListener
import com.JavaWallet.Utilities.OnStartDragListener
import com.JavaWallet.Utilities.SimpleItemTouchHelperCallback
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_manage_wallet.*
import kotlinx.android.synthetic.main.header_title.*
import com.JavaWallet.networking.*
import org.json.JSONArray


class ManageWallet :  BaseActivity(), View.OnClickListener, ManageAdapter.Listener, OnCustomerListChangedListener,
        OnStartDragListener {


    private val MANAGEWALLET: Int = 11
    var walletlist: ArrayList<ManageWalletData> = ArrayList()

    var Combinedwalletlist: ArrayList<CombinedManageWalletData> = ArrayList()
    var sortwalletlist: ArrayList<ManageWalletData> = ArrayList()
    private var list_pos: Int = 0
    private var user_coin_id: Int = 0
    var ishowDrag: Boolean = false
    var issorted: Boolean = false
    private var mItemTouchHelper: ItemTouchHelper? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_wallet)
        tv_title.text = getString(R.string.titlemanagewallet)
        iv_expand.visibility = View.VISIBLE
        tv_done.visibility = View.GONE
    }

    override fun onResume() {
        super.onResume()
        iv_back.setOnClickListener {
            if (issorted) {
                orderDialog()
            } else {
                finish()
            }
        }

        iv_expand.setOnClickListener {

            tv_done.visibility = View.VISIBLE
            iv_expand.visibility = View.GONE
            iv_addnewWallet.visibility = View.GONE
            ishowDrag = true
            adpter = ManageAdapter(walletlist, Combinedwalletlist, this, ishowDrag, this, this)
            recycl_manage.adapter = adpter
            if (ishowDrag) {
                val callback = SimpleItemTouchHelperCallback(adpter)
                mItemTouchHelper = ItemTouchHelper(callback);
                mItemTouchHelper!!.attachToRecyclerView(recycl_manage);
            } else {
                mItemTouchHelper!!.attachToRecyclerView(null);
            }


        }
        tv_done.setOnClickListener {
            DoneClick()

        }


        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
        } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        }
        applyAdapter()
        iv_addnewWallet.setOnClickListener(this)
        if (isInternetConnected()) {
            getWalletList()
        } else {
            showDialog(getString(R.string.network_error), false)
        }
    }

    private fun DoneClick() {

        tv_done.visibility = View.GONE
        iv_expand.visibility = View.VISIBLE
        iv_addnewWallet.visibility = View.VISIBLE
        ishowDrag = false
        if (sortwalletlist.size > 0) {
            Combinedwalletlist.clear()
            val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.CRYPTODATA)
            for (i in 0 until sortwalletlist.size) {
                var mdl = CombinedManageWalletData()
                for (j in 0 until jsonarray.length()) {
                    var jsnobj = jsonarray.getJSONObject(j)
                    if (sortwalletlist[i].coinSymbol.equals(jsnobj.getString("symbol"))) {
                        mdl.listbalance = sortwalletlist[i].balance
                        mdl.current_price = jsnobj.getString("current_price").toDouble()
                        mdl.listcoin_symbol = sortwalletlist[i].coinSymbol
                        mdl.jsncoin_symbol = jsnobj.getString("symbol")
                        break;
                    } else {
                        mdl.listbalance = 0.0
                        mdl.current_price = 0.0
                        mdl.listcoin_symbol = ""
                        mdl.jsncoin_symbol = ""
                    }
                }
                Combinedwalletlist.add(mdl)

            }

            adpter = ManageAdapter(sortwalletlist, Combinedwalletlist, this, ishowDrag, this, this)
        } else {
            adpter = ManageAdapter(walletlist, Combinedwalletlist, this, ishowDrag, this, this)
        }
        recycl_manage.adapter = adpter
        if (ishowDrag) {
            val callback = SimpleItemTouchHelperCallback(adpter)
            mItemTouchHelper = ItemTouchHelper(callback);
            mItemTouchHelper!!.attachToRecyclerView(recycl_manage);
        } else {
            mItemTouchHelper!!.attachToRecyclerView(null);
        }
        if (issorted) {
            sortApi()
        }
    }

    private fun orderDialog() {
        var dialog = Dialog(this)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.logout_dialog)
        val dialog_message = dialog.findViewById<View>(R.id.dialog_message) as TextView
        val dialog_yes = dialog.findViewById<View>(R.id.dialog_yes) as TextView
        val dialog_no = dialog.findViewById<View>(R.id.dialog_no) as TextView
        dialog_message.text = getString(R.string.saveshuffleorder)
        dialog_yes.setOnClickListener {
            dialog.dismiss()
            DoneClick()
        }
        dialog_no.setOnClickListener {
            dialog.dismiss()
            finish()
        }
        dialog.show()

    }


    private var user_coin_idss: String = ""

    private fun sortApi() {

        for (i in 0 until sortwalletlist.size) {
            if (sortwalletlist.size - 1 == i) {
                user_coin_idss = user_coin_idss + sortwalletlist.get(i).userCoinId
            } else {
                user_coin_idss = user_coin_idss + sortwalletlist.get(i).userCoinId + ","
            }
        }

        var rqst = sortWalletRequest(user_coin_idss)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        showLoading()
        apiServiceWithAuthorization.sortWallet(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }

    private fun getWalletList() {
        showLoading()
        apiServiceWithAuthorization.managewallet(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })
    }

    private lateinit var adpter: ManageAdapter

    private fun handleResponse(it: Any?) {

        when (it) {

            is ManageWalletResponse -> {
                hideLoading()
                if (it.status) {
                    walletlist = it.data
                    if (walletlist.size == 0 || walletlist.size == 1) {
                        tv_one.text = "" + walletlist.size + " " + getString(R.string.Wallet)
                    } else {
                        tv_one.text = "" + walletlist.size + " " + getString(R.string.Wallets)
                    }
                    val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.CRYPTODATA)
                    for (i in 0 until walletlist.size) {
                        var mdl = CombinedManageWalletData()
                        for (j in 0 until jsonarray.length()) {
                            var jsnobj = jsonarray.getJSONObject(j)
                            if (walletlist[i].coinSymbol.equals(jsnobj.getString("symbol"))) {
                                mdl.listbalance = walletlist[i].balance
                                mdl.current_price = jsnobj.getString("current_price").toDouble()
                                mdl.listcoin_symbol = walletlist[i].coinSymbol
                                mdl.jsncoin_symbol = jsnobj.getString("symbol")
                                break;
                            } else {
                                mdl.listbalance = 0.0
                                mdl.current_price = 0.0
                                mdl.listcoin_symbol = ""
                                mdl.jsncoin_symbol = ""
                            }
                        }
                        Combinedwalletlist.add(mdl)

                    }
                    adpter = ManageAdapter(walletlist, Combinedwalletlist, this, ishowDrag, this, this)
                    recycl_manage.adapter = adpter
                    if (ishowDrag) {
                        val callback = SimpleItemTouchHelperCallback(adpter)
                        mItemTouchHelper = ItemTouchHelper(callback);
                        mItemTouchHelper!!.attachToRecyclerView(recycl_manage);
                    } else {
                        mItemTouchHelper!!.attachToRecyclerView(null);
                    }


                }
            }
            is BaseResponse -> {
                hideLoading()
                walletlist.removeAt(list_pos)
                adpter.notifyDataSetChanged()
                if (walletlist.size == 0) {
                    tv_one.text = "" + walletlist.size + " " + getString(R.string.Wallet)
                    showWalletDialog()
                } else if (walletlist.size == 1) {
                    tv_one.text = "" + walletlist.size + " " + getString(R.string.Wallet)
                } else {
                    tv_one.text = "" + walletlist.size + " " + getString(R.string.Wallets)
                }


            }

            is BaseResponsenew -> {
                hideLoading()
                if (it.status) {
                    issorted = false
                } else {
                    showToast(it.message)
                }
            }
        }
    }

    private fun showWalletDialog() {

        var dialog = Dialog(this)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.logout_dialog)
        val dialog_message = dialog.findViewById<View>(R.id.dialog_message) as TextView
        val dialog_yes = dialog.findViewById<View>(R.id.dialog_yes) as TextView
        val dialog_no = dialog.findViewById<View>(R.id.dialog_no) as TextView
        dialog_message.text = getString(R.string.wanttoaddwallet)
        dialog_yes.setOnClickListener {
            dialog.dismiss()
            startNewActivity(AddNewWallet())
        }
        dialog_no.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun applyAdapter() {
        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
        recycl_manage.layoutManager = layoutManager

    }

    override fun onClick(p0: View?) {
        when (p0) {

            iv_addnewWallet -> {

                startNewActivity(AddNewWallet())
            }

        }
    }


    override fun onItemClick(walletListData: ManageWalletData, position: Int) {
        user_coin_id = walletListData.userCoinId
        list_pos = position
        disableCoinApi()

    }

    private fun disableCoinApi() {
        showLoading()
        var rqst = DisableCoinRequest(0, user_coin_id)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.disablecoin(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })
    }

    override fun onNoteListChanged(customers: java.util.ArrayList<ManageWalletData>?) {

        sortwalletlist = customers as ArrayList<ManageWalletData>
        issorted = true
    }

    override fun onStartDrag(viewHolder: RecyclerView.ViewHolder?) {
        mItemTouchHelper!!.startDrag(viewHolder!!);
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (data != null) {
            ishowDrag = data!!.getBooleanExtra(getString(R.string.ishowDrag), false)

        }

    }
}
