package com.JavaWallet.ui.fragments

import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.Adapters.RequsetReceived_Adapter
import com.JavaWallet.BaseFragment
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.networking.*
 import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.requestreceived_frag.*
import retrofit2.HttpException

class RequestReceived_frag : BaseFragment(), RequsetReceived_Adapter.InviteListner {


    private lateinit var linearLayoutManager: LinearLayoutManager
    lateinit var userlist: ArrayList<ReceiveAuthReq>
    private lateinit var adaptr: RequsetReceived_Adapter
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.requestreceived_frag, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    override fun onResume() {
        super.onResume()
        if (mActivity.isInternetConnected()) {
            linearLayoutManager = LinearLayoutManager(mActivity)
            rcycl_receiverequests.layoutManager = linearLayoutManager
            getData()
        } else {
            mActivity.showDialog(getString(R.string.network_error), false)
        }
    }

    private fun getData() {
        mActivity.showLoading()

        mActivity.apiServiceWithAuthorization.getReceivedRequests(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); mActivity.hideLoading() })
    }

    private fun handleError(error: Throwable?) {
        when (error) {
            is HttpException -> {
                when {

                    error.code() == 500 -> {

                        tv_nodata.visibility = View.VISIBLE
                        rcycl_receiverequests.visibility = View.GONE
                    }

                }
            }
        }
    }


    override fun onaccept_Click(userlist: ArrayList<ReceiveAuthReq>, position: Int, isremove: Boolean) {
        AcceptDeclineRequest(userlist.get(position).authId, "1")
    }

    override fun ondecline_Click(userlist: ArrayList<ReceiveAuthReq>, position: Int, isremove: Boolean) {
        if (isremove) {
            AcceptDeclineRequest(userlist.get(position).authId, "3")
        } else {
            AcceptDeclineRequest(userlist.get(position).authId, "2")
        }

    }

    private fun AcceptDeclineRequest(authId: Int, status: String) {

        var rqst = AcceptDeclineSendRequest(authId, status)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.apiServiceWithAuthorization.acceptDeclineThreeFactor(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error); })
    }

    private fun handleResponse(it: Any?) {

        when (it) {
            is ReceivedRequestsResponse -> {
                mActivity.hideLoading()
                if (it.status) {
                    userlist = it.data.receiveAuthReqs
                    adaptr = RequsetReceived_Adapter(userlist, this)
                    rcycl_receiverequests.adapter = adaptr
                }
            }

            is InviteAgainResponse -> {
                mActivity.hideLoading()
                if (it.status) {
                    getData()
                } else {
                    mActivity.showToast("Something wrong happened")
                }

            }

        }
    }


}