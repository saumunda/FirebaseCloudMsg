package com.JavaWallet.ui.fragments


import android.app.Dialog
import android.content.Context
import android.view.WindowManager
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import com.JavaWallet.R
import com.JavaWallet.ui.activities.MainActivity
import com.JavaWallet.ui.activities.Send

import kotlinx.android.synthetic.main.nfcscan.*


class Ready2ScanDialog(context: Context , from : String) : Dialog(context, R.style.transparentDialog) {
    private val opacity = 0.85f;
    private var mListener: Listener? = null
    var fromscreen =""

    init {
        fromscreen = from
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.setGravity(Gravity.BOTTOM)
        window.setDimAmount(opacity)

        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.nfcscan)
        setCancelable(false)
        setCanceledOnTouchOutside(true)

        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)

        dialog_readyscan_cancel.setOnClickListener{
            this.dismiss()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (fromscreen == "Send") {
            mListener = context as Send
        } else {
            mListener = context as MainActivity
        }

        mListener!!.onDialogDisplayed()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        mListener!!.onDialogDismissed()
    }
}