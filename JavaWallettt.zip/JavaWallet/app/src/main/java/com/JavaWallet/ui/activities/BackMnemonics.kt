package com.JavaWallet.ui.activities

import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_back_mnemonics.*
import kotlinx.android.synthetic.main.header_title.*
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import com.JavaWallet.*


class BackMnemonics : BaseActivity(), View.OnClickListener {

    private var isthemeDark: Boolean = false
    private var cb_one: Boolean = false
    private var cb_two: Boolean = false
    private var cb_three: Boolean = false
    private var cb_four: Boolean = false
    private var cb_five: Boolean = false

    private var cb_termsbln: Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_back_mnemonics)

    }

    override fun onResume() {
        super.onResume()
        tv_title.text = getString(R.string.titlemnemonics)
        tv_title.setTextColor(resources.getColor(R.color.orange_light))
        tv_mnemonics_data.text = JavaWallet.mPreferenceDataModal.COIN_MNEMONICS
        iv_back.setOnClickListener {
            finish()
        }

        tv_next.setOnClickListener(this)
        tv_confirm.setOnClickListener(this)
        tv_copy.setOnClickListener(this)
//I have read, understood and agree to the terms of use.
       /* val checkBoxText = getString(R.string.terms_backmnemonics)

        cb_terms.setText(Html.fromHtml(checkBoxText))
        cb_terms.setMovementMethod(LinkMovementMethod.getInstance())*/

        tv_terms.makeLinks(
                Pair(getString(R.string.termsofuse), View.OnClickListener {
                    val i = Intent(Intent.ACTION_VIEW)
                    i.data = Uri.parse(getString(R.string.terms_url))
                    startActivity(i)
                }))
        cb_mnemonics.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                tv_next.visibility = View.VISIBLE
            } else {
                tv_next.visibility = View.GONE
            }
        }

        cb_understand.setOnCheckedChangeListener { buttonView, isChecked ->
            if(buttonView.isPressed){
                if (isChecked) {
                    cb_one = true
                    if (cb_one && cb_two && cb_three && cb_four && cb_five && cb_termsbln) {
                        tv_confirm.isEnabled = true
                        tv_confirm.alpha = 1.0f
                    }
                } else {
                    cb_one = false
                    tv_confirm.isEnabled = false
                    tv_confirm.alpha = 0.5f
                }
            }

        }
        cb_inunderstand.setOnCheckedChangeListener { buttonView, isChecked ->
            if(buttonView.isPressed){
                if (isChecked) {
                    cb_two = true
                    if (cb_one && cb_two && cb_three && cb_four && cb_five && cb_termsbln) {
                        tv_confirm.isEnabled = true
                        tv_confirm.alpha = 1.0f
                    }
                } else {
                    cb_two = false
                    tv_confirm.isEnabled = false
                    tv_confirm.alpha = 0.5f
                }
            }

        }


        cb_third.setOnCheckedChangeListener { buttonView, isChecked ->
            if(buttonView.isPressed){
                if (isChecked) {
                    cb_three = true
                    if (cb_one && cb_two && cb_three && cb_four && cb_five && cb_termsbln) {
                        tv_confirm.isEnabled = true
                        tv_confirm.alpha = 1.0f
                    }
                } else {
                    cb_three = false
                    tv_confirm.isEnabled = false
                    tv_confirm.alpha = 0.5f
                }
            }

        }

        cb_fourth.setOnCheckedChangeListener { buttonView, isChecked ->
            if(buttonView.isPressed){
                if (isChecked) {
                    cb_four = true
                    if (cb_one && cb_two && cb_three && cb_four && cb_five && cb_termsbln) {
                        tv_confirm.isEnabled = true
                        tv_confirm.alpha = 1.0f
                    }
                } else {
                    cb_four = false
                    tv_confirm.isEnabled = false
                    tv_confirm.alpha = 0.5f
                }
            }

        }

        cb_fifth.setOnCheckedChangeListener { buttonView, isChecked ->
            if(buttonView.isPressed){
                if (isChecked) {
                    cb_five = true
                    if (cb_one && cb_two && cb_three && cb_four && cb_five && cb_termsbln) {
                        tv_confirm.isEnabled = true
                        tv_confirm.alpha = 1.0f
                    }
                } else {
                    cb_five = false
                    tv_confirm.isEnabled = false
                    tv_confirm.alpha = 0.5f
                }
            }

        }

        cb_terms.setOnCheckedChangeListener { buttonView, isChecked ->
            if(buttonView.isPressed){
                if (isChecked) {
                    cb_termsbln = true
                    if (cb_one && cb_two && cb_three && cb_four && cb_five && cb_termsbln) {
                        tv_confirm.isEnabled = true
                        tv_confirm.alpha = 1.0f
                    }
                } else {
                    cb_termsbln = false
                    tv_confirm.isEnabled = false
                    tv_confirm.alpha = 0.5f
                }
            }

        }


        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            isthemeDark = true
            tv_one.alpha=0.5f
            iv_back.setColorFilter(resources.getColor(R.color.white));
            tv_title.setTextColor(resources.getColor(R.color.white))
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            isthemeDark = false
            tv_one.alpha=1.0f
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
            tv_title.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
        } else {
            tv_one.alpha=0.5f
            isthemeDark = true
            iv_back.setColorFilter(resources.getColor(R.color.white));
            tv_title.setTextColor(resources.getColor(R.color.white))
        }

    }

    override fun onClick(p0: View?) {

        when (p0) {

            tv_next -> {
                var bndl = Bundle()
                bndl.putBoolean(getString(R.string.isfromcreate), true)
                callActivityWithData(Backupsecond::class.java, bndl)

                /*hdr.visibility = View.GONE
                lnr_one_two.visibility = View.GONE
                tv_next.visibility = View.GONE
                cb_terms.visibility = View.VISIBLE
                tv_confirm.visibility = View.VISIBLE
                lnr_two_two.visibility = View.VISIBLE

                tv_confirm.isEnabled = false
                Handler().postDelayed({
                    tv_confirm.alpha = 0.5f
                }, 500)*/

//                if (!isthemeDark) {
//                    main_back.setBackgroundColor(getResources().getColor(R.color.white))
//                }
            }

            tv_confirm -> {
                //new user isactive will be 0
                JavaWallet.mPreferenceDataModal.ISSHOW_VIEW = true
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                ConstantsUtils.isActive = 0
                startNewActivityClearTask(MainActivity())
                finish()
            }

            tv_copy -> {

                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText(getString(R.string.label), tv_mnemonics_data.text.toString())
                clipboard.primaryClip = clip
                showToast(getString(R.string.mnemonicscopied))
            }

        }

    }

    override fun onBackPressed() {
        if (lnr_two_two.visibility == View.VISIBLE) {

        } else {
            super.onBackPressed()
        }


    }

}
