package com.JavaWallet.Adapters

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.TextView
import com.JavaWallet.BaseActivity
import com.JavaWallet.networking.SentAuthReq
 import kotlinx.android.synthetic.main.sent_item.view.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
 import java.text.ParseException


/**
 * Created by user on 11/4/19.
 */

class RequsetSent_Adapter(private val userlist: ArrayList<SentAuthReq>, private val lstnr:   InviteListner) : RecyclerView.Adapter<RequsetSent_Adapter.ViewHolder>() {
    private lateinit var mContext: Context

    interface InviteListner {
        fun oninvite_Click(userlist: ArrayList<SentAuthReq>, position: Int)
        fun onremove_Click(userlist: SentAuthReq, position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):   ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(com.JavaWallet.R.layout.sent_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder:   ViewHolder, position: Int) {
        var listdata = userlist.get(position)
        holder.itemView.tv_name.text = listdata.label
        holder.itemView.tv_number.text = listdata.toMobile
        holder.itemView.tv_intial.text = listdata.label.get(0).toUpperCase().toString()

        var oldfa_date=(mContext as BaseActivity).convertUTCtoDeviceZone(listdata.updatedAt, "MM/dd/yyyy HH:mm:ss")
        val sdf = SimpleDateFormat("MM/dd/yyyy HH:mm:ss")
        val c = Calendar.getInstance()
        try {
            c.time = sdf.parse(oldfa_date)
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        c.add(Calendar.DATE, 1);
        var newDate = sdf.format(c.getTime());

        val c_new = Calendar.getInstance()
        var diff = (mContext as  BaseActivity).getHoursminutes(sdf.format(c_new.getTime()),newDate)

        var hour=diff.substring(0, diff.indexOf(":"))
        if (listdata.status == 0) {
            holder.itemView.tv_invitestatus.visibility = View.VISIBLE
            holder.itemView.tv_invite.visibility = View.VISIBLE
            holder.itemView.tv_time.visibility = View.VISIBLE
            holder.itemView.tv_invitestatus.text = mContext.getString(com.JavaWallet.R.string.invitation_sent)
            holder.itemView.tv_invite.text = mContext.getString(com.JavaWallet.R.string.invite_again)
            holder.itemView.tv_remove.text = mContext.getString(com.JavaWallet.R.string.remove)
            holder.itemView.tv_invitestatus.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.blacknew))
        } else if (listdata.status == 1) {
            holder.itemView.tv_invitestatus.visibility = View.VISIBLE
            holder.itemView.tv_invite.visibility = View.GONE
            holder.itemView.tv_invitestatus.text = "Active "
            holder.itemView.tv_invitestatus.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.greenbottom))
            holder.itemView.tv_time.visibility = View.GONE
            holder.itemView.tv_remove.text = mContext.getString(com.JavaWallet.R.string.remove)
        } else if (listdata.status == 2) {

            if(hour.toInt()>24){
                holder.itemView.lnr_actv.visibility=View.VISIBLE
                holder.itemView.lnr_deleted.visibility=View.GONE


                holder.itemView.tv_invitestatus.visibility = View.VISIBLE
                holder.itemView.tv_invite.visibility = View.VISIBLE
                holder.itemView.tv_remove.visibility = View.VISIBLE
                holder.itemView.tv_time.visibility = View.VISIBLE
                holder.itemView.tv_invitestatus.text = "Invitation declined"
                holder.itemView.tv_invite.text = mContext.getString(com.JavaWallet.R.string.invite_again)
                holder.itemView.tv_remove.text = mContext.getString(com.JavaWallet.R.string.remove)
                holder.itemView.tv_invitestatus.setTextColor(mContext.resources.getColor(com.JavaWallet.R.color.blacknew))

            }else{
                holder.itemView.lnr_actv.visibility=View.GONE
                holder.itemView.lnr_deleted.visibility=View.VISIBLE
                holder.itemView.tv_opted.text="${listdata.label} has opted out"
                holder.itemView.tv_timediff.text=diff
                holder.itemView.itemm.alpha=0.5f
            }


        } else if (listdata.status == 3) {
            holder.itemView.lnr_actv.visibility=View.GONE
            holder.itemView.lnr_deleted.visibility=View.VISIBLE
            holder.itemView.tv_opted.text="${listdata.label} has opted out"
            holder.itemView.tv_timediff.text=diff
            holder.itemView.itemm.alpha=0.5f
        }

        holder.itemView.tv_time.text = (mContext as  BaseActivity).convertUTCtoDeviceZone(listdata.createdAt, "dd-MM-yyyy")
        holder.itemView.tv_invite.setOnClickListener {
            lstnr.oninvite_Click(userlist, position)
        }

        holder.itemView.tv_remove.setOnClickListener {

            var dialog = Dialog(mContext)
            dialog.setCancelable(false)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setContentView(com.JavaWallet.R.layout.logout_dialog)
            val dialog_message = dialog.findViewById<View>(com.JavaWallet.R.id.dialog_message) as TextView
            val dialog_yes = dialog.findViewById<View>(com.JavaWallet.R.id.dialog_yes) as TextView
            val dialog_no = dialog.findViewById<View>(com.JavaWallet.R.id.dialog_no) as TextView
            dialog_message.text = "Do you want to remove " + listdata.label + " remove from the list?"
            dialog_yes.setOnClickListener {
                dialog.dismiss()
                lstnr.onremove_Click(listdata, position)

            }
            dialog_no.setOnClickListener { dialog.dismiss() }
            dialog.show()
        }


    }

    override fun getItemCount(): Int {
        return userlist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context
        }

        fun bindItems() {

        }
    }
}