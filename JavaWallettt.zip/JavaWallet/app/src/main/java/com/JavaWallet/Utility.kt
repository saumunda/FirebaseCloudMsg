package com.JavaWallet

import android.content.Context
import android.preference.PreferenceManager

object Utility {

    fun setTheme(context: Context, theme: String) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        prefs.edit().putString(R.string.prefs_theme_key.toString(), theme).apply();
    }

    fun getTheme(context: Context): String {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        return prefs.getString(R.string.prefs_theme_key.toString(), "")

    }
}
