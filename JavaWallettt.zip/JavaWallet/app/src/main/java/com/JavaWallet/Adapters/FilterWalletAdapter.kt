package com.JavaWallet.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import com.JavaWallet.*
import com.JavaWallet.networking.CoinListData
import kotlinx.android.synthetic.main.filterwallet_item.view.*

/**
 * Created by user on 11/4/19.
 */

class FilterWalletAdapter(private val coinlist: ArrayList<CoinListData>, private val listener:  Listner) : RecyclerView.Adapter< FilterWalletAdapter.ViewHolder>() {

    lateinit var mContext: Context

    interface Listner {
        fun onCoin_Click(walletlist: CoinListData, is_clc: Boolean)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  FilterWalletAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.filterwallet_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder:  FilterWalletAdapter.ViewHolder, position: Int) {
        holder.bindItems()
        var listdata=coinlist.get(position)
        holder.itemView.cb_text.text = coinlist.get(position).coinName

        var data= JavaWallet.mPreferenceDataModal.TRANS_WALLET

       // for (i in 0 until data.size){

           // if(coinlist.get(position).coinSymbol.equals(data[i])){

                if (Utility.getTheme(mContext).equals((mContext as BaseActivity).THEME_DARK)) {
                    holder.itemView.cb_text.isChecked=coinlist.get(position).isclicked
                    holder.itemView.cb_text.setTextColor(mContext.resources.getColor(R.color.white))
                } else if (Utility.getTheme(mContext).equals((mContext as  BaseActivity).THEME_LIGHT)) {
                    holder.itemView.cb_text.isChecked=coinlist.get(position).isclicked
                    holder.itemView.cb_text.setTextColor(mContext.resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                }else{
                    holder.itemView.cb_text.isChecked=coinlist.get(position).isclicked
                    holder.itemView.cb_text.setTextColor(mContext.resources.getColor(R.color.white))
                }

        //    }

      //  }

        holder.itemView.cb_text.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {
                if(isChecked){
                    coinlist.get(position).isclicked = true
                }else{
                    coinlist.get(position).isclicked = false
                }

                if (Utility.getTheme(mContext).equals((mContext as  BaseActivity).THEME_DARK)) {
                    if (isChecked) {
                        holder.itemView.cb_text.setTextColor(mContext.resources.getColor(R.color.blacknew))
                        listener.onCoin_Click(listdata,isChecked)
                    } else {
                        holder.itemView.cb_text.setTextColor(mContext.resources.getColor(R.color.white))
                        listener.onCoin_Click(listdata,isChecked)
                    }
                } else if (Utility.getTheme(mContext).equals((mContext as  BaseActivity).THEME_LIGHT)) {
                    if (isChecked) {
                        holder.itemView.cb_text.setTextColor(mContext.resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
                        listener.onCoin_Click(listdata,isChecked)
                    } else {
                        holder.itemView.cb_text.setTextColor(mContext.resources.getColor(R.color.transtime_light))
                        listener.onCoin_Click(listdata,isChecked)
                    }
                }else{
                    if (isChecked) {
                        holder.itemView.cb_text.setTextColor(mContext.resources.getColor(R.color.blacknew))
                        listener.onCoin_Click(listdata,isChecked)
                    } else {
                        holder.itemView.cb_text.setTextColor(mContext.resources.getColor(R.color.white))
                        listener.onCoin_Click(listdata,isChecked)
                    }
                }
            }

        })

    }

    override fun getItemCount(): Int {
        return coinlist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        init {
            mContext = itemView.context
        }

        fun bindItems() {

        }
    }
}