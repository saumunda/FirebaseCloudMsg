package com.JavaWallet.ui.activities

import android.content.DialogInterface
import android.os.Bundle
import android.support.design.widget.BottomSheetBehavior
import android.support.design.widget.BottomSheetDialog
import android.support.design.widget.CoordinatorLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.FrameLayout
import com.JavaWallet.Adapters.NotificationAdapter
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.Utility
import com.JavaWallet.networking.*
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_notification.*
import kotlinx.android.synthetic.main.header_title.*
import kotlinx.android.synthetic.main.request_dialog_backup.*
import retrofit2.HttpException

class NotificationActivity : BaseActivity(), NotificationAdapter.InviteListner {


    private lateinit var linearLayoutManager: LinearLayoutManager
    lateinit var ntfcctnlist: ArrayList<NotificationData>
    private lateinit var adptr: NotificationAdapter
    private var isthemeDark: Boolean = false
    private var acceptDecline_Status: Int = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)
        tv_title.text = getString(R.string.title_notfications)
        tv_clear.visibility = View.VISIBLE
        iv_back.setOnClickListener {
            finish()
        }

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
            isthemeDark = true
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
            isthemeDark = false
        } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
            isthemeDark = true
        }

        linearLayoutManager = LinearLayoutManager(this)
        rcycl_ntfctn.layoutManager = linearLayoutManager as RecyclerView.LayoutManager?
        if (isInternetConnected()) {
            getNotifctnData()
        }
        tv_clear.setOnClickListener {
            if (isInternetConnected()) {
                clearNotifctnData()
            }
        }
    }

    private fun clearNotifctnData() {
        showLoading()
        apiServiceWithAuthorization.clearNotifications(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })

    }

    private fun getNotifctnData() {
        showLoading()
        apiServiceWithAuthorization.getNotification(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleErrorntfctn(error); hideLoading() })

    }

    private fun checkBkrequest(from_user_id: String) {

        showLoading()
        var rqst = bkRequest(from_user_id)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.checkbkrequests(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })

    }

    private fun bkrequestacceptdeclineApi(backupRequestId: Int, stats: Int, fromId: Int) {

        showLoading()
        var rqst = bkRequestAcceptDecline(backupRequestId, stats, fromId)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.checkbkrequestacceptdecline(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })


    }

    private fun handleErrorntfctn(error: Throwable?) { //Notifications not found.
        when (error) {
            is HttpException -> {
                when {
                    error.code() == 400 -> {
                        val responseBody = error.response().errorBody()?.string()
                        var message = Gson().fromJson<BaseResponse>(responseBody, BaseResponse::class.java)
                        if (message.message.equals(getString(R.string.ntfctnsnotfound), true)) {
                            tv_nontfctn.visibility = View.VISIBLE
                            rcycl_ntfctn.visibility = View.GONE
                            tv_clear.visibility = View.GONE
                        } else {
                            showToast(message.message)
                        }
                    }
                }
            }
        }
    }


    private fun handleResponse(it: Any) {

        when (it) {

            is NotificationResponse -> {
                hideLoading()
                if (it.status) {
                    ntfcctnlist = it.data
                    adptr = NotificationAdapter(ntfcctnlist, isthemeDark, this)
                    rcycl_ntfctn.adapter = adptr
                }
            }
            is BaseResponse -> {
                hideLoading()
                if (it.status) {
                    ntfcctnlist.clear()
                    adptr.notifyDataSetChanged()
                    showDialog(getString(R.string.ntfctnscleared), true)
                }

            }
            is BackupnotificationResponse -> {
                hideLoading()
                if (it.status) {
                    showDialogRequest(it.data.backupRequestId, it.data.fromId, it.data.name)

                }

            }
            is Authacceptresponse -> {
                hideLoading()
                if (it.status) {
                    if (acceptDecline_Status == 1) {
                        showDialog(getString(R.string.BackupRequestapproved), true)
                    } else if (acceptDecline_Status == 0) {
                        showDialog(getString(R.string.Backuprequestdeclined), true)
                    }

                }

            }
        }


    }

    private fun showDialogRequest(backupRequestId: Int, fromId: Int, name: String) {

        val sheetView = layoutInflater.inflate(R.layout.request_dialog_backup, null)
        var mBottomSheetDialog = BottomSheetDialog(mActivity!!)
        mBottomSheetDialog.setContentView(sheetView)

        val params = (sheetView.getParent() as View).layoutParams as CoordinatorLayout.LayoutParams
        params.setMargins(50, 0, 50, 0)
        (sheetView.getParent() as View).setBackgroundColor(getResources().getColor(android.R.color.transparent))

        mBottomSheetDialog.setOnShowListener(DialogInterface.OnShowListener { dialog ->
            val d = dialog as BottomSheetDialog
            val bottomSheet = d.findViewById<View>(android.support.design.R.id.design_bottom_sheet) as FrameLayout?
            BottomSheetBehavior.from(bottomSheet!!).state = BottomSheetBehavior.STATE_EXPANDED
        })

        mBottomSheetDialog.tv_authusername.text = name + getString(R.string.sentyouAuthenticationRequest)
        mBottomSheetDialog.tv_declinebckup.setOnClickListener {
            mBottomSheetDialog.dismiss()
            acceptDecline_Status = 0
            bkrequestacceptdeclineApi(backupRequestId, 0, fromId)
        }

        mBottomSheetDialog.tv_authenticatebckup.setOnClickListener {
            acceptDecline_Status = 1
            mBottomSheetDialog.dismiss()
            bkrequestacceptdeclineApi(backupRequestId, 1, fromId)
        }
        mBottomSheetDialog.iv_closedialog.setOnClickListener {
            mBottomSheetDialog.dismiss()
        }
        mBottomSheetDialog.show()
    }


    override fun oninvite_Click(userlist: ArrayList<NotificationData>, position: Int) {

        if (userlist.get(position).notificationType.equals(2) || userlist.get(position).notificationType.equals(3)
                || userlist.get(position).notificationType.equals(4)) {

            var bndl = Bundle()
            bndl.putBoolean(getString(R.string.is_sent), true)
            callActivityWithData(ThreeFactor::class.java, bndl)
        }

        // 5=notify to cosigner, when get removed;
        else if (userlist.get(position).notificationType.equals(5)) {

            var bndl = Bundle()
            bndl.putBoolean(getString(R.string.is_sent), false)
            callActivityWithData(ThreeFactor::class.java, bndl)


        }
        // 6=notify to cosigners, on withdraw tx;
        else if (userlist.get(position).notificationType.equals(6)) {
            var bndl = Bundle()
            bndl.putBoolean(getString(R.string.showAuthPopup), true)
            bndl.putInt(getString(R.string.t_id), userlist.get(position).txId)
            callActivityWithData(MainActivity::class.java, bndl)
        }
        //7=notify to `from`, on cosigner accept wihdraw req;
        else if (userlist.get(position).notificationType.equals(7) || userlist.get(position).notificationType.equals(8)
                || userlist.get(position).notificationType.equals(9) || userlist.get(position).notificationType.equals(10)
                || userlist.get(position).notificationType.equals(11) || userlist.get(position).notificationType.equals(12)
                || userlist.get(position).notificationType.equals(13) || userlist.get(position).notificationType.equals(14)
                || userlist.get(position).notificationType.equals(15) || userlist.get(position).notificationType.equals(16)) {

            var bndl = Bundle()
            bndl.putInt(getString(R.string.t_id), userlist.get(position).txId)
            bndl.putString(getString(R.string.t_type), userlist.get(position).txType)
            bndl.putString("coinSymbol", userlist.get(position).coinSymbol)
            callActivityWithData(TransactionDetail::class.java, bndl)

        } else if (userlist.get(position).notificationType.equals(17)) {
            if (userlist.get(position).state.equals("signed", true)) {
                checkBkrequest(userlist.get(position).from_user_id)
            } else if (userlist.get(position).state.equals("declined", true)) {
                showDialog(getString(R.string.declinedrequest), false)
            } else if (userlist.get(position).state.equals("accepted", true)) {
                showDialog(getString(R.string.acceptedrequest), false)
            }

        }
    }


}
