package com.JavaWallet.ui.activities

 import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.view.View
 import com.JavaWallet.Adapters.AddWalletAdapter
 import com.JavaWallet.BaseActivity
 import com.JavaWallet.JavaWallet
 import com.JavaWallet.R
 import com.JavaWallet.Utilities.CryptLib
 import com.JavaWallet.Utility
import com.JavaWallet.networking.*
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_add_new_wallet.*
import kotlinx.android.synthetic.main.header_title.*

class AddNewWallet : BaseActivity(), AddWalletAdapter.Listener, View.OnClickListener {

    lateinit var coinlist: ArrayList<CoinListData>
    private var user_coin_id: Int = 0
    private var list_pos: Int = 0
    private var user_coin_symbol: String = ""
    var delay: Long = 800 // 1 seconds after user stops typing
    var last_text_edit: Long = 0
    var handler_ = Handler()
    private var isthemeDark: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_new_wallet)
        tv_title.text = getString(R.string.addwallet)
        iv_search.visibility = View.VISIBLE

        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
        rcycl_addwallet.layoutManager = layoutManager

        iv_search.setOnClickListener(this)
        iv_back.setOnClickListener(this)
        btn_add_custom_token.setOnClickListener(this)
        edt_search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {

                if (p0!!.isNotEmpty()) {
                    last_text_edit = System.currentTimeMillis();
                    handler_.postDelayed(input_finish_checker, delay);
                } else {
                    hitApi()
                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                handler_.removeCallbacks(input_finish_checker)
            }

        })
    }

    private val input_finish_checker = Runnable {
        if (System.currentTimeMillis() > last_text_edit + delay - 500) {
            hitApi()
        }
    }

    override fun onResume() {
        super.onResume()

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            isthemeDark = true
            iv_back.setColorFilter(resources.getColor(R.color.white));
            edt_search.setHintTextColor(resources.getColor(R.color.white))
            edt_search.setTextColor(resources.getColor(R.color.white))
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            isthemeDark = false
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
            edt_search.setHintTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
            edt_search.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
        } else {
            isthemeDark = true
        }
        hitApi()

    }

    private fun hitApi() {
        if (isInternetConnected()) {
            getCoinList(edt_search.text.toString().trim())
        } else {
            showDialog(getString(R.string.network_error), false)
        }
    }

    override fun onClick(p0: View?) {

        when (p0) {
            iv_back -> {

                finish()

            }
            iv_search -> {
                if (edt_search.visibility == View.VISIBLE) {
                    edt_search.visibility = View.GONE
                    hidekeyboard(edt_search)
                } else {
                    edt_search.visibility = View.VISIBLE

                }
            }
            btn_add_custom_token->{
                startNewActivity(AddCustomTokenActivity())

            }

        }
    }

    private fun getCoinList(word: String) {
        showLoading()
        var rqst = SearchRequest(word)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.getCoinList(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })
    }

    private fun disableCoinApi() {
        showLoading()

        var rqst = DisableCoinRequest(0, user_coin_id)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.disablecoin(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }

    private fun createAddressApi() {
        showLoading()
        var rqst: createAddressRequest
        if (user_coin_symbol.equals(getString(R.string.btc))) {
            rqst = createAddressRequest(JavaWallet.mPreferenceDataModal.BTC_ADDRESS,
                    user_coin_symbol, JavaWallet.mPreferenceDataModal.DEVICEToken, 1, 1)
        } else {
            rqst = createAddressRequest(JavaWallet.mPreferenceDataModal.COIN_ADDRESS,
                    user_coin_symbol, JavaWallet.mPreferenceDataModal.DEVICEToken, 1, 1)
        }

        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.createAddress(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })
    }


    private var isupdateStatus: Boolean = false

    override fun onItemClick(coinListData: CoinListData, isCreateAdress: Boolean, pos: Int) {
        user_coin_id = coinListData.userCoinId
        list_pos = pos
        user_coin_symbol = coinListData.coinSymbol
        isupdateStatus = isCreateAdress
        if (isCreateAdress) {
            createAddressApi()
        } else {
            disableCoinApi()
        }
    }

    private lateinit var adapter: AddWalletAdapter

    private fun handleResponse(it: Any?) {
        hideLoading()
        when (it) {
            is CoinListResponse -> {
                if (it.status) {
                    coinlist = it.data
                    if (coinlist.size > 0) {
                        tvno_wallet.visibility = View.GONE
                        rcycl_addwallet.visibility = View.VISIBLE
                        adapter = AddWalletAdapter(coinlist, this)
                        rcycl_addwallet.adapter = adapter
                    } else {
                        tvno_wallet.visibility = View.VISIBLE
                        rcycl_addwallet.visibility = View.GONE
                    }

                }
            }
            is BaseResponse -> {
                if (it.status) {
                    if (isupdateStatus) {
                        coinlist.get(list_pos).status = 1
                    } else {
                        coinlist.get(list_pos).status = 0
                    }
                    adapter.notifyItemChanged(list_pos)
                }
            }
        }


    }


}
