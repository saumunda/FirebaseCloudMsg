package com.JavaWallet.ui.activities

import android.os.Bundle
import android.os.Handler
import android.view.WindowManager
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utility
import com.scottyab.rootbeer.RootBeer

class Splash : BaseActivity() {
    private val SPLASH_DELAY: Long = 2000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash)
        JavaWallet.mPreferenceDataModal.ISGENERATEMNEMONICSAT_SIGNIN = true
        JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
        var rootBeer = RootBeer(this)
       /* if (rootBeer.isRootedWithoutBusyBoxCheck) {
            showDialog(getString(R.string.rooted), false)
        } else {
            if (JavaWallet.mPreferenceDataModal.ISDEFAULTLIGHTTHEME) {
                Utility.setTheme(mActivity, "light")
                JavaWallet.mPreferenceDataModal.ISDEFAULTLIGHTTHEME = false
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
            }

            callHandler()
        }*/

        if (JavaWallet.mPreferenceDataModal.ISDEFAULTLIGHTTHEME) {
            Utility.setTheme(mActivity, "light")
            JavaWallet.mPreferenceDataModal.ISDEFAULTLIGHTTHEME = false
            JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
        }

        callHandler()

    }

    private fun callHandler() {
        Handler().postDelayed({
            if (JavaWallet.mPreferenceDataModal.ISSIGNIN) {
                var bndl = Bundle()
                bndl.putBoolean(getString(R.string.isfromSend), false)
                bndl.putBoolean(getString(R.string.isfromsetting), false)
                bndl.putBoolean(getString(R.string.isfromTransaction), false)
                bndl.putBoolean(getString(R.string.isfromImport), false)
                callActivityWithData(NewPinAfterImport::class.java, bndl)
                finish()
            } else {
                startNewActivity(SigninActivity())
                finish()
            }
        }, SPLASH_DELAY)
    }
}
