package com.JavaWallet.models

/**
 * Created by user on 10/5/19.
 */

class Mnemonics_model {

    var coin_address = ""
    var coin_mnemonic = ""

}


