package com.JavaWallet.ui.activities

import android.content.DialogInterface
import android.os.Bundle
import android.support.design.widget.BottomSheetBehavior
import android.support.design.widget.BottomSheetDialog
import android.support.design.widget.CoordinatorLayout
import android.view.View
import android.widget.FrameLayout
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.networking.*
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.request_dialog_backup.*

class BackupCosignerNotificationActivity : BaseActivity() {

    var from_user_id = 0
    private var acceptDecline_Status: Int = 5
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.bck)

        //  rltv.setOnClickListener { finish() }
        try {
            var b: Bundle? = Bundle()
            b = intent.extras
            from_user_id = b!!.getInt(getString(R.string.fromuserid))
            checkBkrequest(from_user_id.toString())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun checkBkrequest(from_user_id: String) {

        showLoading()
        var rqst = bkRequest(from_user_id)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.checkbkrequests(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })

    }

    private fun bkrequestacceptdeclineApi(backupRequestId: Int, stats: Int, fromId: Int) {

        showLoading()
        var rqst = bkRequestAcceptDecline(backupRequestId, stats, fromId)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.checkbkrequestacceptdecline(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })


    }

    private fun showDialogRequest(backupRequestId: Int, fromId: Int, name: String) {

        val sheetView = layoutInflater.inflate(com.JavaWallet.R.layout.request_dialog_backup, null)
        var mBottomSheetDialog = BottomSheetDialog(mActivity!!)
        mBottomSheetDialog.setContentView(sheetView)

        val params = (sheetView.getParent() as View).layoutParams as CoordinatorLayout.LayoutParams
        params.setMargins(50, 0, 50, 0)
        (sheetView.getParent() as View).setBackgroundColor(getResources().getColor(android.R.color.transparent))

        mBottomSheetDialog.setOnShowListener(DialogInterface.OnShowListener { dialog ->
            val d = dialog as BottomSheetDialog
            val bottomSheet = d.findViewById<View>(android.support.design.R.id.design_bottom_sheet) as FrameLayout?
            BottomSheetBehavior.from(bottomSheet!!).state = BottomSheetBehavior.STATE_EXPANDED
        })
        mBottomSheetDialog.setOnDismissListener {
            dialog ->
            if(acceptDecline_Status==0 || acceptDecline_Status==1){

            }else{
                finish()
            }

        }
        mBottomSheetDialog.tv_authusername.text = name + getString(R.string.sentyouAuthenticationRequest)
        mBottomSheetDialog.tv_declinebckup.setOnClickListener {

            acceptDecline_Status = 0
            mBottomSheetDialog.dismiss()
            bkrequestacceptdeclineApi(backupRequestId, 0, fromId)

        }

        mBottomSheetDialog.tv_authenticatebckup.setOnClickListener {
            acceptDecline_Status = 1
            mBottomSheetDialog.dismiss()
            bkrequestacceptdeclineApi(backupRequestId, 1, fromId)
        }
        mBottomSheetDialog.iv_closedialog.setOnClickListener {
            mBottomSheetDialog.dismiss()
        }
        mBottomSheetDialog.show()


    }

    private fun handleResponse(it: Any) {

        when (it) {


            is BackupnotificationResponse -> {
                hideLoading()
                if (it.status) {
                    showDialogRequest(it.data.backupRequestId, it.data.fromId, it.data.name)

                }

            }
            is Authacceptresponse -> {
                hideLoading()
                if (it.status) {
                    if (acceptDecline_Status == 1) {
                        showDialog(getString(R.string.BackupRequestapproved), true)
                    } else if (acceptDecline_Status == 0) {
                        showDialog(getString(R.string.Backuprequestdeclined), true)
                    }

                }

            }
        }


    }


}
