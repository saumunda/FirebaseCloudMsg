package com.JavaWallet.networking

import android.content.Context
import com.JavaWallet.JavaWallet
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Converter
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.lang.reflect.Type
import java.util.concurrent.TimeUnit

/**
 * Created by user on 10/5/19.
 */
object Apiclient {
    private lateinit var logging: HttpLoggingInterceptor


    fun apiInterfaceWithAuthorization(context:Context): ApiInterface {

        logging = HttpLoggingInterceptor()
        logging.level = HttpLoggingInterceptor.Level.BODY
       val httpClient = OkHttpClient.Builder()
                .addInterceptor { chain ->
                    val ongoing = chain.request().newBuilder()
                    ongoing.addHeader("Content-Type", "application/json")
                    ongoing.addHeader("Accept", "application/json")
                    ongoing.addHeader("Cache-Control", "no-cache")

                    chain.proceed(ongoing.build())
                }
                 .addInterceptor (logging)
                .connectTimeout(1, TimeUnit.MINUTES)
                .readTimeout(1, TimeUnit.MINUTES)
                .build()

        val retrofit = Retrofit.Builder()
                .addConverterFactory(nullOnEmptyConverterFactory)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .baseUrl(JavaWallet.BASE_URL)
                .client(httpClient).build()
        return retrofit.create(ApiInterface::class.java)
    }


    fun apiInterfaceWithAuthorization_LINKS(context:Context): ApiInterface {

        logging = HttpLoggingInterceptor()
        logging.level = HttpLoggingInterceptor.Level.BODY
        val httpClient = OkHttpClient.Builder()
                .addInterceptor { chain ->
                    val ongoing = chain.request().newBuilder()
                    ongoing.addHeader("Content-Type", "application/json")
                    ongoing.addHeader("Accept", "application/json")
                    ongoing.addHeader("Cache-Control", "no-cache")

                    chain.proceed(ongoing.build())
                }
                 .addInterceptor (logging)
                .connectTimeout(1, TimeUnit.MINUTES)
                .readTimeout(1, TimeUnit.MINUTES)
                .build()

        val retrofit = Retrofit.Builder()
                .addConverterFactory(nullOnEmptyConverterFactory)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .baseUrl(JavaWallet.BASE_URL_LINKS)
                .client(httpClient).build()
        return retrofit.create(ApiInterface::class.java)
    }

    fun apiInterfaceWithAuthorization_Token(context:Context): ApiInterface {

        logging = HttpLoggingInterceptor()
        logging.level = HttpLoggingInterceptor.Level.BODY
        val httpClient = OkHttpClient.Builder()
                .addInterceptor { chain ->
                    val ongoing = chain.request().newBuilder()
                    ongoing.addHeader("Content-Type", "application/json")
                    ongoing.addHeader("Cache-Control", "no-cache")
                    chain.proceed(ongoing.build())
                }
                .addInterceptor (logging)
                .connectTimeout(1, TimeUnit.MINUTES)
                .readTimeout(1, TimeUnit.MINUTES)
                .build()

        val retrofit = Retrofit.Builder()
                .addConverterFactory(nullOnEmptyConverterFactory)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .baseUrl(JavaWallet.BASE_URL)
                .client(httpClient).build()
        return retrofit.create(ApiInterface::class.java)
    }
    // if in case response is null Or Empty
    private val nullOnEmptyConverterFactory = object : Converter.Factory() {
        fun converterFactory() = this
        override fun responseBodyConverter(type: Type, annotations: Array<out Annotation>, retrofit: Retrofit) = object : Converter<ResponseBody, Any?> {
            val nextResponseBodyConverter = retrofit.nextResponseBodyConverter<Any?>(converterFactory(), type, annotations)
            override fun convert(value: ResponseBody) = if (value.contentLength() != 0L) nextResponseBodyConverter.convert(value) else null
        }
    }


}