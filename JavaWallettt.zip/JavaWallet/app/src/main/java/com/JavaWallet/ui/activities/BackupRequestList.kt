package com.JavaWallet.ui.activities

import Adapters.CosignerListAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.support.v4.content.LocalBroadcastManager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import com.JavaWallet.*
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.networking.*
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_backup_request_list.*
import kotlinx.android.synthetic.main.header_title.*

class BackupRequestList :BaseActivity(), CosignerListAdapter.RqstListner {

    private var isShowContinue = false
    private lateinit var adapter: CosignerListAdapter
    lateinit var coinlist: ArrayList<BackupcosignerlistData>

    private lateinit var localBroadcastManager: LocalBroadcastManager
    private lateinit var getB_Receiver: LIstUpdateBroadcast
    private lateinit var balanceFilter: IntentFilter

    inner class LIstUpdateBroadcast : BroadcastReceiver() {

        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ConstantsUtils.updatetBackUpRequestList) {
                if ( isInternetConnected()) {
                    getBackupCosignerList()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_backup_request_list)

        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
        reqst_list.layoutManager = layoutManager
        getBackupCosignerList()

        iv_back.setOnClickListener {
            finish()
        }
        tv_continue.setOnClickListener {
            startNewActivity(BackupWallet())
        }

        localBroadcastManager = LocalBroadcastManager.getInstance(mActivity)
        getB_Receiver = LIstUpdateBroadcast()
        balanceFilter = IntentFilter(ConstantsUtils.updatetBackUpRequestList)

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
        } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        }
    }

    override fun onResume() {
        super.onResume()
        localBroadcastManager.registerReceiver(getB_Receiver, balanceFilter)

    }

    override fun onPause() {
        super.onPause()
        localBroadcastManager.unregisterReceiver(getB_Receiver)

    }
    private fun getBackupCosignerList() {

        showLoading()
        apiServiceWithAuthorization.getBackupCosignerList(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }

    private fun requestgainApi(backupRequestId: Int, cosignerUserId: Int) {
        showLoading()
        var rqst = CsgnrRequest()
        rqst.backup_request_id = backupRequestId
        rqst.cosigner_user_id = cosignerUserId
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.BackupCosignerRequestAgain(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }

    private fun handleResponse(it: Any) {
        hideLoading()

        when (it) {

            is BackupcosignerlistResponse -> {
                if (it.status) {
                    coinlist = it.data

                    for (i in 0 until coinlist.size) {

                        if (coinlist[i].signStatus == 1) {
                            isShowContinue = true
                        } else {
                            isShowContinue = false
                        }
                    }

                    if(isShowContinue){
                        tv_continue.visibility=View.VISIBLE
                    }else{
                        tv_continue.visibility=View.GONE
                    }

                    reqst_list.visibility = View.VISIBLE
                    adapter = CosignerListAdapter(coinlist, this)
                    reqst_list.adapter = adapter

                }
            }
            is BaseResponse -> {
                if (it.status) {
                    showDialog(it.message, false)
                }
            }
        }


    }

    override fun onrqst_Click(position: Int) {

        requestgainApi(coinlist.get(position).backupRequestId, coinlist.get(position).cosignerUserId)


    }


}
