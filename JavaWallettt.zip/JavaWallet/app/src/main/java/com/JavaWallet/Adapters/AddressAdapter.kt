package com.JavaWallet.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.R
import com.JavaWallet.networking.AddressData
import kotlinx.android.synthetic.main.address_item.view.*
import kotlinx.android.synthetic.main.address_item.view.rltv
import kotlinx.android.synthetic.main.address_item.view.tv_name

/**
 * Created by user on 11/4/19.
 */

class AddressAdapter(private val addresslist: ArrayList<AddressData>, private val lstnr:  AddresListner) : RecyclerView.Adapter< AddressAdapter.ViewHolder>() {

    private lateinit var mContext: Context

    interface AddresListner {
        fun onAddress_Click(addresslist: AddressData)
        fun ondelete_Click(addresslist: AddressData, position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.address_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder:  AddressAdapter.ViewHolder, position: Int) {
        val listdata = addresslist.get(position)
        holder.itemView.tv_name.text = listdata.payeeName
        holder.itemView.tv_address.text = listdata.payeeAddress
        holder.itemView.rltv.setOnClickListener {
            lstnr.onAddress_Click(listdata)
        }
        holder.itemView.iv_crossaddress.setOnClickListener {
            lstnr.ondelete_Click(listdata,position)
        }

    }

    override fun getItemCount(): Int {
        return addresslist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context
        }

        fun bindItems() {

        }
    }
}