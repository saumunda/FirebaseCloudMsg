package com.JavaWallet

import android.content.Context
import android.support.v4.app.Fragment

open class BaseFragment : Fragment() {
    lateinit var mActivity: BaseActivity

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is BaseActivity) {
            this.mActivity = context
        }
    }

    override fun onResume() {
        super.onResume()
        mActivity.getCoinList()
    }

}



