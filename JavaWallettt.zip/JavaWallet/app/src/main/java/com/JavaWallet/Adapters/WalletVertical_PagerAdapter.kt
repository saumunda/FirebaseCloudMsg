package com.JavaWallet.Adapters

import android.content.Context
import android.support.v4.view.PagerAdapter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.BaseActivity
import com.JavaWallet.R
import com.JavaWallet.ui.activities.Receive
import com.JavaWallet.ui.activities.Send
import kotlinx.android.synthetic.main.walletcoin_pager.view.*

class WalletVertical_PagerAdapter(mContext: Context) : PagerAdapter() {
    private var layoutInflater: LayoutInflater? = null

    init {
        Companion.mContext = mContext
    }

    companion object {
        lateinit var mContext: Context
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        layoutInflater =mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = layoutInflater!!.inflate(R.layout.walletcoin_pager, container, false)


        view.lnr_send.setOnClickListener {

            (WalletVertical_PagerAdapter.Companion.mContext as BaseActivity).startNewActivity(Send())
        }

        view.lnr_receive.setOnClickListener {
            (WalletVertical_PagerAdapter.Companion.mContext as BaseActivity).startNewActivity(Receive())
        }

        container.addView(view)
        return view
    }


    override fun isViewFromObject(view: View, `object`: Any): Boolean {

        return view === `object`
    }

    override fun getCount(): Int {

        return 2
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {

        val view = `object` as View
        container.removeView(view)
    }
}