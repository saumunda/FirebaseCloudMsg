package com.JavaWallet.ui.fragments
//https://www.simplifiedcoding.net/android-tablayout-example-using-viewpager-fragments/
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.view.ViewGroup
import android.util.SparseArray
import android.view.View

public class Pager(fm: FragmentManager, internal var tabCount: Int) : FragmentStatePagerAdapter(fm) {
    private val registeredFragments = SparseArray<Fragment>()
    //Overriding method getItem
    override fun getItem(position: Int): Fragment? {
        //Returning the current tabs
        when (position) {
            0 -> {
                return Wallet_frag()
            }
            1 -> {
                return Transaction_frag()
            }
            2 -> {
                return Setting_frag()
            }
            else -> return null
        }
    }

    //Overriden method getCount to get the number of tabs
    override fun getCount(): Int {
        return tabCount
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val fragment = super.instantiateItem(container, position) as Fragment
        registeredFragments.put(position, fragment)
        return fragment
    }

    override fun destroyItem(container: View, position: Int, `object`: Any) {
        registeredFragments.remove(position)
        super.destroyItem(container!!, position, `object`)
    }

    fun getRegisteredFragment(position: Int): Fragment {
        return registeredFragments.get(position)
    }
}

