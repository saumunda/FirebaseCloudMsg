package com.JavaWallet.models

import java.io.Serializable
import java.math.BigInteger

/**
 * Created by user on 10/5/19.
 */
class PreferenceDataModal : Serializable {
    var JWTToken = ""
    var DEVICEToken = ""
    var DefaultCurrency = "USD"
    var ISGENERATEMNEMONICSAT_SIGNIN: Boolean = true
    var ISSIGNIN: Boolean = false
    var ISSHOW_VIEW: Boolean = true
    var ISDEFAULTLIGHTTHEME: Boolean = true
    var COIN_MNEMONICS = "";
    var COIN_ADDRESS = "";
    var WALLET_PIN = ""
    var CRYPTODATA = ""
    var COINGEEKODATA = ""
    var PRIVATE_KEY: BigInteger? = null

    var ETHPRIVATE_KEY: BigInteger? = null
    var FROM_DATE = ""
    var TO_DATE = ""
    var BTC_ADDRESS = ""
    var PRIVATE_KEYBTC = ""
    var BTC_BALANCE = 0.0
    var ETH_BALANCE = 0.0
  //  var BTC_FEES = 0.00000226
    var BTC_FEES = 0.000374
    var TRANS_WALLET = ArrayList<String>()
    var TRANS_TYPE = ArrayList<String>()
    var TRANS_STATUS = ArrayList<String>()
    var GASPRICE = 0.0
    var GASLIMIT = 0.0
    var IS_SYNCED: Boolean = false

    var NEW_VERSON=false
    var uplvalue = 0.0
    var uplpercenr = 0.0

}