package com.JavaWallet.ui.fragments;

import android.app.DialogFragment;
import android.content.Context;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.JavaWallet.R;
import com.JavaWallet.ui.activities.MainActivity;
import com.JavaWallet.ui.activities.Send;


import java.io.IOException;

public class NFCReadFragment extends DialogFragment {

    static String from = "";
    public static final String TAG = NFCReadFragment.class.getSimpleName();

    public static NFCReadFragment newInstance(String s) {
        from=s;
        return new NFCReadFragment();
    }

    private Button dialog_readyscan_cancel;
    private Listener mListener;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Window window = getDialog().getWindow();
        // set "origin" to top left corner, so to speak
        window.setGravity(Gravity.BOTTOM);
         window.setDimAmount(0.70f);
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        View view = inflater.inflate(R.layout.nfcscan, container, false);
        initViews(view);
        return view;
    }

    private void initViews(View view) {

        dialog_readyscan_cancel = (Button) view.findViewById(R.id.dialog_readyscan_cancel);
        dialog_readyscan_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NFCReadFragment.this.dismiss();
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(from.equals("Send")){
            mListener = (Send) context;
        }else {
            mListener = (MainActivity) context;
        }

        mListener.onDialogDisplayed();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener.onDialogDismissed();
    }

    public void onNfcDetected(Ndef ndef) {

        readFromNFC(ndef);
    }

    private void readFromNFC(Ndef ndef) {

        try {
            ndef.connect();
            NdefMessage ndefMessage = ndef.getNdefMessage();
            String message = new String(ndefMessage.getRecords()[0].getPayload());
            // mTvMessage.setText(message);
            ndef.close();

        } catch (IOException | FormatException e) {
            e.printStackTrace();

        }
    }

    @Override
    public int getTheme() {
        return R.style.DialogAnimationslidenew;
    }
}