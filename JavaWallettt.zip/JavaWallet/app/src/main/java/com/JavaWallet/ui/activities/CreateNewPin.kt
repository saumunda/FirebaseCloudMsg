package com.JavaWallet.ui.activities

import android.os.Bundle
import android.view.View
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utility
import kotlinx.android.synthetic.main.activity_create_new_pin.*
import kotlinx.android.synthetic.main.header_title.*

class CreateNewPin : BaseActivity(), View.OnClickListener {

    var createpin_text: String = ""
    var createpin_count: Int = 0
    private var isthemeDark: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_new_pin)
        tv_title.text = getString(R.string.titlechangepin)
        iv_back.setOnClickListener {
            finish()
        }
        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
            tv_title.setTextColor(resources.getColor(R.color.white))
            isthemeDark = true
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
            tv_title.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
            isthemeDark = false
        }else{
            iv_back.setColorFilter(resources.getColor(R.color.white));
            tv_title.setTextColor(resources.getColor(R.color.white))
            isthemeDark = true
        }
    }

    override fun onResume() {
        super.onResume()
        onclick()
    }

    private fun onclick() {
        tvnumber_zero.setOnClickListener(this)
        tvnumber_one.setOnClickListener(this)
        tvnumber_two.setOnClickListener(this)
        tvnumber_three.setOnClickListener(this)
        tvnumber_four.setOnClickListener(this)
        tvnumber_five.setOnClickListener(this)
        tvnumber_six.setOnClickListener(this)
        tvnumber_seven.setOnClickListener(this)
        tvnumber_eight.setOnClickListener(this)
        tvnumber_nine.setOnClickListener(this)
        ivclear_number.setOnClickListener(this)
        tv_update.setOnClickListener(this)

    }

    override fun onClick(p0: View?) {
        when (p0) {

            tvnumber_one -> {

                if (createpin_text.length < 4) {
                    createpin_text = createpin_text + "1"
                    changebackcreate()
                }
            }

            tvnumber_two -> {
                if (createpin_text.length < 4) {
                    createpin_text = createpin_text + "2"
                    changebackcreate()
                }
            }
            tvnumber_three -> {
                if (createpin_text.length < 4) {
                    createpin_text = createpin_text + "3"
                    changebackcreate()
                }
            }
            tvnumber_four -> {
                if (createpin_text.length < 4) {
                    createpin_text = createpin_text + "4"
                    changebackcreate()
                }
            }
            tvnumber_five -> {
                if (createpin_text.length < 4) {
                    createpin_text = createpin_text + "5"
                    changebackcreate()
                }
            }
            tvnumber_six -> {
                if (createpin_text.length < 4) {
                    createpin_text = createpin_text + "6"
                    changebackcreate()
                }
            }
            tvnumber_seven -> {
                if (createpin_text.length < 4) {
                    createpin_text = createpin_text + "7"
                    changebackcreate()
                }

            }
            tvnumber_eight -> {
                if (createpin_text.length < 4) {
                    createpin_text = createpin_text + "8"
                    changebackcreate()
                }
            }
            tvnumber_nine -> {
                if (createpin_text.length < 4) {
                    createpin_text = createpin_text + "9"
                    changebackcreate()
                }

            }
            tvnumber_zero -> {
                if (createpin_text.length < 4) {
                    createpin_text = createpin_text + "0"
                    changebackcreate()
                }
            }
            ivclear_number -> {
                if(isthemeDark){
                    if (createpin_count == 1) {
                        createpin_count--
                        imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                        createpin_text = removeLastChar(createpin_text)
                    } else if (createpin_count == 2) {
                        createpin_count--
                        imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                        createpin_text = removeLastChar(createpin_text)
                    } else if (createpin_count == 3) {
                        createpin_count--
                        imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                        createpin_text = removeLastChar(createpin_text)
                    } else if (createpin_count == 4) {
                        createpin_count--
                        imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                        createpin_text = removeLastChar(createpin_text)
                    }
                }else{
                    if (createpin_count == 1) {
                        createpin_count--
                        imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        createpin_text = removeLastChar(createpin_text)
                    } else if (createpin_count == 2) {
                        createpin_count--
                        imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        createpin_text = removeLastChar(createpin_text)
                    } else if (createpin_count == 3) {
                        createpin_count--
                        imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        createpin_text = removeLastChar(createpin_text)
                    } else if (createpin_count == 4) {
                        createpin_count--
                        imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        createpin_text = removeLastChar(createpin_text)
                    }
                }


            }

            tv_update -> {
                if (createpin_text.length < 4) {
                    showDialog(getString(R.string.Pleaseenterdigitnewpin),false)
                } else {
                    JavaWallet.mPreferenceDataModal.WALLET_PIN = createpin_text
                    JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                    showDialog(getString(R.string.pinchanged),true)
                }
            }


        }

    }

    private fun changebackcreate() {
        createpin_count++
        if(isthemeDark){
            if (createpin_text.length == 1) {
                imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_full))
            } else if (createpin_text.length == 2) {
                imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_full))
            } else if (createpin_text.length == 3) {
                imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_full))
            } else if (createpin_text.length == 4) {
                imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_full))
            }
        }else{
            if (createpin_text.length == 1) {
                imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 2) {
                imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 3) {
                imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 4) {
                imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            }
        }

    }

    private fun removeLastChar(str: String): String {
        return str.substring(0, str.length - 1)
    }
}
