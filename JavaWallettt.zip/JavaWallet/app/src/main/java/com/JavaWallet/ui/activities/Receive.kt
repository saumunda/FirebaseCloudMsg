package com.JavaWallet.ui.activities

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import android.view.animation.AnimationUtils
import com.JavaWallet.*
import com.JavaWallet.Adapters.SendlistAdapter
import com.JavaWallet.networking.ManageWalletData
import com.JavaWallet.networking.ManageWalletResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_receive.*
import kotlinx.android.synthetic.main.header_title.*
import org.json.JSONArray

class Receive : BaseActivity(), View.OnClickListener, SendlistAdapter.Listner {



    private lateinit var linearLayoutManager: LinearLayoutManager
    lateinit var walletlist: ArrayList<ManageWalletData>


    private lateinit var coin_sym: String
    private lateinit var wallet_address: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receive)

        try {
            var b: Bundle? = Bundle()
            b = intent.extras
            tv_coinnamee.text = b!!.getString(getString(R.string.coin_name))
            tv_crypto.text = b!!.getString(getString(R.string.coinamount_crypto))
            tv_fiat.text = b!!.getString(getString(R.string.coinamount_fiat))
            coin_sym = b!!.getString(getString(R.string.coin_sym)).toLowerCase()
            wallet_address = b!!.getString("wallet_address")

            loadPicture_circle(iv_currency, JavaWallet.IMAGEBASE_URL + b!!.getString(getString(R.string.coin_icon)))

            if(coin_sym.equals(getString(R.string.btc),true)){
                loadPicture_circle(iv_qr, getString(R.string.qrfirtslink) + JavaWallet.mPreferenceDataModal.BTC_ADDRESS + "&choe=UTF-8")
                tv_addrs.text = JavaWallet.mPreferenceDataModal.BTC_ADDRESS
            } else if(coin_sym.equals("upl",true)){
                loadPicture_circle(iv_qr, getString(R.string.qrfirtslink) + wallet_address + "&choe=UTF-8")
                tv_addrs.text = wallet_address
            }
            else{
                loadPicture_circle(iv_qr, getString(R.string.qrfirtslink) + JavaWallet.mPreferenceDataModal.COIN_ADDRESS + "&choe=UTF-8")
                tv_addrs.text = JavaWallet.mPreferenceDataModal.COIN_ADDRESS
            }

            linearLayoutManager = LinearLayoutManager(this)
            rccyl_choose_receive.layoutManager = linearLayoutManager

        } catch (e: Exception) {

        }
    }

    override fun onResume() {
        super.onResume()
        tv_title.text = getString(R.string.titltrcv)
        if (Utility.getTheme(mActivity).equals( THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
        }else{
            iv_back.setColorFilter(resources.getColor(R.color.white));
        }
        iv_back.setOnClickListener {
            finish()
        }

        if (isInternetConnected()) {
            getWalletList()
        } else {
            showDialog(getString(R.string.network_error),false)
        }
        iv_currencydropdown.setOnClickListener(this)
        tv_addrs.setOnClickListener(this)
        tv_share.setOnClickListener(this)
    }

    private fun getWalletList() {

        apiServiceWithAuthorization.managewallet(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); })
    }

    private lateinit var adpter: SendlistAdapter

    private fun handleResponse(it: Any?) {
        when (it) {

            is ManageWalletResponse -> {
                if (it.status) {
                    walletlist = it.data
                    adpter = SendlistAdapter(walletlist, this)
                    rccyl_choose_receive.adapter = adpter
                }
            }
        }
    }


    override fun onCoin_Click(walletlist: ManageWalletData) {

        tv_coinnamee.text = walletlist.coinName
        tv_crypto.text = decimalConverterUpto(walletlist.balance, 8) + " " + walletlist.coinSymbol.toUpperCase()
        loadPicture_circle(iv_currency, JavaWallet.IMAGEBASE_URL + walletlist.coinImage)
        coin_sym = walletlist.coinSymbol

        try {
            val jsonarray = JSONArray(JavaWallet.mPreferenceDataModal.CRYPTODATA)
            for (i in 0 until jsonarray.length()) {
                var jsnobj = jsonarray.getJSONObject(i)
                if (walletlist.coinSymbol.equals(jsnobj.getString("symbol"))) {
                    tv_fiat.text = decimalConverterUpto(((walletlist.balance) * (jsnobj.getString("current_price").toDouble())), 2) +
                            " " + walletlist.currencyCode
                } else {
                    //  tv_fiat.text = "0.00 " + walletlist.currencyCode
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            tv_fiat.text = "0.00 " + walletlist.currencyCode
        }


        rccyl_choose_receive.visibility = View.GONE
        lnr_data.visibility = View.VISIBLE

        if(coin_sym.equals(getString(R.string.btc),true)){
            loadPicture_circle(iv_qr, getString(R.string.qrfirtslink) + JavaWallet.mPreferenceDataModal.BTC_ADDRESS + "&choe=UTF-8")
            tv_addrs.text = JavaWallet.mPreferenceDataModal.BTC_ADDRESS
        }else{
            loadPicture_circle(iv_qr, getString(R.string.qrfirtslink) + JavaWallet.mPreferenceDataModal.COIN_ADDRESS + "&choe=UTF-8")
            tv_addrs.text = JavaWallet.mPreferenceDataModal.COIN_ADDRESS
        }
    }

    override fun onClick(p0: View?) {


        when (p0) {
            iv_currencydropdown -> {

                if (rccyl_choose_receive.visibility == View.VISIBLE) {
                    rccyl_choose_receive.visibility = View.GONE
                    //rccyl_choose.animate().alpha(0.0f);
                    lnr_data.visibility = View.VISIBLE
                } else {
                    val animFadeIn = AnimationUtils.loadAnimation(applicationContext, R.anim.fade_in)
                    rccyl_choose_receive.startAnimation(animFadeIn)
                    rccyl_choose_receive.visibility = View.VISIBLE
                    lnr_data.visibility = View.GONE
                }


            }
            tv_addrs -> {

                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText(getString(R.string.label), tv_addrs.text.toString())
                clipboard.primaryClip = clip
                showToast(getString(R.string.addresscopied))

            }
            tv_share -> {
                try {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "text/plain"
                    i.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name))
                    var sAux = "Address: "+ tv_addrs.text.toString()
                    i.putExtra(Intent.EXTRA_TEXT, sAux)
                    startActivity(Intent.createChooser(i, getString(R.string.chooseone)))
                } catch (e: Exception) {
                    //e.toString();
                }
            }


        }
    }

}
