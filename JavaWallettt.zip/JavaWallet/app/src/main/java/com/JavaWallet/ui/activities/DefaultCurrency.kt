package com.JavaWallet.ui.activities

import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import com.JavaWallet.Adapters.CurrencyAdapter
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.Utility
import com.JavaWallet.networking.*
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_default_currency.*
import kotlinx.android.synthetic.main.header_title.*

class DefaultCurrency : BaseActivity(), CurrencyAdapter.Listener {
    lateinit var currencylist: ArrayList<CurrencyListData>
    var currencyid = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_default_currency)
        tv_title.text = getString(R.string.titlechoosedefault)


        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
        rcycl_currency.layoutManager = layoutManager

        iv_back.setOnClickListener {
            finish()
        }
        if (isInternetConnected()) {
            getCurrencyList()
        } else {
            showDialog(getString(R.string.network_error),false)
        }

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
        }else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        }

    }

    private fun getCurrencyList() {
        showLoading()
        apiServiceWithAuthorization.getCurrencyList(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }

    private fun handleResponse(it: Any) {
        hideLoading()
        when (it) {

            is CurrencyListResponse -> {
                if (it.status) {
                    currencylist = it.data
                    rcycl_currency.adapter = CurrencyAdapter(currencylist, this)
                }
            }
            is BaseResponse -> {
                if (it.status) {

                }
            }
        }
    }

    override fun onItemClick(currencyListData: CurrencyListData) {
        currencyid = currencyListData.currencyId
        JavaWallet.mPreferenceDataModal.DefaultCurrency = currencyListData.currencyCode
        JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)

    }

    override fun onPause() {
        super.onPause()
        if (currencyid != 0) {
            saveDefaultCurrencyApi()
        }
    }

    private fun saveDefaultCurrencyApi() {
        var rqst = DefaultCurrencyRequest()
        rqst.currency_fiat_id = currencyid

        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.saveUserCurrencyList(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }

}
