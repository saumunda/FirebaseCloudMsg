package com.JavaWallet.ui.activities

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.*
import com.JavaWallet.R
import android.support.design.widget.TabLayout
import android.support.v4.view.ViewPager
import com.JavaWallet.JavaWallet
import kotlinx.android.synthetic.main.activity_main.*
import com.JavaWallet.ui.fragments.Pager
import com.JavaWallet.ui.fragments.Wallet_frag
import android.nfc.tech.Ndef
import android.widget.Toast
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.support.v4.content.LocalBroadcastManager
import com.JavaWallet.BaseActivity
import com.JavaWallet.ConstantsUtils
import com.JavaWallet.ui.fragments.Listener


class MainActivity : BaseActivity(), Listener {
    override fun onDialogDisplayed() {

    }

    override fun onDialogDismissed() {
    }

    private var showAuthPopup: Boolean = false
    private var opensetting: Boolean = false
    private var showAuthPopup_txid: Int = 0
    val RESTORE_STATUS_UPDATE: Int = 0
    val RESTORE_FINISHED: Int = 1
     internal lateinit var applctn: JavaWallet


    private lateinit var localBroadcastManager: LocalBroadcastManager
    private lateinit var getAuth_Receiver: GetAuthBroadcast
    private lateinit var authFilter: IntentFilter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // wrapTabIndicatorToTitle(sliding_tabs, 40, 40)

        iv_notification.setOnClickListener {

            startNewActivity(NotificationActivity())
        }
        localBroadcastManager = LocalBroadcastManager.getInstance(mActivity)
        getAuth_Receiver = GetAuthBroadcast()
        authFilter = IntentFilter(ConstantsUtils.showAuthpop)
        try {
            var b: Bundle? = Bundle()
            b = intent.extras
            showAuthPopup = b!!.getBoolean(getString(R.string.showAuthPopup))
            showAuthPopup_txid = b!!.getInt(getString(R.string.t_id))
            opensetting = b!!.getBoolean(getString(R.string.opensetting))


        } catch (e: Exception) {
            e.printStackTrace()
        }
        setTabs()
        showVersionCheckDialog()
    }

    inner class GetAuthBroadcast : BroadcastReceiver() {

        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ConstantsUtils.showAuthpop) {
                showAuthPopup_txid = intent.extras!!.getInt(getString(R.string.t_id))
                viewpager.setCurrentItem(0);
                val tab = sliding_tabs.getTabAt(0)
                tab?.select();
                Handler().postDelayed({
                    val fragment = adapter.getRegisteredFragment(0)
                    (fragment!! as Wallet_frag).getAuthRequestApi(showAuthPopup_txid, getString(R.string.frombroadcast))
                }, 500)
            }
        }
    }



    override fun onResume() {
        super.onResume()
        localBroadcastManager.registerReceiver(getAuth_Receiver, authFilter)

    }

    override fun onPause() {
        super.onPause()
        try {
            if (isNFC()) {
                if (mNfcAdapter_base != null)
                    mNfcAdapter_base.disableForegroundDispatch(this)
            }
            localBroadcastManager.unregisterReceiver(getAuth_Receiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }


    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (isNFC()) {

            val tag = intent!!.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
            if (tag != null) {
                try {
                    Toast.makeText(this, getString(R.string.detected), Toast.LENGTH_SHORT).show()
                    val ndef = Ndef.get(tag)
                    ndef.connect()
                    val ndefMessage = ndef.ndefMessage
                    val address = String(ndefMessage.records[0].payload)
                    ndef.close()
                    mNfcReadFragmentbase.dismiss()

                    var frag1 = viewpager.getAdapter()!!.instantiateItem(viewpager, viewpager.getCurrentItem()) as Wallet_frag
                    frag1.dataWithAddress(intent, getString(R.string.main), address)

                } catch (e: Exception) {
                    e.printStackTrace()
                }

            }
        }

    }



    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val fragment = adapter.getRegisteredFragment(0)
        (fragment!! as Wallet_frag).onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        try {
            if (resultCode == RESULT_OK) {
                if (requestCode == WALLET_QRCODE) {
                    val fragment = adapter.getRegisteredFragment(0)
//                    val activeFragment = adapter.getItem(0)
                    (fragment!! as Wallet_frag).onActivityResult(requestCode, resultCode, data)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private lateinit var adapter: Pager

    private fun setTabs() {

        sliding_tabs.addTab(sliding_tabs.newTab().setText(getString(R.string.wallet)));
        sliding_tabs.addTab(sliding_tabs.newTab().setText(getString(R.string.Transactions)));
        sliding_tabs.addTab(sliding_tabs.newTab().setText(getString(R.string.Settings)));
        sliding_tabs.setTabGravity(TabLayout.GRAVITY_FILL);


        adapter = Pager(supportFragmentManager, sliding_tabs.getTabCount())
        viewpager.setAdapter(adapter)
// checking which screen should stay after changin theme

        if (showAuthPopup) {
            viewpager.setCurrentItem(0);
            val tab = sliding_tabs.getTabAt(0)
            tab?.select();
            Handler().postDelayed({
                val fragment = adapter.getRegisteredFragment(0)
                (fragment!! as Wallet_frag).getAuthRequestApi(showAuthPopup_txid, getString(R.string.fromNotifctnListClick))
            }, 500)


        } else if (opensetting) {
            viewpager.setCurrentItem(2);
            val tab = sliding_tabs.getTabAt(2)
            tab?.select();
        }



        sliding_tabs.addOnTabSelectedListener(object :
                TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {

                viewpager.setCurrentItem(tab.getPosition());


            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}

            override fun onTabReselected(tab: TabLayout.Tab) {}

        })


        viewpager?.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {

            override fun onPageScrollStateChanged(state: Int) {
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                // clearing filter data on scroll
                if (position == 0 || position == 2) {
                    trnx_type.clear()
                    status.clear()
                    coin_type.clear()
                    JavaWallet.mPreferenceDataModal.TRANS_WALLET = coin_type
                    JavaWallet.mPreferenceDataModal.TRANS_STATUS = status
                    JavaWallet.mPreferenceDataModal.TRANS_TYPE = trnx_type
                    JavaWallet.mPreferenceDataModal.FROM_DATE = ""
                    JavaWallet.mPreferenceDataModal.TO_DATE = ""
                    JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
                    /*val pos = viewpager.currentItem
                    if(pos==1){
                        val activeFragment = adapter.getItem(pos)
                        (activeFragment as Transaction_frag).getTrnasactionData()
                    }*/
                }

            }

            override fun onPageSelected(position: Int) {
                val tab = sliding_tabs.getTabAt(position)
                tab?.select();
            }

        })
    }

    override fun onBackPressed() {
        super.onBackPressed()

    }
}





