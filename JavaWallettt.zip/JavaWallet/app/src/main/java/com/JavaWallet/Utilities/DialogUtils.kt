package com.JavaWallet.Utilities

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.support.annotation.StringRes
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import com.JavaWallet.R
import kotlinx.android.synthetic.main.view_loading.view.*

/**
 * Created by user on 10/5/19.
 */
class DialogUtils private constructor() {

    init {
        throw AssertionError()
    }

    companion object {

        fun showLoading(context: Context): ProgressDialog {
            return showLoading(context, "", false)
        }

        fun showLoading(context: Context, isCancelable: Boolean): ProgressDialog {
            return showLoading(context, "", isCancelable)
        }

        fun showLoading(context: Context, message: String): ProgressDialog {
            return showLoading(context, message, false)
        }

        fun showLoading(context: Context, @StringRes message: Int): ProgressDialog {
            return showLoading(
                    context,
                    context.getString(message),
                    false
            )
        }

        fun showLoading(
                context: Context,
                @StringRes message: Int,
                isCancelable: Boolean
        ): ProgressDialog {
            return showLoading(
                    context,
                    context.getString(message),
                    isCancelable
            )
        }

        @SuppressLint("InflateParams")
        private fun showLoading(
                context: Context,
                message: String,
                isCancelable: Boolean
        ): ProgressDialog {
            val progressDialog = ProgressDialog(context)
            try {
                progressDialog.show()
                val window = progressDialog.window
                window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                val inflater = LayoutInflater.from(context)
                val view = inflater.inflate(R.layout.view_loading, null)
                if (TextUtils.isEmpty(message)) {
                    view.loading_message.visibility = View.GONE
                } else {
                    view.loading_message.text = message
                    view.loading_message.visibility = View.VISIBLE
                }
                progressDialog.setContentView(view)
                progressDialog.isIndeterminate = true
                progressDialog.setCancelable(isCancelable)
                progressDialog.setCanceledOnTouchOutside(isCancelable)
            } catch (e: Exception) {

            }
            return progressDialog
        }

        fun getAlertDialog(
                context: Context,
                message: String
        ): AlertDialog.Builder {
            return getAlertDialog(context, "", message, false)
        }

        fun getAlertDialog(
                context: Context,
                @StringRes message: Int
        ): AlertDialog.Builder {
            return getAlertDialog(
                    context,
                    "",
                    context.getString(message),
                    false
            )
        }

        fun getAlertDialog(
                context: Context,
                message: String,
                isCancelable: Boolean
        ): AlertDialog.Builder {
            return getAlertDialog(
                    context,
                    "",
                    message,
                    isCancelable
            )
        }

        fun getAlertDialog(
                context: Context,
                @StringRes message: Int,
                isCancelable: Boolean
        ): AlertDialog.Builder {
            return getAlertDialog(
                    context,
                    "",
                    context.getString(message),
                    isCancelable
            )
        }

        fun getAlertDialog(
                context: Context,
                @StringRes title: Int,
                @StringRes message: Int,
                isCancelable: Boolean
        ): AlertDialog.Builder {
            return getAlertDialog(
                    context,
                    context.getString(title),
                    context.getString(message),
                    isCancelable
            )
        }

        private fun getAlertDialog(
                context: Context,
                title: String,
                message: String,
                isCancelable: Boolean
        ): AlertDialog.Builder {
            val builder = AlertDialog.Builder(context)
            if (!TextUtils.isEmpty(title)) {
                builder.setTitle(title)
            }
            builder.setMessage(message)
            builder.setCancelable(isCancelable)
            return builder
        }
    }

}