package com.JavaWallet.ui.activities

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import com.JavaWallet.*
import kotlinx.android.synthetic.main.activity_new_pin_after_import.*
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import com.JavaWallet.FingerPrintSensor.FingerPrintStatusInfo
import com.JavaWallet.networking.BaseResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fingerprint_dialog.*
import retrofit2.HttpException


class NewPinAfterImport : BaseActivity(), View.OnClickListener {

    private lateinit var fingerprintDialog: Dialog
    var createpin_count: Int = 0
    var createpin_text: String = ""
    var iscreatepin: Boolean = true
    var confirmpin_count: Int = 0
    var confirmpin_text: String = ""
    var ispincreated: Boolean = false
    lateinit var animShake: Animation
    private var isfrom: Boolean = false
    private var isfromSetting: Boolean = false
    private var isfromTransaction: Boolean = false
    private var isthemeDark: Boolean = false
    var isfromImport = false
    private var rReceiver = ReceiverBroadCast()
    var error_count: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_pin_after_import)
        animShake = AnimationUtils.loadAnimation(this, R.anim.shake)
        if (JavaWallet.mPreferenceDataModal.WALLET_PIN.equals("")) {
            ispincreated = false
        } else {
            ispincreated = true
            tvcreate_newpin.text = getString(R.string.titleexistingpin)
        }

        try {
            var b: Bundle? = Bundle()
            b = intent.extras
            isfrom = b!!.getBoolean(getString(R.string.isfromSend))
            isfromSetting = b!!.getBoolean(getString(R.string.isfromsetting))
            isfromTransaction = b!!.getBoolean(getString(R.string.isfromTransaction))
            isfromImport = b!!.getBoolean(getString(R.string.isfromImport))
            if (isfromSetting || isfrom) {
                cross.visibility = View.VISIBLE
            } else {
                cross.visibility = View.GONE
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            isthemeDark = true
            signin_logo.setImageResource(R.drawable.javawalletwhite)
        }
        else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            isthemeDark = false
            signin_logo.setImageResource(R.drawable.javawallet)
        } else {
            isthemeDark = true
            signin_logo.setImageResource(R.drawable.javawalletwhite)
        }


        if(!isfromImport){
            if (JavaWallet.checkIsFingerprintLockEnabled(mActivity)) {
                fingerPrintDialog("success");
            } else {
                if (FingerPrintStatusInfo.FINGER_PRINT_OTHER_ERROR == JavaWallet.fingerPrintErrorStatus) {
                    //Toast.makeText(getApplicationContext(), JavaWallet.fingerPrintErrorMessage, Toast.LENGTH_LONG).show();
                } else if (FingerPrintStatusInfo.FINGER_PRINT_NO_SUPPORTED == JavaWallet.fingerPrintErrorStatus) {
                    //Toast.makeText(getApplicationContext(), "No fingerprint", Toast.LENGTH_LONG).show();
                    iv_fingerprint.visibility = View.INVISIBLE
                } else {
                    iv_fingerprint.visibility = View.VISIBLE
                    // showToast("has fingerprint but not on")
                }
            }
        }


    }

    inner class ReceiverBroadCast : BroadcastReceiver() {

        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action!!.equals(ConstantsUtils.FINGERPRINT_SUCCESS, ignoreCase = true)) {
                fingerprintDialog.dismiss()
                if (isfrom) {
                    var data = intent
                    setResult(Activity.RESULT_OK, data)
                    finish()
                } else if (isfromSetting) {
                    checkBackupCosignerApi()

                } else if (isfromTransaction) {
                    var data = intent
                    setResult(Activity.RESULT_OK, data)
                    finish()
                } else {
                    startNewActivityClearTask(MainActivity())
                    //existing user isactive will be 1
                    ConstantsUtils.isActive = 1
                }
            } else if (intent.action!!.equals(ConstantsUtils.FINGERPRINT_fail, ignoreCase = true)) {
                error_count++
                fingerprintDialog.dismiss()
                if (error_count < 3) {
                    fingerPrintDialog("fail")
                } else {
                    unregisterReceiver(rReceiver)
                }

            }
        }
    }

    private fun checkBackupCosignerApi() {
        showLoading()
        apiServiceWithAuthorization.getBackupwalletStatus(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleErrorbackup(error);hideLoading() })

    }

    private fun handleErrorbackup(error: Throwable?) {
        when (error) {
            is HttpException -> {
                when {
                    error.code() == 400 -> {
                        startNewActivity(BackupWallet())
                        finish()

                    }
                }
            }
        }
    }

    private fun handleResponse(it: BaseResponse) {
        hideLoading()
        if (it.status) {
            if (it.message.equals(getString(R.string.Requestsent))) {
                startNewActivity(BackupRequestList())
                finish()
            } else if(it.message.equals(getString(R.string.sentcosigners))){
                finish()
            }

        } else {
            startNewActivity(BackupWallet())
            finish()
        }
    }

    private fun fingerPrintDialog(case: String) {

        fingerprintDialog = Dialog(mActivity)
        fingerprintDialog.setCancelable(false)
        fingerprintDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        fingerprintDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        fingerprintDialog.setContentView(R.layout.fingerprint_dialog)

        if (case.equals("fail", true)) {
            fingerprintDialog.tv_tryagain.startAnimation(animShake)
            fingerprintDialog.ll_password.visibility = View.VISIBLE
            fingerprintDialog.tv_tryagain.visibility = View.VISIBLE
            fingerprintDialog.tv_touch.visibility = View.GONE
        } else {
            fingerprintDialog.ll_password.visibility = View.GONE
            fingerprintDialog.tv_tryagain.visibility = View.GONE
            fingerprintDialog.tv_touch.visibility = View.VISIBLE
        }
        fingerprintDialog.ll_password.setOnClickListener {
            unregisterReceiver(rReceiver)
            fingerprintDialog.dismiss()
        }
        fingerprintDialog.ll_cancel.setOnClickListener {
            unregisterReceiver(rReceiver)
            fingerprintDialog.dismiss()
        }
        fingerprintDialog.show()
    }

    override fun onResume() {
        super.onResume()

        val iFilter = IntentFilter(ConstantsUtils.FINGERPRINT_SUCCESS)
        val iFilter_fail = IntentFilter(ConstantsUtils.FINGERPRINT_fail)
        registerReceiver(rReceiver, iFilter)
        registerReceiver(rReceiver, iFilter_fail)
        onclick()
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(rReceiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    private fun onclick() {
        tvnumber_zero.setOnClickListener(this)
        tvnumber_one.setOnClickListener(this)
        tvnumber_two.setOnClickListener(this)
        tvnumber_three.setOnClickListener(this)
        tvnumber_four.setOnClickListener(this)
        tvnumber_five.setOnClickListener(this)
        tvnumber_six.setOnClickListener(this)
        tvnumber_seven.setOnClickListener(this)
        tvnumber_eight.setOnClickListener(this)
        tvnumber_nine.setOnClickListener(this)
        ivclear_number.setOnClickListener(this)
        cross.setOnClickListener(this)

    }

    override fun onClick(p0: View?) {
        when (p0) {
            cross -> {
                finish()
            }


            tvnumber_one -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "1"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "1"
                        changebackconfirm()
                    }

                }


            }
            tvnumber_two -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "2"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "2"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_three -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "3"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "3"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_four -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "4"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "4"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_five -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "5"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "5"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_six -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "6"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "6"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_seven -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "7"
                        changebackcreate()
                    }

                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "7"
                        changebackconfirm()
                    }
                }

            }
            tvnumber_eight -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "8"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "8"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_nine -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "9"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "9"
                        changebackconfirm()
                    }
                }

            }
            tvnumber_zero -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "0"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "0"
                        changebackconfirm()
                    }
                }
            }
            ivclear_number -> {

                if (isthemeDark) {
                    if (iscreatepin) {
                        if (createpin_count == 1) {
                            createpin_count--
                            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 2) {
                            createpin_count--
                            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 3) {
                            createpin_count--
                            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 4) {
                            createpin_count--
                            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        }
                    } else {

                        if (confirmpin_count == 1) {
                            confirmpin_count--
                            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 2) {
                            confirmpin_count--
                            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 3) {
                            confirmpin_count--
                            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 4) {
                            confirmpin_count--
                            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        }
                    }
                } else {
                    if (iscreatepin) {
                        if (createpin_count == 1) {
                            createpin_count--
                            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 2) {
                            createpin_count--
                            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 3) {
                            createpin_count--
                            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 4) {
                            createpin_count--
                            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        }
                    } else {

                        if (confirmpin_count == 1) {
                            confirmpin_count--
                            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 2) {
                            confirmpin_count--
                            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 3) {
                            confirmpin_count--
                            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 4) {
                            confirmpin_count--
                            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        }
                    }
                }


            }


        }

    }

    private fun changebackcreate() {

        if (isthemeDark) {
            createpin_count++
            if (createpin_text.length == 1) {
                imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 2) {
                imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 3) {
                imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 4) {
                imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
                if (ispincreated) {
                    if (JavaWallet.mPreferenceDataModal.WALLET_PIN.equals(createpin_text)) {
                        if (isfrom) {
                            var data = intent
                            setResult(Activity.RESULT_OK, data)
                            finish()
                        } else if (isfromSetting) {
                            checkBackupCosignerApi()

                        } else if (isfromTransaction) {
                            var data = intent
                            setResult(Activity.RESULT_OK, data)
                            finish()
                        } else {
                            startNewActivityClearTask(MainActivity())
                            //existing user isactive will be 1
                            ConstantsUtils.isActive = 1
                        }
                    } else {
                        imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        createpin_text = ""
                        createpin_count = 0
                        lnr_pin.startAnimation(animShake)
                        //showToast("Pin not matched")
                    }
                } else {
                    changeConfirm()
                }

            }

        } else {

            createpin_count++
            if (createpin_text.length == 1) {
                imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 2) {
                imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 3) {
                imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 4) {
                imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
                if (ispincreated) {
                    if (JavaWallet.mPreferenceDataModal.WALLET_PIN.equals(createpin_text)) {
                        if (isfrom) {
                            var data = intent
                            setResult(Activity.RESULT_OK, data)
                            finish()
                        } else if (isfromSetting) {
                            /* startNewActivity(BackupWallet())
                             finish()*/
                            checkBackupCosignerApi()
                        } else if (isfromTransaction) {
                            var data = intent
                            setResult(Activity.RESULT_OK, data)
                            finish()
                        } else {
                            startNewActivityClearTask(MainActivity())
                            //existing user isactive will be 1
                            ConstantsUtils.isActive = 1
                        }
                    } else {
                        imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                        createpin_text = ""
                        createpin_count = 0
                        lnr_pin.startAnimation(animShake)
                        //showToast("Pin not matched")
                    }
                } else {
                    changeConfirm()
                }

            }


        }


    }

    private fun changebackconfirm() {

        confirmpin_count++
        if (isthemeDark) {
            if (confirmpin_text.length == 1) {
                imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (confirmpin_text.length == 2) {
                imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (confirmpin_text.length == 3) {
                imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (confirmpin_text.length == 4) {
                imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
                checkPin()
            }
        } else {
            if (confirmpin_text.length == 1) {
                imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (confirmpin_text.length == 2) {
                imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (confirmpin_text.length == 3) {
                imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (confirmpin_text.length == 4) {
                imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
                checkPin()
            }
        }

    }

    private fun checkPin() {
        if (createpin_text.equals(confirmpin_text)) {
            JavaWallet.mPreferenceDataModal.WALLET_PIN = confirmpin_text
            JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
            //existing user isactive will be 1
            ConstantsUtils.isActive = 1
            startNewActivityClearTask(MainActivity())
        } else {
            if (isthemeDark) {
                imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
            } else {
                imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
            }

            lnr_pin.startAnimation(animShake)
            confirmpin_text = ""
            confirmpin_count = 0
            iscreatepin = false

//            showToast("Pin not matched")
        }

    }

    private fun changeConfirm() {
        iscreatepin = false
        tvcreate_newpin.text = getString(R.string.confirmnewpin)
        if (isthemeDark) {
            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
        } else {
            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
        }


    }

    private fun removeLastChar(str: String): String {
        return str.substring(0, str.length - 1)
    }

}
