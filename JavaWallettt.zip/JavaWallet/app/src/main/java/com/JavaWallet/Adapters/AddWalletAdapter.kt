package com.JavaWallet.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import com.JavaWallet.JavaWallet
import kotlinx.android.synthetic.main.addwallet_item.view.*
import android.graphics.Color
import java.util.*
import kotlin.collections.ArrayList
import android.graphics.drawable.GradientDrawable
import com.JavaWallet.BaseActivity
import com.JavaWallet.networking.CoinListData


/**
 * Created by user on 11/4/19.
 */

class AddWalletAdapter(private val coinlist: ArrayList<CoinListData>, private val listener:  Listener) : RecyclerView.Adapter< AddWalletAdapter.ViewHolder>() {

    interface Listener {

        fun onItemClick(coinListData: CoinListData, isCreateAdress: Boolean, position: Int)
    }

    private lateinit var mContext: Context
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(com.JavaWallet.R.layout.addwallet_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder:  ViewHolder, position: Int) {
        if (coinlist.get(position).status == 0) {
          //  holder.itemView.main_rltv.alpha = 0.3f
            holder.itemView.crncy_swtch.isChecked = false
        } else {
          //  holder.itemView.main_rltv.alpha = 1.0f
            holder.itemView.crncy_swtch.isChecked = true
        }
        holder.itemView.tv_coinname.text = coinlist.get(position).coinName

        val rnd = Random()
        val color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))

        try{
            if(coinlist.get(position).coinImage==null){
                holder.itemView.iv_currency.visibility=View.INVISIBLE
                holder.itemView.tv_round.visibility=View.VISIBLE
                val bgShape = holder.itemView.tv_round.getBackground() as GradientDrawable
                bgShape.setColor(color)
                holder.itemView.tv_round.text=coinlist.get(position).coinName.substring(0,1);
            }else{
                holder.itemView.iv_currency.visibility=View.VISIBLE
                holder.itemView.tv_round.visibility=View.GONE
                (mContext as BaseActivity).loadPicture_circle(holder.itemView.iv_currency, JavaWallet.IMAGEBASE_URL + coinlist.get(position).coinImage)

            }

        }catch (e:Exception){
            e.printStackTrace()
        }

        holder.itemView.crncy_swtch.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {
                if (isChecked) {
                    listener.onItemClick(coinlist.get(position), true, position)
                } else {
                    listener.onItemClick(coinlist.get(position), false, position)
                }
            }

        })

    }

    override fun getItemCount(): Int {
        return coinlist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context

        }

    }
}