package com.JavaWallet.networking

import com.google.gson.annotations.SerializedName
import java.io.Serializable

/**
 * Created by user on 10/5/19.
 */
data class BaseResponse(
        @SerializedName("status") val status: Boolean,
        @SerializedName("message") val message: String
)

data class BaseResponseisUpl(
        @SerializedName("status") val status: Boolean,
        @SerializedName("message") val message: String
)

data class BaseResponseUplSend(
        @SerializedName("status") val status: Boolean,
        @SerializedName("message") val message: String
)

data class BaseResponseUplSendOuter(
        @SerializedName("status") val status: Boolean,
        @SerializedName("message") val message: String
)

data class BaseResponsenew(
        @SerializedName("status") val status: Boolean,
        @SerializedName("message") val message: String
)

data class SendResponse(
        @SerializedName("status") val status: Boolean,
        @SerializedName("message") val message: String
)

data class ErrorResponse(
        @SerializedName("code") var error: Int,
        @SerializedName("message") var message: String
)


data class CreateUserResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("message") var message: String,
        @SerializedName("data") var data: Data
)

data class Data(
        @SerializedName("access_token") var accessToken: String,
        @SerializedName("jwt_token") var jwtToken: String
)


data class CurrencyListResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: ArrayList<CurrencyListData>
)

data class CurrencyListData(
        @SerializedName("currency_id") var currencyId: Int,
        @SerializedName("currency_name") var currencyName: String,
        @SerializedName("currency_code") var currencyCode: String,
        @SerializedName("currency_symbol") var currencySymbol: String
)


data class ManageWalletResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("admin_address") var admin_address: String,
        @SerializedName("data") var data: ArrayList<ManageWalletData>
)

data class ManageWalletData(
        @SerializedName("user_coin_id") var userCoinId: Int,
        @SerializedName("user_id") var userId: Int,
        @SerializedName("coin_id") var coinId: Int,
        @SerializedName("coin_name") var coinName: String,
        @SerializedName("coin_symbol") var coinSymbol: String,
        @SerializedName("coin_image") var coinImage: String,
        @SerializedName("is_token") var isToken: Int,
        @SerializedName("token_address") var tokenAddress: String,
        @SerializedName("decimals") var decimals: Long,
        @SerializedName("usd_price") var usdPrice: Any,
        @SerializedName("coin_status") var coinStatus: Int,
        @SerializedName("currency_id") var currencyId: Int,
        @SerializedName("currency_name") var currencyName: String,
        @SerializedName("currency_code") var currencyCode: String,
        @SerializedName("currency_symbol") var currencySymbol: String,
        @SerializedName("balance") var balance: Double,
        @SerializedName("user_withdraw_limit") var userWithdrawLimit: Double,
        @SerializedName("default_withdraw_limit") var defaultWithdrawLimit: Double,
        @SerializedName("user_coin_status") var userCoinStatus: Int,
        @SerializedName("min_fee") var min_fee: Double,
        @SerializedName("max_fee") var max_fee: Double,
        @SerializedName("percentage_fee") var percentage_fee: String,
        @SerializedName("wallet_address") var wallet_address: String,
        @SerializedName("transactions") var transactions: ArrayList<TransactionsWalletData>
)

data class TransactionsWalletData(
        @SerializedName("id") var id: Int,
        @SerializedName("user_id") var userId: Int,
        @SerializedName("type") var type: String,
        @SerializedName("amount") var amount: Double,
        @SerializedName("coin_symbol") var coinSymbol: String,
        @SerializedName("status") var status: String,
        @SerializedName("blockchain_status") var blockchainStatus: String = "NULL",
        @SerializedName("created_at") var createdAt: String
)

data class CoinListResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: ArrayList<CoinListData>
)

data class CoinListData(
        @SerializedName("coin_id") var coinId: Int,
        @SerializedName("coin_name") var coinName: String,
        @SerializedName("coin_symbol") var coinSymbol: String,
        @SerializedName("coin_image") var coinImage: String?,
        @SerializedName("coin_status") var coinStatus: Int,
        @SerializedName("is_token") var isToken: Int,
        @SerializedName("status") var status: Int,
        @SerializedName("coin_gicko_alias") var coin_gicko_alias: String,
        @SerializedName("user_coin_id") var userCoinId: Int,
        @SerializedName("isclicked") var isclicked: Boolean
)


data class AddressResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: ArrayList<AddressData>
)

data class AddressData(
        @SerializedName("payee_id") var payeeId: Int,
        @SerializedName("payee_name") var payeeName: String,
        @SerializedName("payee_address") var payeeAddress: String,
        @SerializedName("coin") var coin: Coin_mdl
)

data class Coin_mdl(
        @SerializedName("coin_name") var coinName: String,
        @SerializedName("coin_symbol") var coinSymbol: String
)


data class GasResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("gas_estimate") var gasEstimate: Int,
        @SerializedName("gas_gwei_price") var gasGweiPrice: String
)


data class NonceResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("nonce") var nonce: Int,
        @SerializedName("rawtx_required") var rawtxRequired: String,
        @SerializedName("message") var message: String
)


data class TransactionResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: ArrayList<TransactionData>
)

data class TransactionData(
        @SerializedName("id") var id: Int,
        @SerializedName("user_id") var userId: Int,
        @SerializedName("type") var type: String,
        @SerializedName("amount") var amount: String,
        @SerializedName("coin_symbol") var coinSymbol: String,
        @SerializedName("status") var status: String,
        @SerializedName("blockchain_status") var blockchainStatus: String = "NULL",
        @SerializedName("created_at") var createdAt: String,
        @SerializedName("updated_at") var updatedAt: String
)


data class TransactionDetailResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: ArrayList<TransactionDetailData>
)

data class TransactionDetailData(
        @SerializedName("from_adrs") var fromAdrs: String,
        @SerializedName("to_adrs") var toAdrs: String,
        @SerializedName("status") var status: String,
        @SerializedName("blockchain_status") var blockchainStatus: String = "NULL",
        @SerializedName("amount") var amount: Double,
        @SerializedName("coin_symbol") var coinSymbol: String,
        @SerializedName("created_at") var createdAt: String,
        @SerializedName("tx_id") var tx_id: String,
        @SerializedName("gas_limit") var gas_limit: Long,
        @SerializedName("gas_price") var gas_price: Double,
        @SerializedName("fee_priority") var fee_priority: Int,
        @SerializedName("auths") var auths: ArrayList<TransactionAuth>
)

data class TransactionAuth(
        @SerializedName("cosigner_user_id") var cosignerUserId: Int,
        @SerializedName("label") var label: String,
        @SerializedName("sign_status") var signStatus: Int
)


data class LinksResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("message") var message: String,
        @SerializedName("data") var data: LinkData
)

data class LinkData(
        @SerializedName("id") var id: Int,
        @SerializedName("content") var content: String,
        @SerializedName("created_at") var createdAt: String,
        @SerializedName("updated_at") var updatedAt: String
)


data class SentThreeFaqResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: SentThreeData
)

data class SentThreeData(
        @SerializedName("token") var token: String,
        @SerializedName("fa_status") var faStatus: Int,
        @SerializedName("fa_status_date") var faStatusDate: String,
        @SerializedName("sent_auth_reqs") var sentAuthReqs: ArrayList<SentAuthReq>
)

data class SentAuthReq(
        @SerializedName("auth_id") var authId: Int,
        @SerializedName("label") var label: String,
        @SerializedName("to_mobile") var toMobile: String,
        @SerializedName("ref_code") var refCode: String,
        @SerializedName("status") var status: Int,
        @SerializedName("created_at") var createdAt: String,
        @SerializedName("updated_at") var updatedAt: String,
        @SerializedName("country_code") var countryCode: SentThreeCountryCode
)

data class SentThreeCountryCode(
        @SerializedName("country_code_id") var countryCodeId: Int,
        @SerializedName("iso") var iso: String,
        @SerializedName("code") var code: String
)


data class CountryCodeResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: CountryCodeData
)

data class CountryCodeData(
        @SerializedName("country_code_id") var countryCodeId: Int,
        @SerializedName("country_name") var countryName: String,
        @SerializedName("country_code") var countryCode: String
)

data class ReferCodeResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: ReferCodeData
)

data class ReferCodeData(
        @SerializedName("ref_code") var refCode: String
)


data class InviteResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: InviteData
)

data class InviteData(
        @SerializedName("id") var id: Int,
        @SerializedName("label") var label: String,
        @SerializedName("to_mobile") var toMobile: String,
        @SerializedName("to_country_code_id") var toCountryCodeId: String,
        @SerializedName("from_id") var fromId: Int,
        @SerializedName("status") var status: Int,
        @SerializedName("ref_code") var refCode: String,
        @SerializedName("created_at") var createdAt: String,
        @SerializedName("updated_at") var updatedAt: String
)


data class InviteAgainResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: List<Int>
)


data class RemoveResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: Int
)

data class UserContactResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: UserContactData
)

data class UserContactData(
        @SerializedName("name") var name: String,
        @SerializedName("mobile") var mobile: String,
        @SerializedName("country_code_id") var countryCodeId: Int,
        @SerializedName("country_code") var countryCode: UserContactCountryCode
)

data class UserContactCountryCode(
        @SerializedName("country_code_id") var countryCodeId: Int,
        @SerializedName("iso") var iso: String,
        @SerializedName("code") var code: String
)


data class NotificationResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: ArrayList<NotificationData>
)

data class NotificationData(
        @SerializedName("notification_id") var notificationId: Int,
        @SerializedName("to_adrs") var toAdrs: String,
        @SerializedName("from_user_id") var from_user_id: String,
        @SerializedName("amount") var amount: Double,
        @SerializedName("coin_symbol") var coinSymbol: String,
        @SerializedName("message") var message: String,
        @SerializedName("notification_type") var notificationType: Int,
        @SerializedName("tx_id") var txId: Int,
        @SerializedName("tx_type") var txType: String,
        @SerializedName("view_status") var viewStatus: Int,
        @SerializedName("state") var state: String,
        @SerializedName("created_at") var createdAt: String
)


data class UnspntResponse(
        @SerializedName("address") var address: String,
        @SerializedName("txid") var txid: String,
        @SerializedName("vout") var vout: Int,
        @SerializedName("scriptPubKey") var scriptPubKey: String,
        @SerializedName("amount") var amount: Double,
        @SerializedName("satoshis") var satoshis: Int,
        @SerializedName("height") var height: Int,
        @SerializedName("confirmations") var confirmations: Int
)


data class ErcDataResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("message") var message: String,
        @SerializedName("data") var data: String
)


data class ReceivedRequestsResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: ReceivedRequestData
)

data class ReceivedRequestData(
        @SerializedName("token") var token: String,
        @SerializedName("fa_status") var faStatus: Int,
        @SerializedName("receive_auth_reqs") var receiveAuthReqs: ArrayList<ReceiveAuthReq>
)

data class ReceiveAuthReq(
        @SerializedName("auth_id") var authId: Int,
        @SerializedName("from_user_id") var fromUserId: Int,
        @SerializedName("label") var label: String,
        @SerializedName("to_mobile") var toMobile: String,
        @SerializedName("ref_code") var refCode: String,
        @SerializedName("status") var status: Int,
        @SerializedName("created_at") var createdAt: String,
        @SerializedName("updated_at") var updatedAt: String,
        @SerializedName("country_code") var countryCode: Any,
        @SerializedName("from_user") var fromUser: ReceiveFromUser
)

data class ReceiveFromUser(
        @SerializedName("name") var name: String,
        @SerializedName("mobile") var mobile: String,
        @SerializedName("country_code") var countryCode: ReceiveCountryCode
)

data class ReceiveCountryCode(
        @SerializedName("country_code_id") var countryCodeId: Int,
        @SerializedName("iso") var iso: String,
        @SerializedName("code") var code: String
)


data class AuthenticatorResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("message") var message: String,
        @SerializedName("data") var data: List<Int>
)

data class NonceErrorResponse(
        @SerializedName("nonce") var nonce: Int,
        @SerializedName("rawtx_required") var rawtxRequired: String,
        @SerializedName("message") var message: String
)

data class WithdrawauthResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: ArrayList<WithdrawauthData>
)

data class WithdrawauthData(
        @SerializedName("withdraw_cosign_req_id") var withdrawCosignReqId: Int,
        @SerializedName("trnx_withdraw_id") var trnxWithdrawId: Int,
        @SerializedName("to_id") var toId: Int,
        @SerializedName("from_id") var fromId: Int,
        @SerializedName("from_adrs") var fromAdrs: String,
        @SerializedName("to_adrs") var toAdrs: String,
        @SerializedName("coin_id") var coinId: Int,
        @SerializedName("coin_symbol") var coinSymbol: String,
        @SerializedName("amount") var amount: Double,
        @SerializedName("created_at") var createdAt: String,
        @SerializedName("to_name") var toName: String,
        @SerializedName("from_name") var fromName: String
)

data class Authacceptresponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: List<Int>
)


data class BackupcosignerlistResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: ArrayList<BackupcosignerlistData>
)

data class BackupcosignerlistData(
        @SerializedName("backup_request_id") var backupRequestId: Int,
        @SerializedName("cosigner_user_id") var cosignerUserId: Int,
        @SerializedName("label") var label: String,
        @SerializedName("sign_status") var signStatus: Int
)


data class BackupnotificationResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: BackupnotificationData
)

data class BackupnotificationData(
        @SerializedName("backup_request_id") var backupRequestId: Int,
        @SerializedName("from_id") var fromId: Int,
        @SerializedName("name") var name: String,
        @SerializedName("sign_status") var signStatus: Int,
        @SerializedName("created_at") var createdAt: String,
        @SerializedName("updated_at") var updatedAt: String
)

data class ContractResponse(
        @SerializedName("status") var status: String,
        @SerializedName("result") var result: Result,
        @SerializedName("message") var message: String
)

data class Result(
        @SerializedName("type") var type: String,
        @SerializedName("totalSupply") var totalSupply: String,
        @SerializedName("symbol") var symbol: String,
        @SerializedName("name") var name: String,
        @SerializedName("decimals") var decimals: String,
        @SerializedName("contractAddress") var contractAddress: String,
        @SerializedName("cataloged") var cataloged: Boolean
)


data class SearchTokenResponse(
        @SerializedName("type") var type: String,
        @SerializedName("total_supply") var totalSupply: String,
        @SerializedName("symbol") var symbol: String,
        @SerializedName("name") var name: String,
        @SerializedName("holder_count") var holderCount: Int,
        @SerializedName("decimals") var decimals: String,
        @SerializedName("contract_address_hash") var contractAddressHash: String,
        @SerializedName("cataloged") var cataloged: Boolean
)

data class CoinGeekoList(
        @SerializedName("id") var id: String,
        @SerializedName("symbol") var symbol: String,
        @SerializedName("name") var name: String
)


data class updateTokenResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: List<Int>
)


class CombinedManageWalletData : Serializable {
    @SerializedName("coin_symbol")
    var listcoin_symbol: String = ""
    @SerializedName("balance")
    var listbalance: Double = 0.0
    @SerializedName("symbol")
    var jsncoin_symbol: String = ""
    @SerializedName("current_price")
    var current_price: Double = 0.0
}


data class CoinDetailResponse(
        @SerializedName("status") var status: Boolean,
        @SerializedName("data") var data: CoinDetailData
)

data class CoinDetailData(
        @SerializedName("coin_id") var coinId: Int,
        @SerializedName("coin_name") var coinName: String,
        @SerializedName("coin_symbol") var coinSymbol: String,
        @SerializedName("coin_image") var coinImage: String,
        @SerializedName("is_token") var isToken: Int,
        @SerializedName("token_address") var tokenAddress: String,
        @SerializedName("decimals") var decimals: Int,
        @SerializedName("usd_price") var usdPrice: Any,
        @SerializedName("coin_status") var coinStatus: Int
)


data class CommisionResponse(
        @SerializedName("data")
        var data: ArrayList<CommisionResponseData>,
        @SerializedName("status")
        var status: Boolean
)

data class CommisionResponseData(
        @SerializedName("address")
        var address: String,
        @SerializedName("coin_symbol")
        var coinSymbol: String,
        @SerializedName("created_at")
        var createdAt: String,
        @SerializedName("id")
        var id: Int,
        @SerializedName("min_fee")
        var minFee: Double,
        @SerializedName("percentage_fee")
        var percentageFee: Double,
        @SerializedName("updated_at")
        var updatedAt: String
)

data class sendContractResponse(
        @SerializedName("data")
        var data: sendContractData,
        @SerializedName("message")
        var message: String,
        @SerializedName("status")
        var status: Boolean
)

data class sendContractData(
        @SerializedName("amount")
        var amount: String,
        @SerializedName("coin_family")
        var coinFamily: Int,
        @SerializedName("coin_id")
        var coinId: Int,
        @SerializedName("created_at")
        var createdAt: String,
        @SerializedName("from_adrs")
        var fromAdrs: String,
        @SerializedName("gas_limit")
        var gasLimit: String,
        @SerializedName("gas_price")
        var gasPrice: String,
        @SerializedName("id")
        var id: Int,
        @SerializedName("is_cosigner")
        var isCosigner: String,
        @SerializedName("nonce")
        var nonce: String,
        @SerializedName("req_type")
        var reqType: String,
        @SerializedName("status")
        var status: String,
        @SerializedName("to_adrs")
        var toAdrs: String,
        @SerializedName("tx_id")
        var txId: String,
        @SerializedName("tx_raw")
        var txRaw: String,
        @SerializedName("updated_at")
        var updatedAt: String,
        @SerializedName("user_id")
        var userId: Int
)

data class SendBtcResponse(
        @SerializedName("status") val status: Boolean,
        @SerializedName("message") val message: String
)

data class UnspentResponseLocal(
        @SerializedName("data")
        var data: List<UnspentResponseLocalData>,
        @SerializedName("status")
        var status: Boolean
)

data class UnspentResponseLocalData(
        @SerializedName("address")
        var address: String,
        @SerializedName("amount")
        var amount: Double,
        @SerializedName("confirmations")
        var confirmations: Int,
        @SerializedName("height")
        var height: Int,
        @SerializedName("satoshis")
        var satoshis: Int,
        @SerializedName("scriptPubKey")
        var scriptPubKey: String,
        @SerializedName("txid")
        var txid: String,
        @SerializedName("vout")
        var vout: Int
)
data class uplResponse(
        @SerializedName("data")
        var `data`: uplData,
        @SerializedName("status")
        var status: Boolean
)

data class uplData(
        @SerializedName("coin_type")
        var coinType: String,
        @SerializedName("created_at")
        var createdAt: String,
        @SerializedName("fiat_type")
        var fiatType: String,
        @SerializedName("id")
        var id: Int,
        @SerializedName("percent_change")
        var percentChange: Double,
        @SerializedName("updated_at")
        var updatedAt: String,
        @SerializedName("value")
        var value: Double
)