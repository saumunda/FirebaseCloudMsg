package com.JavaWallet.Utilities;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.JavaWallet.JavaWallet;
import com.JavaWallet.models.PreferenceDataModal;
import com.google.gson.Gson;


public class Preference {

    private final String PreferencekEY = JavaWallet.Companion.getPREFERNCE_KEY();
    private Context mContext;
    private Gson gson;


    public Preference(Context context) {
        mContext = context;
        gson = new Gson();
    }

    public static Preference getInstance(final Context context) {
        Preference Instance;
        Instance = new Preference(context.getApplicationContext());
        return Instance;
    }

    public PreferenceDataModal getSharedPreference() {
        final SharedPreferences preference = PreferenceManager.getDefaultSharedPreferences(mContext);//mContext.getSharedPreferences(MyPreference, Context.MODE_PRIVATE);
        final String sharedPerferencedata = preference.getString(PreferencekEY, "");
        final PreferenceDataModal mSharedPreferenceField = gson.fromJson(AES.decrypt(sharedPerferencedata), PreferenceDataModal.class);
        if (mSharedPreferenceField != null)
            return mSharedPreferenceField;
        else
            return new PreferenceDataModal();
    }

    public void setSharedPreference(final PreferenceDataModal preferenceField) {
        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);//mContext.getSharedPreferences(MyPreference, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = preferences.edit();
        editor.putString(PreferencekEY, AES.encrypt(gson.toJson(preferenceField)));
        editor.apply();

    }


}