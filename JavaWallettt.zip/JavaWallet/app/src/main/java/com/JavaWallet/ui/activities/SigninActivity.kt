package com.JavaWallet.ui.activities

import android.os.AsyncTask
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.support.v4.view.ViewCompat
import android.text.InputType
import android.view.View
import android.view.animation.*
import android.view.inputmethod.EditorInfo
import com.HdWaalet.FileUtils
import com.JavaWallet.*
import com.JavaWallet.models.Mnemonics_model
import kotlinx.android.synthetic.main.activity_signin.*
import org.bitcoinj.core.LegacyAddress
import org.bitcoinj.crypto.HDUtils
import org.bitcoinj.params.MainNetParams
import org.bitcoinj.params.TestNet3Params
import org.bitcoinj.wallet.DeterministicKeyChain
import org.bitcoinj.wallet.DeterministicSeed
import org.bitcoinj.wallet.KeyChainGroup


import org.web3j.crypto.Credentials
import org.web3j.crypto.MnemonicUtils.validateMnemonic
import org.web3j.crypto.WalletUtils
import java.io.File
import java.math.BigInteger


class SigninActivity : BaseActivity(), View.OnClickListener {


    lateinit var chain: DeterministicKeyChain
    var createpin_count: Int = 0
    var createpin_text: String = ""
    var iscreatepin: Boolean = true
    var confirmpin_count: Int = 0
    var confirmpin_text: String = ""
    var mnemonicdata: String = ""
    lateinit var animShake: Animation
    private var isthemeDark: Boolean = false
    var isPressed = false
    lateinit var privKey: BigInteger


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signin)
        animShake = AnimationUtils.loadAnimation(this, R.anim.shake)
        /*if (JavaWallet.mPreferenceDataModal.ISGENERATEMNEMONICSAT_SIGNIN) {
island young grass grow hole what also trumpet cattle vendor bachelor crunch" testnet btc
        }*/
        val task = Generate_mnemonics()
        task.execute()
    }

    override fun onResume() {
        super.onResume()
        edt_mnemonics.setImeOptions(EditorInfo.IME_ACTION_DONE);
        edt_mnemonics.setRawInputType(InputType.TYPE_CLASS_TEXT);
        checkTheme()
        onclick()
    }

    private fun onclick() {
        /*rl_create_one.setOnClickListener(this)
        rl_existing_two.setOnClickListener(this)*/
        tv_next.setOnClickListener(this)
        tvnumber_zero.setOnClickListener(this)
        tvnumber_one.setOnClickListener(this)
        tvnumber_two.setOnClickListener(this)
        tvnumber_three.setOnClickListener(this)
        tvnumber_four.setOnClickListener(this)
        tvnumber_five.setOnClickListener(this)
        tvnumber_six.setOnClickListener(this)
        tvnumber_seven.setOnClickListener(this)
        tvnumber_eight.setOnClickListener(this)
        tvnumber_nine.setOnClickListener(this)
        ivclear_number.setOnClickListener(this)

        rl_existing_one.setOnClickListener {
            if (isPressed) {
                isPressed = false
                ViewCompat.setElevation(rl_existing_one, 5f)
                ViewCompat.setElevation(rl_create_two, 0f)
                animateOne()
                tvlostpin.visibility = View.GONE
            }
        }
        rl_create_two.setOnClickListener {
            if (!isPressed) {
                isPressed = true
                ViewCompat.setElevation(rl_existing_one, 0f)
                ViewCompat.setElevation(rl_create_two, 5f)
                animateTwo()
                tvlostpin.visibility = View.VISIBLE
            }
        }


    }

    fun animateOne() {
        rlCreateOptions.visibility = View.GONE
        rlView.visibility = View.VISIBLE
        var anim = ScaleAnimation(1f, 1.1f, 1f, 1.1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f)
        anim.duration = 250
        anim.fillAfter = true
        anim.isFillEnabled = true
        anim.interpolator = AccelerateInterpolator() as Interpolator?
        anim.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {
                var anim1 = ScaleAnimation(1.1f, 1f, 1.1f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f)
                anim1.duration = 250
                anim1.fillAfter = true
                anim1.isFillEnabled = true
                anim1.interpolator = AccelerateInterpolator()

                rl_existing_one.startAnimation(anim1)
            }

            override fun onAnimationStart(p0: Animation?) {
            }
        })
        rl_existing_one.startAnimation(anim)
    }

    fun animateTwo() {
        rlCreateOptions.visibility = View.VISIBLE
        rlView.visibility = View.GONE
        var anim = ScaleAnimation(1.0f, 1.1f, 1.0f, 1.3f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1f)
        anim.duration = 0
        anim.fillAfter = true
        anim.isFillEnabled = true
        anim.interpolator = AccelerateInterpolator()
        anim.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {
                var anim2 = ScaleAnimation(1.1f, 1f, 1.3f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1f)
                anim2.duration = 500
                anim2.fillAfter = true
                anim2.isFillEnabled = true
                anim2.interpolator = AccelerateInterpolator()
                rl_create_two.startAnimation(anim2)
            }

            override fun onAnimationStart(p0: Animation?) {
            }
        })
        rl_create_two.startAnimation(anim)
    }

    private fun checkTheme() {

        if (Utility.getTheme(applicationContext).equals(THEME_DARK)) {
            //   signin_logo.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Darktheme));

            signin_logo.setImageResource(R.drawable.javawalletwhite)
            isthemeDark = true
        } else if (Utility.getTheme(applicationContext).equals(THEME_LIGHT)) {
            //  signin_logo.setColorFilter(resources.getColor(R.color.colorPrimary_Lighttheme));
            signin_logo.setImageResource(R.drawable.javawallet)

            isthemeDark = false
        } else {
            //  signin_logo.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Darktheme));
            signin_logo.setImageResource(R.drawable.javawalletwhite)

            isthemeDark = true
        }

    }

    override fun onClick(p0: View?) {

        when (p0) {
            /*rl_create_one -> {
                rl_existing.visibility = View.VISIBLE
                rl_create.visibility = View.GONE
            }

            rl_existing_two -> {
                rl_create.visibility = View.VISIBLE
                rl_existing.visibility = View.GONE

                *//* val task = Generate_mnemonics()
                 task.execute()*//*
            }*/

            tv_next -> {
                if (edt_mnemonics.text.toString().equals("")) {
                    showDialog(getString(R.string.mnemonicphrase), false)

                } else if (!isValidMnemonic(edt_mnemonics.text.toString())) {
                    showDialog(getString(R.string.validmnemonics), false)
                } else {
                    if (validateMnemonic(edt_mnemonics.text.toString().toLowerCase())) {
                        val task = ImportWallet(edt_mnemonics.text.toString().toLowerCase().trim())
                        task.execute()
                    } else {
                        showDialog(getString(R.string.validmnemonics), false)
                    }

                }

            }

            tvnumber_one -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "1"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "1"
                        changebackconfirm()
                    }

                }


            }
            tvnumber_two -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "2"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "2"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_three -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "3"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "3"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_four -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "4"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "4"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_five -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "5"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "5"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_six -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "6"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "6"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_seven -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "7"
                        changebackcreate()
                    }

                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "7"
                        changebackconfirm()
                    }
                }

            }
            tvnumber_eight -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "8"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "8"
                        changebackconfirm()
                    }
                }
            }
            tvnumber_nine -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "9"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "9"
                        changebackconfirm()
                    }
                }

            }
            tvnumber_zero -> {
                if (iscreatepin) {
                    if (createpin_text.length < 4) {
                        createpin_text = createpin_text + "0"
                        changebackcreate()
                    }
                } else {
                    if (confirmpin_text.length < 4) {
                        confirmpin_text = confirmpin_text + "0"
                        changebackconfirm()
                    }
                }
            }
            ivclear_number -> {

                if (isthemeDark) {
                    if (iscreatepin) {
                        if (createpin_count == 1) {
                            createpin_count--
                            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 2) {
                            createpin_count--
                            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 3) {
                            createpin_count--
                            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 4) {
                            createpin_count--
                            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                            createpin_text = removeLastChar(createpin_text)
                        }
                    } else {

                        if (confirmpin_count == 1) {
                            confirmpin_count--
                            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 2) {
                            confirmpin_count--
                            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 3) {
                            confirmpin_count--
                            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 4) {
                            confirmpin_count--
                            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundary))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        }
                    }
                } else {
                    if (iscreatepin) {
                        if (createpin_count == 1) {
                            createpin_count--
                            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 2) {
                            createpin_count--
                            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 3) {
                            createpin_count--
                            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        } else if (createpin_count == 4) {
                            createpin_count--
                            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            createpin_text = removeLastChar(createpin_text)
                        }
                    } else {

                        if (confirmpin_count == 1) {
                            confirmpin_count--
                            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 2) {
                            confirmpin_count--
                            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 3) {
                            confirmpin_count--
                            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        } else if (confirmpin_count == 4) {
                            confirmpin_count--
                            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                            confirmpin_text = removeLastChar(confirmpin_text)
                        }
                    }
                }


            }


        }

    }

    private fun isValidMnemonic(mnemonics: String): Boolean {
        var mnemonic_list = mnemonics.split(" ")
        if (mnemonic_list.contains("")) {
            return false
        }
        return true
        
    }


    private fun changebackcreate() {
        createpin_count++
        if (createpin_text.length == 1) {
            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
        } else if (createpin_text.length == 2) {
            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
        } else if (createpin_text.length == 3) {
            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
        } else if (createpin_text.length == 4) {
            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            changeConfirm()
        }
        /*if (isthemeDark) {
            if (createpin_text.length == 1) {
                imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_full))
            } else if (createpin_text.length == 2) {
                imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_full))
            } else if (createpin_text.length == 3) {
                imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_full))
            } else if (createpin_text.length == 4) {
                imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_full))
                changeConfirm()
            }
        } else {
            if (createpin_text.length == 1) {
                imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 2) {
                imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 3) {
                imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            } else if (createpin_text.length == 4) {
                imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
                changeConfirm()
            }
        }
*/
    }

    private fun changebackconfirm() {
        confirmpin_count++
        if (confirmpin_text.length == 1) {
            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
        } else if (confirmpin_text.length == 2) {
            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
        } else if (confirmpin_text.length == 3) {
            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
        } else if (confirmpin_text.length == 4) {
            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_fullblack))
            checkPin()
        }

    }

    private fun checkPin() {
        if (createpin_text.equals(confirmpin_text)) {
            JavaWallet.mPreferenceDataModal.WALLET_PIN = confirmpin_text
            JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)

            // startNewActivity(BackMnemonics())

            var bndl = Bundle()
            bndl.putBoolean(getString(R.string.isfromcreate), true)
            bndl.putBoolean(getString(R.string.isfromsetting), false)
            callActivityWithData(Backupnow::class.java, bndl)

            Handler().postDelayed({
                createpin_count = 0
                createpin_text = ""
                iscreatepin = true
                confirmpin_count = 0
                confirmpin_text = ""

                imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
                imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))

                tvcreate_newpin.text = getString(R.string.create_new_pin)

            }, 1000)

        } else {

            imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
            imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
            imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
            imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))

            lnr_pin.startAnimation(animShake)
            confirmpin_text = ""
            confirmpin_count = 0
            iscreatepin = false

        }

    }

    private fun changeConfirm() {
        iscreatepin = false
        tvcreate_newpin.text = getString(R.string.confirmnewpin)
        imgcircle_one.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
        imgcircle_two.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
        imgcircle_three.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))
        imgcircle_four.setBackgroundDrawable(getResources().getDrawable(R.drawable.circle_boundaryblack))


    }

    private fun removeLastChar(str: String): String {
        return str.substring(0, str.length - 1)
    }

    inner class Generate_mnemonics : AsyncTask<Void, Void, Mnemonics_model>() {
        override fun doInBackground(vararg p0: Void?): Mnemonics_model {
            val path = Environment.getDataDirectory().toString() + "/data/" + packageName + "/ACW/"
            FileUtils.createDirIfNotExists(Environment.getDataDirectory().toString() + "/data/" + packageName + "/ACW/")
            val wallet = WalletUtils.generateBip39Wallet("", File(path))
            val mnemonics = wallet.mnemonic
            //  bitcoinj
            var seed = DeterministicSeed(wallet.mnemonic, null, "", 1409478661L)
            chain = DeterministicKeyChain.builder().seed(seed).build()
            if (JavaWallet.is_MainNet) {
                // Mainnet
                val keyPath = HDUtils.parsePath("M/44H/0H/0H/0/0")
                val key = chain.getKeyByPath(keyPath, true)
                privKey = key.privKey

                val keyPathB = HDUtils.parsePath("M/44H/0H/0H/0/0")
                val keyB = chain.getKeyByPath(keyPathB, true)
                val privKeyB = keyB.getPrivateKeyEncoded(MainNetParams.get());
                val btc_address = LegacyAddress.fromKey(MainNetParams.get(), keyB).toString()
                val privateKeyb58 = privKeyB.toBase58()
                JavaWallet.mPreferenceDataModal.BTC_ADDRESS = btc_address
                JavaWallet.mPreferenceDataModal.PRIVATE_KEYBTC = privateKeyb58
                JavaWallet.mPreferenceDataModal.PRIVATE_KEY = privKey
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
            } else {
                // testnet
                val keyPath = HDUtils.parsePath("M/44H/1H/0H/0/0")
                val key = chain.getKeyByPath(keyPath, true)
                privKey = key.privKey

                val keyPathB = HDUtils.parsePath("M/44H/1H/0H/0/0")
                val keyB = chain.getKeyByPath(keyPathB, true)
                val privKeyB = keyB.getPrivateKeyEncoded(TestNet3Params.get());
                val btc_address = LegacyAddress.fromKey(TestNet3Params.get(), keyB).toString()
                val privateKeyb58 = privKeyB.toBase58()
                JavaWallet.mPreferenceDataModal.BTC_ADDRESS = btc_address
                JavaWallet.mPreferenceDataModal.PRIVATE_KEYBTC = privateKeyb58
                JavaWallet.mPreferenceDataModal.PRIVATE_KEY = privKey
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)

            }

            val keyPath = HDUtils.parsePath("M/44H/60H/0H/0/0")
            val key = chain.getKeyByPath(keyPath, true)
            val ethprivKey = key.privKey

            JavaWallet.mPreferenceDataModal.ETHPRIVATE_KEY = ethprivKey
            JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)



            // Web3j
            val credentials = Credentials.create(ethprivKey.toString(16))
            val eth_address = credentials.address
            FileUtils.deleteFile(path + wallet.filename)
            var mdl = Mnemonics_model()
            mdl.coin_address = eth_address
            mdl.coin_mnemonic = mnemonics

            return mdl
        }

        override fun onPostExecute(result: Mnemonics_model?) {
            super.onPostExecute(result)
            JavaWallet.mPreferenceDataModal.COIN_ADDRESS = result!!.coin_address
            JavaWallet.mPreferenceDataModal.COIN_MNEMONICS = result!!.coin_mnemonic
            JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)

        }


    }

    inner class ImportWallet(mnemonics: String) : AsyncTask<Void, Void, Mnemonics_model>() {
        init {
            mnemonicdata = mnemonics
        }

        override fun onPreExecute() {
            super.onPreExecute()
            showLoading()
        }

        override fun doInBackground(vararg p0: Void?): Mnemonics_model {

            var seed: DeterministicSeed? = null
            seed = DeterministicSeed(mnemonicdata, null, "", 1409478661L)
            chain = DeterministicKeyChain.builder().seed(seed).build()

            if (JavaWallet.is_MainNet) {
                // Mainnet
                val keyPath = HDUtils.parsePath("M/44H/0H/0H/0/0")
                val key = chain.getKeyByPath(keyPath, true)
                privKey = key.privKey
                val keyPathB = HDUtils.parsePath("M/44H/0H/0H/0/0")
                val keyB = chain.getKeyByPath(keyPathB, true)
                val privKeyB = keyB.getPrivateKeyEncoded(MainNetParams.get());
                val btc_address = LegacyAddress.fromKey(MainNetParams.get(), keyB).toString()
                val privateKeyb58 = privKeyB.toBase58()
                JavaWallet.mPreferenceDataModal.BTC_ADDRESS = btc_address
                JavaWallet.mPreferenceDataModal.PRIVATE_KEYBTC = privateKeyb58
                JavaWallet.mPreferenceDataModal.PRIVATE_KEY = privKey
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
            } else {
                // testnet
                val keyPath = HDUtils.parsePath("M/44H/1H/0H/0/0")
                val key = chain.getKeyByPath(keyPath, true)
                privKey = key.privKey
                val keyPathB = HDUtils.parsePath("M/44H/1H/0H/0/0")
                val keyB = chain.getKeyByPath(keyPathB, true)
                val privKeyB = keyB.getPrivateKeyEncoded(TestNet3Params.get());
                val btc_address = LegacyAddress.fromKey(TestNet3Params.get(), keyB).toString()
                val privateKeyb58 = privKeyB.toBase58()
                JavaWallet.mPreferenceDataModal.BTC_ADDRESS = btc_address
                JavaWallet.mPreferenceDataModal.PRIVATE_KEYBTC = privateKeyb58
                JavaWallet.mPreferenceDataModal.PRIVATE_KEY = privKey
                JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
            }




            val keyPath = HDUtils.parsePath("M/44H/60H/0H/0/0")
            val key = chain.getKeyByPath(keyPath, true)
            val ethprivKey = key.privKey


            JavaWallet.mPreferenceDataModal.ETHPRIVATE_KEY = ethprivKey
            JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)


            val credentials = Credentials.create(ethprivKey.toString(16))
            var mdl = Mnemonics_model()
            mdl.coin_address = credentials.address
            mdl.coin_mnemonic = mnemonicdata
            return mdl
        }

        override fun onPostExecute(result: Mnemonics_model?) {
            super.onPostExecute(result)
            hideLoading()
            JavaWallet.mPreferenceDataModal.COIN_ADDRESS = result!!.coin_address
            JavaWallet.mPreferenceDataModal.COIN_MNEMONICS = result!!.coin_mnemonic
            JavaWallet.setPreference(JavaWallet.mPreferenceDataModal)
            var bndl = Bundle()
            bndl.putBoolean(getString(R.string.isfromSend), false)
            bndl.putBoolean(getString(R.string.isfromsetting), false)
            bndl.putBoolean(getString(R.string.isfromTransaction), false)
            bndl.putBoolean(getString(R.string.isfromImport), true)
            callActivityWithData(NewPinAfterImport::class.java, bndl)
        }
    }


}
