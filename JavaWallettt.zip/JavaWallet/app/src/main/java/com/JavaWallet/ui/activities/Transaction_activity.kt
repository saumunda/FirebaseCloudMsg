package com.JavaWallet.ui.activities

import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import com.JavaWallet.Adapters.TransactionAdapter
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.Utility
import com.JavaWallet.networking.TransactionData
import com.JavaWallet.networking.TransactionRequest
import com.JavaWallet.networking.TransactionResponse
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_transaction_activity.*
import kotlinx.android.synthetic.main.header_title.*

class Transaction_activity : BaseActivity() {
    private var isthemeDark: Boolean = false

    private lateinit var linearLayoutManager: LinearLayoutManager
    lateinit var transactionlist: ArrayList<TransactionData>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transaction_activity)

        linearLayoutManager = LinearLayoutManager(mActivity)
        recycl_transction.layoutManager = linearLayoutManager
        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            isthemeDark = true
            iv_back.setColorFilter(resources.getColor(R.color.white));
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            isthemeDark = false
            iv_back.setColorFilter(resources.getColor(R.color.logout_light));
        } else {
            isthemeDark = true
            iv_back.setColorFilter(resources.getColor(R.color.white));
        }
        coin_type.clear()
        try {
            var b: Bundle? = Bundle()
            b = intent.extras
            var coinSymbol = b!!.getString(getString(R.string.coinSymbol))
            var coinName = b!!.getString(getString(R.string.coinName))
            tv_title.text = coinName + getString(R.string.transactions)
            coin_type.add(coinSymbol)

        } catch (e: Exception) {

        }
        iv_back.setOnClickListener {
            finish()
        }
        if (isInternetConnected()) {
            getTrnasactionData()
        } else {
            showDialog(getString(R.string.network_error), false)
        }
    }


    fun getTrnasactionData() {

        showLoading()
        var rqst = TransactionRequest(coin_type, trnx_type, "", "", status)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.getTransaction(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); })


    }

    private fun handleResponse(it: TransactionResponse?) {

        hideLoading()
        if (it!!.status) {
            transactionlist = it.data
            var adptr = TransactionAdapter(transactionlist, isthemeDark)
            recycl_transction.adapter = adptr
        }
    }
}
