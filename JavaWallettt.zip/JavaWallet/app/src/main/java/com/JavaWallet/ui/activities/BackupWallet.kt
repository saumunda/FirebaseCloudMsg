package com.JavaWallet.ui.activities

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import com.JavaWallet.Adapters.MnemonicsAdptr
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utility
import kotlinx.android.synthetic.main.activity_backup_wallet.*
import kotlinx.android.synthetic.main.activity_backup_wallet.tv_copy
import kotlinx.android.synthetic.main.activity_backup_wallet.tv_mnemonics_data
import kotlinx.android.synthetic.main.header_title.*

class BackupWallet : BaseActivity(), View.OnClickListener, MnemonicsAdptr.MnemonicListner {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_backup_wallet)
        tv_title.text = ""
        OnClicks()
        tv_title.setTextColor(resources.getColor(R.color.white))
        cb_stored.setOnCheckedChangeListener { buttonView, isChecked ->
            if (buttonView.isPressed) {
                if (isChecked) {
                    tv_nextSubmit.visibility = View.VISIBLE
                } else {
                    tv_nextSubmit.visibility = View.INVISIBLE
                }
            }
        }
    }

    private fun OnClicks() {
        tv_nextSubmit.setOnClickListener(this)
        iv_back.setOnClickListener(this)
        tv_okay.setOnClickListener(this)
        tv_copy.setOnClickListener(this)
    }

    override fun onResume() {
        super.onResume()

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
         } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
         } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
         }

        val layoutManager: RecyclerView.LayoutManager = GridLayoutManager(this, 3)
        recl_mnmncs.layoutManager = layoutManager
        val adapter = MnemonicsAdptr(JavaWallet.mPreferenceDataModal.COIN_MNEMONICS.split(" "), this, false)
        recl_mnmncs.adapter = adapter
        tv_mnemonics_data.text = JavaWallet.mPreferenceDataModal.COIN_MNEMONICS
    }

    override fun onClick(p0: View?) {
        when (p0) {

            iv_back -> {

                finish()

            }
            tv_nextSubmit -> {
                var bndl = Bundle()
                bndl.putBoolean(getString(R.string.isfromcreate), false)
                callActivityWithData(Backupsecond::class.java, bndl)


            }
            tv_okay -> {
                finish()
            }

            tv_copy -> {

                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText(getString(R.string.label), tv_mnemonics_data.text.toString())
                clipboard.primaryClip = clip
                showToast(getString(R.string.mnemonicscopied))
            }
        }

    }

    override fun onAddress_Click(position: Int) {
    }


}
