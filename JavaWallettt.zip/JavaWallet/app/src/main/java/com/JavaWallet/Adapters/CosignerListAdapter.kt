package Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.R
import com.JavaWallet.networking.BackupcosignerlistData
import kotlinx.android.synthetic.main.address_item.view.tv_name
import kotlinx.android.synthetic.main.cosignerlist_item.view.*

/**
 * Created by user on 11/4/19.
 */

class CosignerListAdapter(private val addresslist: ArrayList<BackupcosignerlistData>, private val lstnr:  RqstListner) : RecyclerView.Adapter< CosignerListAdapter.ViewHolder>() {

    private lateinit var mContext: Context

    interface RqstListner {
        fun onrqst_Click(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):  CosignerListAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.cosignerlist_item, parent, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(holder:  CosignerListAdapter.ViewHolder, position: Int) {
        val listdata = addresslist.get(position)
        holder.itemView.tv_name.text = listdata.label

        if (listdata.signStatus == 0) {
            holder.itemView.tv_statuscsnr.text = mContext.getString(R.string.Pending)
            holder.itemView.tv_request.visibility=View.VISIBLE
            holder.itemView.tv_statuscsnr.setTextColor(mContext.resources.getColor(R.color.yellow))
        } else if (listdata.signStatus == 1) {
            holder.itemView.tv_statuscsnr.text = "Accepted"
            holder.itemView.tv_request.visibility=View.GONE
            holder.itemView.tv_statuscsnr.setTextColor(mContext.resources.getColor(R.color.greenbottom))
        } else if (listdata.signStatus == 2) {
            holder.itemView.tv_statuscsnr.text = "Declined"
            holder.itemView.tv_request.visibility=View.VISIBLE
            holder.itemView.tv_statuscsnr.setTextColor(mContext.resources.getColor(R.color.red))
        }
        holder.itemView.tv_request.setOnClickListener {
            lstnr.onrqst_Click(position)
        }


    }

    override fun getItemCount(): Int {
        return addresslist.size
    }


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            mContext = itemView.context
        }

        fun bindItems() {

        }
    }
}