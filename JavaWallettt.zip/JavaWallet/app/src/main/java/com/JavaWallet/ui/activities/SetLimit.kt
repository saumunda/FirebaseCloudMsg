package com.JavaWallet.ui.activities

import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import com.JavaWallet.Adapters.SetLimit_Adapter
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import com.JavaWallet.Utility
import com.JavaWallet.networking.ManageWalletData
import com.JavaWallet.networking.ManageWalletResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_set_limit.*
import kotlinx.android.synthetic.main.header_title.*
import java.util.*

class SetLimit : BaseActivity(), SetLimit_Adapter.Listner {


    private lateinit var linearLayoutManager: LinearLayoutManager
    lateinit var walletlist: ArrayList<ManageWalletData>
    private lateinit var adpter: SetLimit_Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_limit)
    }

    override fun onResume() {
        super.onResume()
        linearLayoutManager = LinearLayoutManager(this)
        rcycl_setlimit.layoutManager = linearLayoutManager

        tv_title.text = getString(R.string.titlelimit)
        iv_back.setOnClickListener {
            onBackPressed()
        }
        if (isInternetConnected()) {
            getData()
        }
        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
        }else{
            iv_back.setColorFilter(resources.getColor(R.color.white));
        }
    }

    override fun onBackPressed() {

        var bndl = Bundle()
        bndl.putBoolean(getString(R.string.is_sent), true)
        callActivityWithData(ThreeFactor::class.java, bndl)
        finish()
    }



    override fun onClickk(limit_value: String) {


    }

    private fun getData() {
        showLoading()
        apiServiceWithAuthorization.managewallet(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })
    }

    private fun handleResponse(it: Any?) {
        hideLoading()
        when (it) {
            is ManageWalletResponse -> {
                if (it.status) {
                    walletlist = it.data
                    adpter = SetLimit_Adapter(walletlist, this)
                    rcycl_setlimit.adapter = adpter
                }
            }

        }

    }


}
