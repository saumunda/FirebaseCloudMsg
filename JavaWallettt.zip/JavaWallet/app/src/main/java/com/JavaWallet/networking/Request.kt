package com.JavaWallet.networking

import com.google.gson.annotations.SerializedName
import java.io.Serializable

/**
 * Created by user on 10/5/19.
 */
data class createAddressRequest(
        var address: String,
        var type: String,
        var device_token: String,
        var is_active: Int,
        var device_type: Int = 0

)

class createUserRequest : Serializable {
    @SerializedName("address")
    var address: String = ""
    @SerializedName("type")
    var type: String = ""
    @SerializedName("device_token")
    var device_token: String = ""
    @SerializedName("is_active")
    var is_active: Int = 0
    @SerializedName("device_type")
    var device_type: Int = 0
    @SerializedName("is_production")
    var is_production: Int = 0

}

class DefaultCurrencyRequest : Serializable {
    @SerializedName("currency_fiat_id")
    var currency_fiat_id: Int = 0

}

class CsgnrRequest : Serializable {
    @SerializedName("backup_request_id")
    var backup_request_id: Int = 0
    @SerializedName("cosigner_user_id")
    var cosigner_user_id: Int = 0

}

data class sendCoinRequest(
        var nonce: Long,
        var tx_raw: String,
        var from: String,
        var to: String,
        var amount: String,
        var gas_estimate: Double,
        var eth_gas_price: Double,
        var token_data_swapping: String,
        var fee_priority: Int,
        var is_eth_outer: Boolean


)
data class disablecoinRequest(
        var device_token: String,
        var is_production: Int


)

data class sendCoinCosigerRequest(
        var tx_id: Int,
        var tx_raw: String,
        var nonce: Long,
        var gas_estimate: Double,
        var eth_gas_price: Long

)

data class TransactionRequest(
        var coin_type: ArrayList<String>,
        var trnx_type: ArrayList<String>,
        var from_date: String,
        var to_date: String,
        var status: ArrayList<String>
)


data class ThreeFactorRequest(
        var to_label: String,
        var to_mobile: String,
        var to_country_code_id: String,
        var from_label: String,
        var from_mobile: String,
        var from_country_code_id: String,
        var ref_code: String
)

data class SearchRequest(
        @SerializedName("search") var search: String
)

data class DisableCoinRequest(
        var is_active: Int,
        var user_coin_id: Int

)

data class WithdrawLimitRequest(
        var user_coin_id: Int,
        var withdraw_limit: Double

)

data class AddpayeeRequest(
        var payee_name: String,
        var payee_address: String,
        var payee_address_type: String

)
data class IsUplWalletRequest(
        var from: String,
        var to: String

)

data class sendUplWalletRequest(
        var from: String?,
        var to: String?,
        var amount: String?

)
data class GetuserpayeeRequest(
        var coin_type: String

)

data class RemoveuserpayeeRequest(
        var payee_id: Int

)
data class uplRequest(
        var coin_type: String,
        var fiat_type: String


)

data class GasEstimateRequest(
        var to: String,
        var amount: String

)
//data class demoRequest(
//        var captchatext: String,
//        var code: String,
//        var confirmPassword: String,
//        var email: String,
//        var firstName: String,
//        var lastName: String,
//        var password: String
//
//)

data class GetNonceRequest(

        var amount: String,
        var is_eth_outer: Boolean

)

data class InviteRemoveRequest(

        var auth_id: Int

)

data class onoffAuthenticatorRequest(

        var is_active: Int

)

data class AcceptDeclineSendRequest(

        var auth_id: Int,
        var status: String

)

data class RemoveRequest(

        var auth_id: Int


)

data class TransactiondetailsRequest(

        var trnx_id: Int,
        var trnx_type: String

)

data class RequestAgainRequest(

        var co_signer: Int,
        var txid: Int

)

data class GetCountryCodeRequest(

        var iso: String

)

data class sortWalletRequest(

        var user_coin_id: String

)

data class authwithdrawRequest(

        var tx_id: Int

)

data class bkRequest(

        var from_user_id: String

)

data class bkRequestAcceptDecline(

        var backup_request_id: Int,
        var status: Int,
        var from_id: Int

)

data class addTokenRequest(

        var name: String,
        var symbol: String,
        var gicko_alias: String,
        var decimals: String,
        var contract_address: String

)

data class cancelBroadcastRequest(

        var trnx_id: Int

)

data class addreferalRequest(

        var ref_code: String

)

data class GetERCDataRequest(

        var my_address: String,
        var dest_address: String,
        var coin_type: String,
        var amount: String

)

data class AcceptDeclineAuthRequest(

        var from_id: Int,
        var withdraw_cosign_req_id: Int,
        var status: Int,
        var trnx_withdraw_id: Int

)

data class TokenRequest(
        var device_token: String,
        var device_type: Int,
        var is_production: Int
)

data class afterSendRequest(
        var tx_hash: String,
        var from: String,
        var to: String,
        var amount: Double,
        var nonce: Int,
        var gas_estimate: Long,
        var gas_price: Long,
        var tx_status: String,
        var withdraw_id : Int
)
data class saveTrxRequest(

        var tx_hash: String,
        var from: String,
        var to: String,
        var amount: String,
        var nonce: Long,
        var gas_estimate: Double,
        var eth_gas_price: Double

)

data class updatetrxRequest(
        var withdraw_id: Int,
        var tx_hash: String


)