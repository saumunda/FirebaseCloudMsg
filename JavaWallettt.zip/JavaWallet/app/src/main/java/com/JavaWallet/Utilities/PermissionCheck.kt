package com.JavaWallet.Utilities

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.os.Build
import android.support.v4.app.ActivityCompat
import android.widget.Toast
import com.JavaWallet.PermissionInterface

/**
 * Created by user on 16/5/19.
 */
class PermissionCheck() {
    lateinit var ctx: Context
    val PERMISSION_REQUEST_CODE = 1080
    lateinit var callback: PermissionInterface

    constructor(ctx: Context, callback: PermissionInterface) : this() {
        this.ctx = ctx
        this.callback = callback
    }

    constructor(ctx: Context) : this() {
        this.ctx = ctx
    }

    fun checkPermission(permissions: Array<String>, callback: PermissionInterface) {
        var isPermission = true
        for (i in permissions.indices) {
            if (ActivityCompat.checkSelfPermission(ctx, permissions[i]) != PackageManager.PERMISSION_GRANTED) {
                isPermission = false
            }
        }
        if (!isPermission) {
            requestPermission(permissions)
        } else {
            callback.permissionAccepted()
        }
    }

    private fun requestPermission(permissions: Array<String>) {
        ActivityCompat.requestPermissions(ctx as Activity, permissions, PERMISSION_REQUEST_CODE)
    }

    fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> if (grantResults.size > 0) {
                var isPermission = true
                for (i in permissions.indices) {
                    if (ActivityCompat.checkSelfPermission(ctx, permissions[i]) != PackageManager.PERMISSION_GRANTED) {
                        isPermission = false
                    }
                }
                if (isPermission) {
                    callback.permissionAccepted()
                } else {
                    showToast("Permission Denied, application might not work as desired.")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if ((ctx as Activity).shouldShowRequestPermissionRationale(android.Manifest.permission.CAMERA)) {
                            showMessageOKCancel("You need to allow access to all the permissions",
                                    DialogInterface.OnClickListener { dialog, which ->
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                            (ctx as Activity).requestPermissions(permissions,
                                                    PERMISSION_REQUEST_CODE)
                                        }
                                    })
                            return
                        }
                    }
                }
            }
        }
    }

    private fun showMessageOKCancel(message: String, okListener: DialogInterface.OnClickListener) {
        AlertDialog.Builder(ctx)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show()
    }

    fun showToast(message: String) {
        Toast.makeText(ctx, message, Toast.LENGTH_LONG).show()
    }
}