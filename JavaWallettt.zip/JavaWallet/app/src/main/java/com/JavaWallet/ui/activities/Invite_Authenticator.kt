package com.JavaWallet.ui.activities

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView
import com.JavaWallet.models.Country_model
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_invite__authenticator.*
import kotlinx.android.synthetic.main.countrydialog.*
import kotlinx.android.synthetic.main.countrydialog_item.view.*
import kotlinx.android.synthetic.main.header_title.*
import android.widget.Toast
import com.JavaWallet.*
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.networking.*
import com.google.gson.Gson
import kotlinx.android.synthetic.main.logout_dialog.*
import retrofit2.HttpException


class Invite_Authenticator : BaseActivity(), View.OnClickListener {
    var delay: Long = 100 // 1 seconds after user stops typing
    var last_text_edit: Long = 0
    var handler = Handler()
    var isinvitecountrycode: Boolean = false
    private lateinit var refcode: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_invite__authenticator)
        if (isInternetConnected()) {
            getReferCodeApi()
            getCountries()
        } else {
            showDialog(getString(R.string.network_error), false)
        }
    }

    override fun onResume() {
        super.onResume()
        tv_title.text = getString(R.string.title_inviteauthenticator)
        iv_back.setOnClickListener {
            onBackPressed()
        }

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
            tv_title.setTextColor(resources.getColor(R.color.white))
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
            tv_title.setTextColor(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme))
        } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
            tv_title.setTextColor(resources.getColor(R.color.white))
        }
        onClick()


        edt_label.setOnEditorActionListener(TextView.OnEditorActionListener { textView, i, keyEvent ->
            if (i == EditorInfo.IME_ACTION_DONE) {
                setdata(refcode, edt_label.text.toString().trim(), edt_yourlabel.text.toString().trim())
                hidekeyboard(edt_label)
                true
            } else false
        })

        edt_yourlabel.setOnEditorActionListener(TextView.OnEditorActionListener { textView, i, keyEvent ->
            if (i == EditorInfo.IME_ACTION_DONE) {
                setdata(refcode, edt_label.text.toString().trim(), edt_yourlabel.text.toString().trim())
                hidekeyboard(edt_yourlabel)
                true
            } else false
        })

        edt_label.setOnFocusChangeListener { view, b ->
            if (!b) {
                setdata(refcode, edt_label.text.toString().trim(), edt_yourlabel.text.toString().trim())
            }
        }

        edt_yourlabel.setOnFocusChangeListener { view, b ->
            if (!b) {
                setdata(refcode, edt_label.text.toString().trim(), edt_yourlabel.text.toString().trim())
            }
        }

    }

    override fun onBackPressed() {
        var bndl = Bundle()
        bndl.putBoolean(getString(R.string.is_sent), true)
        callActivityWithData(ThreeFactor::class.java, bndl)
        finish()
    }
    private fun onClick() {

        tv_countrycode.setOnClickListener(this)
        tv_yourcountrycode.setOnClickListener(this)
        tv_sendinvitation.setOnClickListener(this)
    }



    override fun onClick(p0: View?) {
        when (p0) {
            tv_countrycode -> {
                isinvitecountrycode = true
                countrySelectionPopup(countryString, this)
            }
            tv_yourcountrycode -> {
                isinvitecountrycode = false
                countrySelectionPopup(countryString, this)
            }
            tv_sendinvitation -> {
                if (tv_countrycode.text.toString().trim().equals("") || edt_invitephone.text.toString().trim().equals("")
                        || edt_label.text.toString().trim().equals("") || edt_message.text.toString().trim().equals("")
                        || edt_yourlabel.text.toString().trim().equals("") || tv_yourcountrycode.text.toString().trim().equals("")
                        || edt_yourphone.text.toString().trim().equals("")) {

                    showDialog(getString(R.string.fill_fields), false)

                } else if (edt_invitephone.text.toString().trim().length < 8 || edt_yourphone.text.toString().trim().length < 8) {
                    showDialog(getString(R.string.valid_phone), false)
                } else {
                    val intent = Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(getString(R.string.smsto)+tv_countrycode.text.toString().trim() + edt_invitephone.text.toString().trim()));
                    intent.putExtra(getString(R.string.smsaddress), tv_countrycode.text.toString().trim() + edt_invitephone.text.toString().trim());
                    intent.putExtra(getString(R.string.sms_body), edt_message.text.toString().trim());
                    intent.putExtra(getString(R.string.exit_on_sent), true);
                    startActivityForResult(intent, 101);

                }

             /*   val setSmsAppIntent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                setSmsAppIntent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                startActivityForResult(setSmsAppIntent, 123)*/

            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 101) {
            when (resultCode) {
                Activity.RESULT_OK -> showconfirmDialog()
                Activity.RESULT_CANCELED // unfortunately returned by default android sms app at the moment
                -> showconfirmDialog()
                else -> Toast.makeText(this, getString(R.string.errorsendingtext), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showconfirmDialog() {

        var dialog = Dialog(mActivity)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.logout_dialog)
        dialog.dialog_message.text = getString(R.string.sentthemessage)
        dialog.dialog_no.setOnClickListener {
            dialog.dismiss()
            showToast(getString(R.string.messageagain))
        }
        dialog.dialog_yes.setOnClickListener {
            dialog.dismiss()
            inviteAuthApi()
            // ConstantsUtils.CurrentScreen = 0

        }
        dialog.show()
    }


    fun countrySelectionPopup(countryList: ArrayList<Country_model>, ctx: Context) {
        val dialog = Dialog(ctx)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setContentView(R.layout.countrydialog)
        dialog.setCancelable(true)
        dialog.tvDismiss.setOnClickListener { dialog.dismiss() }

        val input_finish_checker = Runnable {
            if (System.currentTimeMillis() > last_text_edit + delay - 500) {
                var newList = countryList.filter {
                    it.countryName.toLowerCase().contains(dialog.etSearch.text.toString().trim().toLowerCase())
                }
                makeCountryList(dialog, newList as ArrayList<Country_model>, ctx)
            }
        }
        dialog.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {

            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
                handler.removeCallbacks(input_finish_checker)
            }

            override fun afterTextChanged(editable: Editable) {
                if (editable!!.isNotEmpty()) {
                    last_text_edit = System.currentTimeMillis();
                    handler.postDelayed(input_finish_checker, delay)
                } else {
                    makeCountryList(dialog, countryList, ctx)
                }
            }
        })
        makeCountryList(dialog, countryList, ctx)
        dialog.window!!.setLayout(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        )
        dialog.window!!.setGravity(Gravity.BOTTOM)
        dialog.setCancelable(true)
        dialog.window!!.attributes.windowAnimations = R.style.DialogAnimationslide
        dialog.show()
    }


    fun makeCountryList(dialog: Dialog, countryList: ArrayList<Country_model>, ctx: Context) {
        dialog.llCountry.removeAllViews()
        Thread(Runnable {
            run {
                for (i in 0 until countryList.size) {
                    var countryInfo = countryList[i]
                    var view = LayoutInflater.from(ctx).inflate(R.layout.countrydialog_item, null)
                    view.tvCountryName.text = countryInfo.countryName
                    Handler(Looper.getMainLooper()).post {
                        dialog.llCountry.addView(view)
                    }
                    view.setOnClickListener {
                        getCodeApi(countryInfo.country)
                        dialog.dismiss()
                    }
                }
            }
        }).start()

    }

    private fun getCodeApi(country_code: String) {

        showLoading()

        var rqst = GetCountryCodeRequest(country_code)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.getCountryCode(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })
    }

    private fun getReferCodeApi() {
        showLoading()
        apiServiceWithAuthorization.getReferCode(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })

    }

    private fun inviteAuthApi() {

        showLoading()
        var rqst = ThreeFactorRequest(edt_label.text.toString().trim(),
                edt_invitephone.text.toString().trim(), tv_countrycode.text.toString().trim(), edt_yourlabel.text.toString().trim(), edt_yourphone.text.toString().trim(),
                tv_yourcountrycode.text.toString().trim(), refcode)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.invite_ThreeFactor(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleErrorInvite(error); hideLoading() })
    }

    private fun handleErrorInvite(error: Throwable?) {

        when (error) {
            is HttpException -> {
                when {

                    error.code() == 400 -> {
                        val responseBody = error.response().errorBody()?.string()
                        var message = Gson().fromJson<BaseResponse>(responseBody, BaseResponse::class.java)
                        if (message.message.equals(getString(R.string.requestalready), true)) {
                            showDialog(message.message, false)
                        } else {
                            showToast(message.message)
                        }


                    }

                }
            }
        }
    }

    private fun getUserConatctApi() {
        apiServiceWithAuthorization.getUserContact(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })

    }


    private var tocountrycodeid: Int = 0
    private var fromcountrycodeid: Int = 0

    private fun handleResponse(it: Any?) {

        when (it) {
            is CountryCodeResponse -> {
                hideLoading()
                if (it.status) {
                    if (isinvitecountrycode) {
                        tv_countrycode.text = it.data.countryCode
                        tocountrycodeid = it.data.countryCodeId
                    } else {
                        tv_yourcountrycode.text = it.data.countryCode
                        fromcountrycodeid = it.data.countryCodeId
                    }
                }
            }
            is ReferCodeResponse -> {
                hideLoading()
                if (it.status) {
                    refcode = it.data.refCode
                    getUserConatctApi()
                }
            }

            is InviteResponse -> {
                hideLoading()
                if (it.status) {
                    try {
                        finish()
                    } catch (ex: Exception) {
                        Toast.makeText(applicationContext, getString(R.string.smsfail),
                                Toast.LENGTH_LONG).show()
                        ex.printStackTrace()
                    }

                }
            }
            is UserContactResponse -> {
                if (it.status) {
                    if (it.data.name != null) {
                        edt_yourlabel.setText(it.data.name)
                        edt_yourphone.setText(it.data.mobile)
                        tv_yourcountrycode.text = "+${it.data.countryCode.countryCodeId}"
                    }

                    setdata(refcode, edt_label.text.toString().trim(), edt_yourlabel.text.toString().trim())
                }
            }
        }
    }


    private fun setdata(refCode: String, label: String, yourlabel: String) {
        edt_message.setText("Hi " + label + "\nI am inviting you on " + yourlabel + " JavaWallet Wallet as a Cosigner. Use referral code "
                + refCode + " while logging in.Use https://play.google.com/store/apps/details?id=com.JavaWallet to download the app.")

    }

}
