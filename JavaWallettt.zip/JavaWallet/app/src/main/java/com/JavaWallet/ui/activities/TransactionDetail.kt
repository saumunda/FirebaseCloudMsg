package com.JavaWallet.ui.activities

import android.app.Activity
import android.app.Dialog
import android.app.ProgressDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.support.v4.content.LocalBroadcastManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.TextView
import com.JavaWallet.*
import com.JavaWallet.Utilities.Bytetohex
import com.JavaWallet.Utilities.CryptLib
import com.JavaWallet.networking.*

import com.google.gson.Gson

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_send.*
import kotlinx.android.synthetic.main.activity_transaction_detail.*
import kotlinx.android.synthetic.main.auth_item.view.*
import kotlinx.android.synthetic.main.header_title.*
import kotlinx.android.synthetic.main.logout_dialog.*
import org.bitcoinj.core.*
import org.bitcoinj.crypto.TransactionSignature
import org.bitcoinj.params.MainNetParams
import org.bitcoinj.params.TestNet3Params
import org.bitcoinj.script.Script
import org.bitcoinj.script.ScriptBuilder
import org.bitcoinj.wallet.UnreadableWalletException
import org.web3j.crypto.Credentials
import org.web3j.crypto.RawTransaction
import org.web3j.crypto.TransactionEncoder
import org.web3j.utils.Convert
import org.web3j.utils.Numeric
import retrofit2.HttpException
import java.math.BigDecimal
import java.math.BigInteger
import org.web3j.protocol.Web3j
import org.web3j.protocol.http.HttpService

class TransactionDetail : BaseActivity(), View.OnClickListener {

    private var fee_priority: Int = 0
    private var final_txnFee: Double = 0.0
    private var request_pos: Int = 0
    private var ishowfull: Boolean = false
    var trnx_id = 0
    var coinSymbol = ""
    var trnx_typedetail = ""
    var coin_sym = ""
    var to_address = ""
    var to_amount = 0.0
    private var gas_price: String = "30000000000"
    private var gas_Limit: Double = 21000.0

    var Erc_nonce: Int = 0
    private val WALLETPIN_TRANSACTION: Int = 101
    lateinit var applctn: JavaWallet


    var tx_id = ""

    var token_address = ""
    private var btcFeetosend: Double = 0.0
    private lateinit var localBroadcastManager: LocalBroadcastManager
    private lateinit var getB_Receiver: DetailUpdateBroadcast
    private lateinit var lstFilter: IntentFilter


    var commsionList = ArrayList<CommisionResponseData>()
    //var ContractAddress = "0x5b0Adb5A0f9E8551CB2502A0AD6307faD06121CB"
    var ContractAddress = "0xb061d8806de7a93af7760f1f1499f7faada66496" // java main
    // var ContractAddress = "0xa8f69D25F01285Aa3526F56626C9c08ddC03dD73" // bank test
    var eth_cryptoxy_address = ""
    var eth_antier_address = ""
    var ethpercentage_fee = 0.0
    var ethmin_fee = 0.0
    var btc_cryptoxy_address = ""
    var btc_antier_address = ""
    var btcpercentage_fee = 0.0
    var btcmin_fee = 0.0

    lateinit var contractcommison: Cmsn_solc_Contract
    lateinit var web3j: Web3j
    private var privKey: BigInteger? = null
    private var credentials: Credentials? = null
    var senderaddress = ""

    var errormessage = ""
    private var currentNonce: Int = 0
    var contractTransactionhash = ""
    private var txnFee: Double = 0.0
    var feestoSend = 0.0

    var btcUnspentlist: ArrayList<UnspentResponseLocalData> = ArrayList()
    var jsonutxo = ArrayList<UTXO>()
    var minebalance: Long = 0
    var myvalue = 0
    var myunspentforoutput: Long = 0
    var btctosatoshi = 100000000
    private var outputUsedtomatchValue: Long = 0

    private lateinit var finalfee_ethPrice: String


    inner class DetailUpdateBroadcast : BroadcastReceiver() {

        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ConstantsUtils.updateDetail) {
                getDATA()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transaction_detail)
        tv_title.text = getString(R.string.title_trnsdetail)
        iv_back.setOnClickListener {
            finish()
        }
        iv_notification.visibility = View.GONE
        iv_notification.setOnClickListener {
            startNewActivity(NotificationActivity())
        }

        localBroadcastManager = LocalBroadcastManager.getInstance(mActivity)
        getB_Receiver = DetailUpdateBroadcast()
        lstFilter = IntentFilter(ConstantsUtils.updateDetail)


        try {
            var b: Bundle? = Bundle()
            b = intent.extras
            coinSymbol = b!!.getString("coinSymbol")
            trnx_typedetail = b!!.getString(getString(R.string.t_type))
            trnx_id = b!!.getInt(getString(R.string.t_id))

            if (coinSymbol.equals("btc")) {

                getUnspentBtc()
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
        getCommisonApi()
        if (trnx_typedetail.equals("withdraw", true)) {
            iv_deposit.setImageDrawable(resources.getDrawable(R.drawable.ic_send_arrow))
            iv_deposit.setColorFilter(resources.getColor(R.color.dred));
            tv_deposit.text = getString(R.string.Transfer_title)
        } else {
            iv_deposit.setImageDrawable(resources.getDrawable(R.drawable.ic_deposit_arrow))
            iv_deposit.setColorFilter(resources.getColor(R.color.greenbottom));
            tv_deposit.text = getString(R.string.Deposit_title)
        }
    }

    private fun getUnspentBtc() {

        if (isInternetConnected()) {
            apiServiceWithAuthorization.getUnspent(JavaWallet.mPreferenceDataModal.BTC_ADDRESS)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponseUnspent(it) },
                            { error -> handleError(error); })
        } else {
            showDialog(getString(R.string.network_error), false)

        }
    }

    fun String.hexToByteArray(): ByteArray {
        return ByteArray(this.length / 2) {
            this.substring(it * 2, it * 2 + 2).toInt(16).toByte()
        }
    }

    private fun handleResponseUnspent(itmy: UnspentResponseLocal) {

        var unResponse = itmy.data.filter { it.confirmations >= 1 }
        btcUnspentlist.addAll(unResponse)
        for (i in 0 until btcUnspentlist.size) {
            var script = Script(btcUnspentlist[i].scriptPubKey.hexToByteArray())
            val coin = Coin.parseCoin((btcUnspentlist[i].amount).toString());
            var hashh = Sha256Hash.wrap(btcUnspentlist[i].txid)
            var utxo = UTXO(hashh, btcUnspentlist[i].vout.toLong(), coin,
                    btcUnspentlist[i].height, false, script, btcUnspentlist[i].address)
            if (btcUnspentlist[i].confirmations >= 1) {
                jsonutxo.add(utxo)
                minebalance = minebalance + btcUnspentlist[i].satoshis
            }

        }

    }

    override fun onResume() {
        super.onResume()
        if (isInternetConnected()) {
            if (coin_sym.equals("btc")) {

            }
            getDATA()
        } else {
            showDialog(getString(R.string.network_error), false)
        }

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
        } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
        }
        tv_canceltransaction.setOnClickListener(this)
        tv_viewexporer.setOnClickListener(this)
        localBroadcastManager.registerReceiver(getB_Receiver, lstFilter)
    }

    override fun onPause() {
        super.onPause()
        localBroadcastManager.unregisterReceiver(getB_Receiver)
    }


    override fun onClick(p0: View?) {
        when (p0) {

            tv_canceltransaction -> {
                if (tv_canceltransaction.text.toString().trim().equals(getString(R.string.CancelTransaction))) {
                    showCancelDialog()
                } else {
                    showCancelBroadcastDialog()
                }
            }
            tv_viewexporer -> {
                if (coin_sym.equals(getString(R.string.btc))) {
                    val i = Intent(Intent.ACTION_VIEW)
                    i.data = Uri.parse(getString(R.string.blockstream) + tx_id)

                    startActivity(i)
                } else {
                    val i = Intent(Intent.ACTION_VIEW)
                    i.data = Uri.parse(getString(R.string.etherscan) + tx_id)
                    startActivity(i)
                }
            }
        }
    }

    private fun showCancelDialog() {

        var dialog = Dialog(mActivity)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.logout_dialog)
        dialog.dialog_message.text = getString(R.string.canceltransaction)
        dialog.dialog_no.setOnClickListener { dialog.dismiss() }
        dialog.dialog_yes.setOnClickListener {
            dialog.dismiss()
            cancelBroadcatApi()
        }
        dialog.show()

    }

    private fun showCancelBroadcastDialog() {
        var dialog = Dialog(mActivity)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.logout_dialog)
        dialog.dialog_message.text = getString(R.string.liketodo)
        dialog.dialog_no.text = getString(R.string.Broadcast)
        dialog.dialog_yes.text = getString(R.string.Cancel)
        dialog.dialog_no.setOnClickListener {
            dialog.dismiss()
            startBroadcast()
        }
        dialog.dialog_yes.setOnClickListener {
            dialog.dismiss()
            showCancelDialog()
        }
        dialog.show()

    }

    private fun startBroadcast() {
        if (coin_sym.equals(getString(R.string.btc))) {
            if (to_amount < 0.00005460) {
                showDialog(getString(R.string.minamount), false)
                return
            } else {
                var bndl = Bundle()
                bndl.putBoolean(getString(R.string.isfromSend), false)
                bndl.putBoolean(getString(R.string.isfromsetting), false)
                bndl.putBoolean(getString(R.string.isfromTransaction), true)
                bndl.putBoolean(getString(R.string.isfromImport), false)
                bndl.putBoolean("isfromSwap", false)
                callActivityforResultData(NewPinAfterImport::class.java, WALLETPIN_TRANSACTION, bndl)
            }

        } else {
            var bndl = Bundle()
            bndl.putBoolean(getString(R.string.isfromSend), false)
            bndl.putBoolean(getString(R.string.isfromsetting), false)
            bndl.putBoolean(getString(R.string.isfromTransaction), true)
            bndl.putBoolean(getString(R.string.isfromImport), false)
            bndl.putBoolean("isfromSwap", false)
            callActivityforResultData(NewPinAfterImport::class.java, WALLETPIN_TRANSACTION, bndl)
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == WALLETPIN_TRANSACTION && resultCode == Activity.RESULT_OK) {
            if (coin_sym.equals("btc", true)) {
                gasEstimationApi()
            } else {
                gasEstimationApi()
            }
        }
    }


    private fun getDATA() {
        showLoading()
        var rqst = TransactiondetailsRequest(trnx_id, trnx_typedetail.toLowerCase())
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.getTransactionDetail(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })
    }

    private fun getCommisonApi() {
        apiServiceWithAuthorization.getCommissiondetail(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })

    }

    private fun cancelBroadcatApi() {

        showLoading()
        var rqst = cancelBroadcastRequest(trnx_id)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.deleteTransaction(JavaWallet.mPreferenceDataModal.JWTToken, coin_sym, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })


    }

    private fun gasEstimationApi() {

        var rqst = GasEstimateRequest(to_address, decimalConverterUpto(to_amount, 10))
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.gasEstimation(JavaWallet.mPreferenceDataModal.JWTToken, coin_sym, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error) })

    }

    private fun getNonceApi() {
        showLoading()
        var rqst = GetNonceRequest(to_amount.toString(),false)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.getNonce(JavaWallet.mPreferenceDataModal.JWTToken, coin_sym, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleErrornonce(error);hideLoading() })
    }

    private fun sendCoinApi(nonce: Long, tx_raw: String) {
        showLoading()
        var rqst: sendCoinCosigerRequest
        if (coin_sym.equals(getString(R.string.btc))) {
            rqst = sendCoinCosigerRequest(trnx_id, tx_raw, nonce, btcFeetosend, 0)
        } else {
            rqst = sendCoinCosigerRequest(trnx_id, tx_raw, nonce, gas_Limit, 0)
        }
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.sendCoinbycosign(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })
    }


    private fun eth_Rawtransaction(it: NonceResponse) {
        try {
            /* val privKey = JavaWallet.mPreferenceDataModal.PRIVATE_KEY
             // Web3j
             val credentials = Credentials.create(privKey!!.toString(16))
             val amountWei = Convert.toWei(to_amount.toString(), Convert.Unit.ETHER).toBigInteger()
             //BigInteger nonce, BigInteger gasPrice, BigInteger gasLimit, String to, BigInteger value
             val rawTransaction = RawTransaction.createEtherTransaction(BigInteger.valueOf(it.nonce.toLong()), BigInteger.valueOf(gas_price.toDouble().toLong()),
                     BigInteger.valueOf(gas_Limit.toLong()), to_address, amountWei)
             val signedMessage = TransactionEncoder.signMessage(rawTransaction, credentials)
             val hexValue = Numeric.toHexString(signedMessage)
             sendCoinApi(it.nonce.toLong(), hexValue.substring(2))*/
            val privKey = JavaWallet.mPreferenceDataModal.PRIVATE_KEY
            // Web3j
            val credentials = Credentials.create(privKey!!.toString(16))
            val amountWei = Convert.toWei(to_amount.toString(), Convert.Unit.ETHER).toBigInteger()
            //BigInteger nonce, BigInteger gasPrice, BigInteger gasLimit, String to, BigInteger value
            val rawTransaction =
                    RawTransaction.createEtherTransaction(BigInteger.valueOf(it.nonce.toLong()), BigInteger.valueOf(finalfee_ethPrice.toDouble().toLong()),
                            BigInteger.valueOf(gas_Limit.toLong()), to_address, amountWei)
            val signedMessage = TransactionEncoder.signMessage(rawTransaction, credentials)
            val hexValue = Numeric.toHexString(signedMessage)
            sendCoinApi(it.nonce.toLong(), hexValue.substring(2))
        } catch (e: UnreadableWalletException) {
            e.printStackTrace()
        }

    }

    private fun getRawDataERC(it: NonceResponse) {

        Erc_nonce = it.nonce
        getCoinDetail()
    }

    private fun getCoinDetail() {
        showLoading()
        var rqst = GetuserpayeeRequest(coin_sym.toLowerCase())
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.getCoindetail(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error); hideLoading() })

    }

    private fun ERC_Rawtransaction(data_raw: String) {

        try {
            val privKey = JavaWallet.mPreferenceDataModal.ETHPRIVATE_KEY
            // Web3j
            val credentials = Credentials.create(privKey!!.toString(16))
            //BigInteger nonce, BigInteger gasPrice, BigInteger gasLimit, String to,
            //            BigInteger value, String data
            val rawTransaction = RawTransaction.createTransaction(BigInteger.valueOf(Erc_nonce.toLong()),
                    BigInteger.valueOf(finalfee_ethPrice.toDouble().toLong()),
                    BigInteger.valueOf(gas_Limit.toLong()), token_address, data_raw)
            val signedMessage = TransactionEncoder.signMessage(rawTransaction, credentials)
            val hexValue = Numeric.toHexString(signedMessage)
            sendCoinApi(Erc_nonce.toLong(), hexValue.substring(2))

        } catch (e: UnreadableWalletException) {
            e.printStackTrace()
        }

    }


    private fun handleResponse(it: Any) {
        when (it) {
            is TransactionDetailResponse -> {
                hideLoading()
                if (it.status) {

                    tx_id = it.data[0].tx_id
                    fee_priority = it.data[0].fee_priority
                    coin_sym = it.data.get(0).coinSymbol
                    to_amount = it.data.get(0).amount
                    to_address = it.data.get(0).toAdrs

                    if (!coin_sym.equals("btc", true)) {
                        if (it.data[0].gas_limit.toInt() != 0) {
                            gas_price = decimalConverterUpto(it.data[0].gas_price, 8)
                            gas_Limit = it.data[0].gas_limit.toDouble()
                        }
                    } else {
                        gas_price = decimalConverterUpto(it.data[0].gas_price, 8)
                        gas_Limit = it.data[0].gas_limit.toDouble()
                    }

                    tv_time.text = convertUTCtoDeviceZone(it.data.get(0).createdAt, "dd MMM, yyyy ' | 'hh:mm a")
                    tv_amount.text = decimalConverterUpto(it.data.get(0).amount.toDouble(), 9) + " " + it.data.get(0).coinSymbol.toUpperCase()
                    tv_from.text = it.data.get(0).fromAdrs
                    tv_to.text = it.data.get(0).toAdrs
                    var status = it.data.get(0).status
                    var blockchain_status = it.data.get(0).blockchainStatus
                    if (trnx_typedetail.toLowerCase().equals("withdraw")) {
                        if (it.data.get(0).status.equals("pending", true) || it.data.get(0).status.equals("approved", true)) {
                            for (i in 0 until it.data[0].auths.size) {
                                if (it.data[0].auths[i].signStatus == 1 && it.data[0].status.equals("approved", true)) {
                                    ishowfull = true
                                    break
                                }
                            }
                            if (ishowfull) {
                                tv_canceltransaction.text = getString(R.string.cancelBroadcastTransaction)
                                tv_canceltransaction.visibility = View.VISIBLE
                                tv_viewexporer.visibility = View.GONE
                            } else {
                                tv_canceltransaction.text = getString(R.string.CancelTransaction)
                                tv_canceltransaction.visibility = View.VISIBLE
                                tv_viewexporer.visibility = View.GONE
                            }
                        } else {
                            if(tx_id==null){
                                tv_canceltransaction.visibility = View.GONE
                                tv_viewexporer.visibility = View.GONE
                            }else{
                                tv_canceltransaction.visibility = View.GONE
                                tv_viewexporer.visibility = View.VISIBLE
                            }

                        }
                    } else {

                        if(tx_id==null){
                            tv_canceltransaction.visibility = View.GONE
                            tv_viewexporer.visibility = View.GONE
                        }else{
                            tv_canceltransaction.visibility = View.GONE
                            tv_viewexporer.visibility = View.VISIBLE
                        }


                    }

                    if (status.equals("pending", true)) {
                        tv_status.text = getString(R.string.Pending)
                        tv_status.setTextColor(resources.getColor(R.color.orange_progress))
                        iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_in_progress))
                    } else if (status.equals("approved", true)) {
                        tv_status.text = getString(R.string.broadcast)
                        tv_status.setTextColor(resources.getColor(R.color.orange_progress))
                        iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_in_progress))
                    } else if (status.equals("complete", true) || status.equals("signed", true) || status.equals("unconfirmed", true)) {

                        if (blockchain_status == null) {
                            if (trnx_typedetail.equals("withdraw", true) && blockchain_status == null) {
                                if (status.equals("complete", true)) {
                                    tv_status.text = getString(R.string.inProgress)
                                    tv_status.setTextColor(resources.getColor(R.color.orange_progress))
                                    iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_in_progress))

                                } else if (status.equals("signed", true) && blockchain_status == null) {
                                    tv_status.text = getString(R.string.inProgress)
                                    tv_status.setTextColor(resources.getColor(R.color.orange_progress))
                                    iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_in_progress))
                                } else {
                                    tv_status.text = getString(R.string.complete)
                                    tv_status.setTextColor(resources.getColor(R.color.greenbottom))
                                    iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_compeleted))
                                }
                            } else if (trnx_typedetail.equals("deposit", true)) {
                                if (status.equals("complete", true)) {
                                    tv_status.text = getString(R.string.complete)
                                    tv_status.setTextColor(resources.getColor(R.color.greenbottom))
                                    iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_compeleted))
                                } else {
                                    tv_status.text = getString(R.string.inProgress)
                                    tv_status.setTextColor(resources.getColor(R.color.orange_progress))
                                    iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_in_progress))
                                }

                            } else {
                                tv_status.text = getString(R.string.inProgress)
                                tv_status.setTextColor(resources.getColor(R.color.orange_progress))
                                iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_in_progress))
                            }
                        } else {
                            if (blockchain_status.equals("confirmed", true)) {
                                tv_status.text = getString(R.string.complete)
                                tv_status.setTextColor(resources.getColor(R.color.greenbottom))
                                iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_compeleted))
                            } else {

                                if (trnx_typedetail.equals("withdraw", true)) {
                                    if (status.equals("complete", true)) {
                                        tv_status.text = getString(R.string.complete)
                                        tv_status.setTextColor(resources.getColor(R.color.greenbottom))
                                        iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_compeleted))
                                    } else {
                                        tv_status.text = getString(R.string.inProgress)
                                        tv_status.setTextColor(resources.getColor(R.color.orange_progress))
                                        iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_in_progress))
                                    }
                                } else if (trnx_typedetail.equals("deposit", true)) {
                                    if (status.equals("complete", true)) {
                                        tv_status.text = getString(R.string.complete)
                                        tv_status.setTextColor(resources.getColor(R.color.greenbottom))
                                        iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_compeleted))
                                    } else {
                                        tv_status.text = getString(R.string.inProgress)
                                        tv_status.setTextColor(resources.getColor(R.color.orange_progress))
                                        iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_in_progress))
                                    }
                                } else {
                                    tv_status.text = getString(R.string.inProgress)
                                    tv_status.setTextColor(resources.getColor(R.color.orange_progress))
                                    iv_status.setImageDrawable(resources.getDrawable(R.drawable.ic_in_progress))
                                }
                            }
                        }


                    } else if (status.equals("confirmed", true)) {

                    } else {
                        tv_status.text = getString(R.string.failed)
                        tv_status.setTextColor(resources.getColor(R.color.red))
                        iv_status.setImageDrawable(resources.getDrawable(R.drawable.cross_fialed))

                    }
                    if (it.data[0].auths == null) {
                        tv_authstatus.text = getString(R.string.noAUTHENTICATION)
                    } else {
                        if (it.data[0].auths.size > 0) {
                            lnr_auth.removeAllViews()
                            tv_authstatus.text = getString(R.string.aSTATUS)
                            for (i in 0 until it.data[0].auths.size) {
                                var authInfo = it.data[0].auths[i]
                                var view = LayoutInflater.from(mActivity).inflate(R.layout.auth_item, null)
                                view.tv_transaction_name.text = authInfo.label
                                if (authInfo.signStatus == 0) {
                                    view.tv_transaction_status.text = getString(R.string.waiting)
                                    view.tv_transaction_mode.visibility = View.VISIBLE
                                    view.tv_transaction_status.setTextColor(resources.getColor(R.color.orange_progress))
                                    view.iv_transaction_status.setImageDrawable(resources.getDrawable(R.drawable.ic_in_progress))
                                } else if (authInfo.signStatus == 1) {
                                    view.tv_transaction_status.text = getString(R.string.complete)
                                    view.tv_transaction_mode.visibility = View.GONE
                                    view.tv_transaction_status.setTextColor(resources.getColor(R.color.greenbottom))
                                    view.iv_transaction_status.setImageDrawable(resources.getDrawable(R.drawable.ic_compeleted))
                                } else if (authInfo.signStatus == 2) {
                                    view.tv_transaction_status.text = getString(R.string.declined)
                                    view.tv_transaction_mode.visibility = View.GONE
                                    view.tv_transaction_status.setTextColor(resources.getColor(R.color.red))
                                    view.iv_transaction_status.setImageDrawable(resources.getDrawable(R.drawable.cross_fialed))
                                }
                                view.tv_transaction_mode.setOnClickListener {
                                    showLoading()
                                    var rqst = RequestAgainRequest(authInfo.cosignerUserId, trnx_id)
                                    val plainText = Gson().toJson(rqst)
                                    val cryptLib = CryptLib()
                                    val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
                                    apiServiceWithAuthorization.requestAgain(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                                            .subscribeOn(Schedulers.io())
                                            .observeOn(AndroidSchedulers.mainThread())
                                            .subscribe({ println(it);handleResponse(it) },
                                                    { error -> handleError(error); hideLoading() })


                                }
                                lnr_auth.addView(view)
                            }
                        } else {
                            tv_authstatus.text = getString(R.string.noAUTHENTICATION)
                        }
                    }
                }
            }

            is GasResponse -> {
                if (it.status) {

                    if (coin_sym.equals(getString(R.string.btc), true)) {


                        final_txnFee = decimalConverterUpto(gas_price.toDouble(), 10).toDouble() + to_amount


                        var commison_fees = decimalConverterUpto((to_amount * (btcpercentage_fee / 100)), 12)
                        if (decimalConverterUpto(commison_fees.toDouble(), 12) > btcmin_fee.toString()) {
                            feestoSend = commison_fees.toDouble()
                        } else {
                            feestoSend = btcmin_fee
                        }

                        showTxnDialog(to_amount + feestoSend, feestoSend, to_amount)


                    } else if (coin_sym.equals("eth")) {
                        var commison_fees = to_amount * (ethpercentage_fee / 100)
                        if (decimalConverterUpto(commison_fees, 8) > ethmin_fee.toString()) {
                            feestoSend = commison_fees
                        } else {
                            feestoSend = ethmin_fee
                        }
//                          final_txnFee = txnFee + to_amount
//                          showTxnDialog(final_txnFee + feestoSend, feestoSend, to_amount)
                        var vl = gas_price.toDouble() / gas_Limit
                        finalfee_ethPrice = decimalConverterUpto(vl * 1000000000000000000, 8)

                        final_txnFee = gas_price.toDouble() + to_amount

                        showTxnDialog(final_txnFee + to_amount, feestoSend, to_amount)


                    } else {
                        /*final_txnFee = txnFee
                        showTxnDialog(final_txnFee, 0.0, 0.0)*/
                        var vl = gas_price.toDouble() / gas_Limit
                        finalfee_ethPrice = decimalConverterUpto(vl * 1000000000000000000, 8)
                        var gasFeeMultiplier = 0.000000000000000001
                        var initialValue = gas_price.toDouble() * gas_Limit
                        var txnFee = decimalConverterUpto(finalfee_ethPrice.toDouble() * gasFeeMultiplier, 8)
                        final_txnFee = txnFee.toDouble()
                    }
                    //showTxnDialog(final_txnFee)

                } else {
                    showToast(getString(R.string.notvalid))
                }
            }

            is SendBtcResponse -> {
                hideLoading()
                if (it.status) {
                    showDialog(it.message, true)
                } else {
                    showDialog(it.message, false)
                }
            }


            is NonceResponse -> {
                hideLoading()
                if (it.status) {

                    if (coin_sym.equals("eth", true)) {
                        // eth_Rawtransaction(it)
                        Commision(to_address).execute()
                    } else if (coin_sym.equals("btc", true)) {
                        // sendBtcRaw()
                        //btc_Rawtransaction()
                        getFeesAndUnspent()
                    } else {
                        getRawDataERC(it)
                    }

                }
            }
            is SendResponse -> {
                hideLoading()

                if (it.status) {
                    showDialog(it.message, true)
                } else {
                    showDialog(it.message, false)
                }
            }
            is ErcDataResponse -> {
                hideLoading()
                if (it.status) {
                    ERC_Rawtransaction(it.data)
                }

            }
            is BaseResponse -> {
                hideLoading()
                if (it.status) {
                    showDialog(getString(R.string.Transactioncancelledsuccessfully), true)
                }

            }
            is BaseResponsenew -> {
                hideLoading()
                if (it.status) {
                    showDialog(getString(R.string.resentsuccessfully), false)
                } else {
                    showDialog(getString(R.string.wrong), false)
                }

            }

            is CoinDetailResponse -> {
                hideLoading()
                token_address = it.data.tokenAddress
                val amountWei = to_amount.toString().toDouble() * it.data.decimals
                if (to_amount.toString().contains(".")) {
                    var number = to_amount.toString()
                    number = number.substring(number.indexOf(".")).substring(1)
                    if (number.length > it.data.decimals.toString().length) {
                        showDialog(getString(R.string.decimalsvaluemore) + it.data.decimals, false)
                    } else {
                        showLoading()
                        var rqst = GetERCDataRequest(JavaWallet.mPreferenceDataModal.COIN_ADDRESS, to_address.trim(),
                                coin_sym.toLowerCase(), BigDecimal(amountWei).toBigInteger().toString())
                        val plainText = Gson().toJson(rqst)
                        val cryptLib = CryptLib()
                        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
                        apiServiceWithAuthorization.getERCDATA(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                                .subscribeOn(Schedulers.io())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe({ println(it);handleResponse(it) },
                                        { error -> handleError(error); hideLoading() })
                    }

                } else {
                    showLoading()
                    var rqst = GetERCDataRequest(JavaWallet.mPreferenceDataModal.COIN_ADDRESS, to_address.trim(),
                            coin_sym.toLowerCase(), BigDecimal(amountWei).toBigInteger().toString())
                    val plainText = Gson().toJson(rqst)
                    val cryptLib = CryptLib()
                    val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
                    apiServiceWithAuthorization.getERCDATA(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                            .subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe({ println(it);handleResponse(it) },
                                    { error -> handleError(error); hideLoading() })
                }


            }

            is CommisionResponse -> {
                commsionList = it.data
                for (i in 0 until commsionList.size) {
                    if (commsionList[i].coinSymbol.equals("btc")) {
                        btc_cryptoxy_address = commsionList[i].address
                        btcmin_fee = commsionList[i].minFee
                        btcpercentage_fee = commsionList[i].percentageFee
                    } else if (commsionList[i].coinSymbol.equals("eth")) {
                        eth_cryptoxy_address = commsionList[i].address
                        ethmin_fee = commsionList[i].minFee
                        ethpercentage_fee = commsionList[i].percentageFee
                    }
                }

            }

            is sendContractResponse -> {
                hideLoading()
                showDialog(it.message, true)
            }

        }
    }
    lateinit var keyk: ECKey
    lateinit var tx: Transaction
    lateinit var addressmine: Address
    lateinit var commision_address: Address
    lateinit var address2: Address
    lateinit var scriptPubKey: Script
    private fun getFeesAndUnspent() {

        try {
            showLoading()
            if(JavaWallet.is_MainNet){
                org.bitcoinj.core.Context.getOrCreate(MainNetParams.get());
                val dumpedPrivateKey = DumpedPrivateKey.fromBase58(MainNetParams.get(), JavaWallet.mPreferenceDataModal.PRIVATE_KEYBTC);
                  keyk = dumpedPrivateKey.getKey();
                //String to an address
                  address2 = Address.fromString(MainNetParams.get(), to_address);
                  addressmine = Address.fromString(MainNetParams.get(), JavaWallet.mPreferenceDataModal.BTC_ADDRESS);
                  commision_address= Address.fromString(MainNetParams.get(), btc_cryptoxy_address);
                    tx = Transaction(MainNetParams.get());
            }else{
                org.bitcoinj.core.Context.getOrCreate(TestNet3Params.get());
                val dumpedPrivateKey = DumpedPrivateKey.fromBase58(TestNet3Params.get(), JavaWallet.mPreferenceDataModal.PRIVATE_KEYBTC);
                  keyk = dumpedPrivateKey.getKey();
                //String to an address
                  address2 = Address.fromString(TestNet3Params.get(), to_address);
                  addressmine = Address.fromString(TestNet3Params.get(), JavaWallet.mPreferenceDataModal.BTC_ADDRESS);
                  commision_address= Address.fromString(TestNet3Params.get(), btc_cryptoxy_address);
                  tx = Transaction(TestNet3Params.get());
            }



            //value is a sum of all inputs, fee is 4013
            var btcfees = (gas_price.toDouble() * btctosatoshi).toLong()
            var amount = (to_amount * btctosatoshi).toLong()
            var btc_commisionamount= (feestoSend.toDouble() * btctosatoshi).toLong()
            var amounttobesentFromunspent = amount + btcfees + btc_commisionamount
            if (minebalance >= amounttobesentFromunspent) {
                if (btcUnspentlist[myvalue].satoshis.toLong() == amounttobesentFromunspent) {
                    tx.addOutput(Coin.valueOf(amount), address2);
                    tx.addOutput(Coin.valueOf(btc_commisionamount), commision_address)
                } else if (btcUnspentlist[myvalue].satoshis.toLong() > amounttobesentFromunspent) {
                    tx.addOutput(Coin.valueOf(amount), address2);
                    tx.addOutput(Coin.valueOf(btcUnspentlist[myvalue].satoshis.toLong() - (amount + btcfees)), addressmine);
                    tx.addOutput(Coin.valueOf(btc_commisionamount), commision_address)
                } else if (btcUnspentlist[myvalue].satoshis.toLong() < amounttobesentFromunspent) {
                    txCaculation(tx, amounttobesentFromunspent, btcUnspentlist[myvalue].satoshis.toLong(), address2, addressmine, btcUnspentlist,
                            amount,btc_commisionamount,commision_address)
                }
                for (utxo in jsonutxo) {
                    if (amounttobesentFromunspent > outputUsedtomatchValue) {
                        if(JavaWallet.is_MainNet){
                            val outPoint = TransactionOutPoint(MainNetParams.get(), utxo.index, utxo.hash)
                            tx.addSignedInput(outPoint, utxo.getScript(), keyk, Transaction.SigHash.ALL, true)
                            outputUsedtomatchValue = outputUsedtomatchValue + utxo.value.value
                        }else{
                            val outPoint = TransactionOutPoint(TestNet3Params.get(), utxo.index, utxo.hash)
                            tx.addSignedInput(outPoint, utxo.getScript(), keyk, Transaction.SigHash.ALL, true)
                            outputUsedtomatchValue = outputUsedtomatchValue + utxo.value.value
                        }

                    }

                }

                for (i in 0 until tx.inputs.size) {
                    val transactionInput: TransactionInput = tx.getInput(i.toLong())
                    val addressFromUtxo: String = jsonutxo[i].getAddress()
                    if(JavaWallet.is_MainNet){
                        scriptPubKey = ScriptBuilder.createOutputScript(Address.fromString(MainNetParams.get(), jsonutxo[i].getAddress()))
                    }else{
                        scriptPubKey = ScriptBuilder.createOutputScript(Address.fromString(TestNet3Params.get(), jsonutxo[i].getAddress()))
                    }

                    val hash: Sha256Hash = tx.hashForSignature(i, scriptPubKey, Transaction.SigHash.ALL, false)
                    val ecSig = keyk.sign(hash)
                    val txSig = TransactionSignature(ecSig, Transaction.SigHash.ALL, false)
                    transactionInput.scriptSig = ScriptBuilder.createInputScript(txSig, keyk)
                }
                tx.getConfidence().setSource(TransactionConfidence.Source.SELF);
                tx.setPurpose(Transaction.Purpose.USER_PAYMENT);
                var rawtrnsactn = Bytetohex.ByteArrayToHexString(tx.bitcoinSerialize())
                System.out.println(rawtrnsactn);
                System.out.println(tx.getHashAsString());
                hideLoading()
                  sendCoinApi(1, rawtrnsactn)


            } else {
                hideLoading()
                showDialog("Insufficient fund", false)
                System.out.println("Insufficient fund");
            }
        } catch (e: Exception) {
            hideLoading()
        }

    }

    private fun txCaculation(tx: Transaction, amounttobesentFromunspent: Long, myUnspentBalance: Long, addresSend: Address,
                             addressmine: Address, outputjson: ArrayList<UnspentResponseLocalData>, amount: Long
                             ,commision_amount: Long, commision_addresSend: Address) {

        if (myUnspentBalance == amounttobesentFromunspent) {
            tx.addOutput(Coin.valueOf(amount), addresSend);
            tx.addOutput(Coin.valueOf(commision_amount), commision_addresSend);
        } else if (myUnspentBalance > amounttobesentFromunspent) {
            tx.addOutput(Coin.valueOf(amount), addresSend);
            tx.addOutput(Coin.valueOf(myUnspentBalance - (amounttobesentFromunspent)), addressmine);
            tx.addOutput(Coin.valueOf(commision_amount), commision_addresSend);
        } else if (myUnspentBalance < amounttobesentFromunspent) {
            myunspentforoutput = myUnspentBalance
            if (myunspentforoutput == amounttobesentFromunspent) {
                tx.addOutput(Coin.valueOf(amount), addresSend);
                tx.addOutput(Coin.valueOf(commision_amount), commision_addresSend);
            } else if (myunspentforoutput > amounttobesentFromunspent) {
                tx.addOutput(Coin.valueOf(amount), addresSend);
                tx.addOutput(Coin.valueOf(myunspentforoutput - (amounttobesentFromunspent)), addressmine);
                tx.addOutput(Coin.valueOf(commision_amount), commision_addresSend);
            } else if (myunspentforoutput < amounttobesentFromunspent) {
                myvalue++
                myunspentforoutput = myunspentforoutput + outputjson[myvalue].satoshis.toLong()
                txCaculation(tx, amounttobesentFromunspent, myunspentforoutput, addresSend, addressmine, outputjson, amount,commision_amount,commision_addresSend)
            }
        }
    }

    private fun handleErrornonce(error: Throwable?) {
        when (error) {
            is HttpException -> {
                when {
                    error.code() == 400 -> {
                        val responseBody = error.response().errorBody()?.string()
                        var message = Gson().fromJson<NonceErrorResponse>(responseBody, NonceErrorResponse::class.java)
                        showDialog(message.message, false)
                    }
                    else -> {
                        val responseBody = error.response().errorBody()?.string()
                        var message = Gson().fromJson<NonceErrorResponse>(responseBody, NonceErrorResponse::class.java)
                        showDialog(message.message, false)
                    }
                }
            }
        }
    }

    //, commissionFees: Double, Amount: Double
    private fun showTxnDialog(final_txnFeed: Double, commissionFees: Double, Amount: Double) {
        var dialog = Dialog(mActivity)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.logout_dialog)
        val dialog_no = dialog.findViewById<View>(R.id.dialog_no) as TextView
        val dialog_yes = dialog.findViewById<View>(R.id.dialog_yes) as TextView
        val dialog_message = dialog.findViewById<View>(R.id.dialog_message) as TextView

        if (coin_sym.equals("eth")) {
            dialog_message.text = getString(R.string.estimatedincludingGasFee) + " " + decimalConverterUpto(final_txnFeed, 8) + " " + coin_sym.toUpperCase() + "\nAmount to be sent: " +
                    decimalConverterUpto(Amount, 8) + " " + coin_sym.toUpperCase() + "\nGas fee: " +
                    decimalConverterUpto(final_txnFee.toDouble(), 10) + " " + coin_sym.toUpperCase() + "\nJavaWallet Commission: " + decimalConverterUpto(commissionFees, 12) + " " +
                    coin_sym.toUpperCase() + "\nDo you want to continue?"
        } else if (coin_sym.equals("btc")) {




            dialog_message.text = "Estimated Withdrawl amount including Transaction Fee: " + decimalConverterUpto(final_txnFeed, 8) + " " + coin_sym.toUpperCase() + "\nAmount to be sent: " +
                    decimalConverterUpto(to_amount, 8) + " " + coin_sym.toUpperCase() + "\nTransaction fee: " +
                    decimalConverterUpto(commissionFees.toDouble(), 10)  + " " + coin_sym.toUpperCase() + "\nJavaWallet Commission: " +
                    decimalConverterUpto(commissionFees, 8) + " " + coin_sym.toUpperCase() + "\n" + getString(R.string.continueuu)


        } else {
            dialog_message.text = getString(R.string.estimatedGasFee) + decimalConverterUpto(final_txnFee, 8) + getString(R.string.ethCptl) + "\n" + getString(R.string.continueuu)

        }


        dialog_no.setOnClickListener { dialog.dismiss() }
        dialog_yes.setOnClickListener {
            var blnc = 0.0
            if (coin_sym.equals(getString(R.string.btc), true)) {
                blnc = JavaWallet.mPreferenceDataModal.BTC_BALANCE
            } else {
                blnc = JavaWallet.mPreferenceDataModal.ETH_BALANCE
            }
            if (blnc < final_txnFee) {
                showDialog(getString(R.string.lowbalance), false)
            } else {
                myvalue=0
                outputUsedtomatchValue=0
                myunspentforoutput=0
                getNonceApi()
            }
            dialog.dismiss()
        }
        dialog.show()
    }

    private var hitapi = false

    private inner class Commision(address: String) : AsyncTask<String, String, String>() {


        init {
            senderaddress = address
        }

        override fun doInBackground(vararg urls: String): String? {
            showLoading()
            hitapi = true
            try {
                  web3j = Web3j.build(HttpService("https://mainnet.infura.io/v3/ec3e001e25614013b9e1b6ffec3d61b1"))
                // web3j = Web3j.build(HttpService("https://mainnet.infura.io/v3/af08f92cb0064554a28996fc361619e7"))
                privKey = JavaWallet.mPreferenceDataModal.ETHPRIVATE_KEY
                credentials = Credentials.create(privKey!!.toString(16))
                Log.i("contractcommison", "commison Smart contract loading...")
                contractcommison = Cmsn_solc_Contract.load(ContractAddress,
                        web3j, credentials, BigInteger.valueOf(finalfee_ethPrice.toDouble().toLong()),
                        BigInteger.valueOf(gas_Limit.toLong()))
                Log.i("contractcommison", "Smart contract addres " + contractcommison.getContractAddress())

                /* var commison_fees_crypto = decimalConverterUpto(((feestoSend * 85) / 100), 8)
                 var commison_fees_antr = decimalConverterUpto(((feestoSend * 15) / 100), 8)
 */
                val value = Convert.toWei((to_amount + feestoSend).toString(), Convert.Unit.ETHER).toBigInteger()
                Log.i("contractcommison", "valueeeee contract : " + value)
                val receipt = contractcommison.multipleOutputs(senderaddress, eth_cryptoxy_address,
                        Convert.toWei(to_amount.toString(), Convert.Unit.ETHER).toBigInteger(),
                        Convert.toWei(feestoSend.toString(), Convert.Unit.ETHER).toBigInteger(), value).send()

                hideLoading()
                contractTransactionhash = receipt.getTransactionHash()
                Log.i("contractcommison", "Smart contract after: " + contractcommison.getContractAddress())
                Log.i("contractcommison", "Smart contract hash: " + receipt.getTransactionHash())


            } catch (e: Exception) {
                hideLoading()
                hitapi = false
                e.printStackTrace()
                errormessage = e.message!!
            }

            return contractTransactionhash
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if (hitapi) {
                sendCoinContract()
            } else {
                if (!errormessage.equals("")) {
                    showDialog(errormessage, false)
                }

            }

        }

    }

    private fun sendCoinContract() {
        showLoading()
        var rqst = afterSendRequest(contractTransactionhash, JavaWallet.mPreferenceDataModal.COIN_ADDRESS, ContractAddress, to_amount, currentNonce,
                JavaWallet.mPreferenceDataModal.GASLIMIT.toLong(), JavaWallet.mPreferenceDataModal.GASPRICE.toLong(), "complete", trnx_id)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)
        apiServiceWithAuthorization.sendContract(JavaWallet.mPreferenceDataModal.JWTToken, "eth", cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }


    private fun sendHashApicosigner(transactionHash: String) {
        showLoading()
        var rqst = updatetrxRequest(trnx_id, transactionHash)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        apiServiceWithAuthorization.updatetrnxidaftercosignerauth(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> handleError(error);hideLoading() })

    }


}
