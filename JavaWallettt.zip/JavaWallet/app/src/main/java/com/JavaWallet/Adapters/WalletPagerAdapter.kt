package com.JavaWallet.Adapters

import android.content.Context
import android.support.v4.view.PagerAdapter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.JavaWallet.BaseActivity
import com.JavaWallet.JavaWallet
import com.JavaWallet.R
import kotlinx.android.synthetic.main.wallet_pager_two.view.*

class WalletPagerAdapter(mContext: Context, private val isshow: Boolean, private var total_val: Double) : PagerAdapter() {
    private var layoutInflater: LayoutInflater? = null


    init {
       Companion.mContext = mContext
    }

    companion object {
        lateinit var mContext: Context
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        layoutInflater =Companion.mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        var resId = -1
        //Getting my layout's in my adapter. two layouts defined.
        if (isshow) {
            when (position) {0 -> resId = R.layout.wallet_pager_one
                1 -> resId = R.layout.wallet_pager_two
            }
        } else {
            when (1) {1 -> resId = R.layout.wallet_pager_two
            }
        }
        val view = layoutInflater!!.inflate(resId, container, false)
        container.addView(view)
         //total = view.tv_total
        try{
            view.tv_total.text ="= "+ (mContext as BaseActivity).decimalConverterUpto(total_val,2)  + " " + JavaWallet.mPreferenceDataModal.DefaultCurrency

        }catch (e:Exception){
            e.printStackTrace()
        }

        return view
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun getCount(): Int {
        if (isshow) {
            return 2
        } else {
            return 1
        }
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        val view = `object` as View
        container.removeView(view)
    }

    override fun getItemPosition(`object`: Any): Int {
        return POSITION_NONE
    }

    fun showdata(total_val :Double) {
        this.total_val=total_val
        notifyDataSetChanged()
    }
}/*qcreatewalletround_dark*/