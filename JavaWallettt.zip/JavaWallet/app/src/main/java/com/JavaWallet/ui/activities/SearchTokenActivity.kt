package com.JavaWallet.ui.activities

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import com.JavaWallet.Adapters.Addnewtokenadapter
import com.JavaWallet.BaseActivity
import com.JavaWallet.R
import com.JavaWallet.Utility
import com.JavaWallet.networking.SearchTokenResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_search_token.*
import kotlinx.android.synthetic.main.header_title.*

class SearchTokenActivity : BaseActivity() ,Addnewtokenadapter.Listener {


    private lateinit var adapter: Addnewtokenadapter
    lateinit var tokenlist: ArrayList<SearchTokenResponse>

    var delay: Long = 800 // 1 seconds after user stops typing
    var last_text_edit: Long = 0
    var handler_ = Handler()
    private var isthemeDark: Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_token)
        tv_title.text = getString(R.string.SearchToken)
        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
        rcycl_searchtoken.layoutManager = layoutManager
        iv_back.setOnClickListener {
            finish()
        }

        if (Utility.getTheme(mActivity).equals(THEME_DARK)) {
            iv_back.setColorFilter(resources.getColor(R.color.white));
         } else if (Utility.getTheme(mActivity).equals(THEME_LIGHT)) {
            iv_back.setColorFilter(resources.getColor(R.color.Primary_text_colorwhite_Lighttheme));
         } else {
            iv_back.setColorFilter(resources.getColor(R.color.white));
         }

        edt_searchtoken.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {

                if (p0!!.isNotEmpty()) {
                    last_text_edit = System.currentTimeMillis();
                    handler_.postDelayed(input_finish_checker, delay);
                } else {
                    hitApi()
                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                handler_.removeCallbacks(input_finish_checker)
            }

        })
    }

    private fun hitApi() {
        if (isInternetConnected()) {
            getSearchtoken(edt_searchtoken.text.toString().trim())
        } else {
            showDialog(getString(R.string.network_error), false)
        }

    }

    private fun getSearchtoken(word: String) {
            showLoading()
            apiInterfaceWithAuthorization_Token.getSearchToken(word)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ println(it);handleResponse(it) },
                            { error -> handleError(error);hideLoading() })

    }

    private fun handleResponse(it: ArrayList<SearchTokenResponse>) {
        hideLoading()
        tokenlist = it
        if(tokenlist.size>0){
            tvno_token.visibility= View.GONE
            adapter = Addnewtokenadapter(tokenlist, this)
            rcycl_searchtoken.adapter = adapter
        }else{
            tokenlist.clear()
            adapter.notifyDataSetChanged()
            tvno_token.visibility= View.VISIBLE
        }

    }

    private val input_finish_checker = Runnable {
        if (System.currentTimeMillis() > last_text_edit + delay - 500) {
            hitApi()
        }
    }

    override fun onItemClick(position: Int) {
        var data = intent
        data.putExtra(getString(R.string.smartContracrAddess), tokenlist[position].contractAddressHash)
        setResult(Activity.RESULT_OK, data)
        finish()
    }
}
