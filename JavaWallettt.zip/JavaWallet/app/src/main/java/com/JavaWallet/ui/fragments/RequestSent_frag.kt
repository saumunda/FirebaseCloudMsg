package com.JavaWallet.ui.fragments

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.CompoundButton
import android.widget.TextView
import com.JavaWallet.JavaWallet
import com.JavaWallet.networking.*
import com.JavaWallet.ui.activities.Invite_Authenticator
import com.JavaWallet.ui.activities.SetLimit
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.logout_dialog.*
import kotlinx.android.synthetic.main.requestsent_frag.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import java.text.ParseException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.JavaWallet.Adapters.RequsetSent_Adapter
import com.JavaWallet.BaseFragment
import com.JavaWallet.R
import com.JavaWallet.Utilities.CryptLib


class RequestSent_frag : BaseFragment(), View.OnClickListener, RequsetSent_Adapter.InviteListner {

    private var yourlabel: String = ""
    private lateinit var linearLayoutManager: LinearLayoutManager
    private var list_pos: Int = 0
    lateinit var userlist: ArrayList<SentAuthReq>
    var userlistinvite: ArrayList<SentAuthReq> = ArrayList()
    private lateinit var adaptr: RequsetSent_Adapter

    var isonActivityrslt: Boolean = false
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(com.JavaWallet.R.layout.requestsent_frag, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view!!, savedInstanceState)

    }

    override fun onResume() {
        super.onResume()
        onclick()
        linearLayoutManager = LinearLayoutManager(mActivity)
        rcycl_sentrequests.layoutManager = linearLayoutManager
        switch_factor.isEnabled = false
        rltv_invite.isEnabled = false
        tv_setlimit.isEnabled = false
        mActivity.showLoading()

        if (mActivity.isInternetConnected()) {
            getData()
        } else {
            mActivity.showDialog(getString(com.JavaWallet.R.string.network_error), false)
        }


        switch_factor.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { compoundButton, isChecked ->
            if (compoundButton.isPressed) {
                if (userlist.size > 0) {
                    show24hourDialog()
                } else {
                    if (isChecked) {
                        onOffAuthenticatorApi(1)
                    } else {
                        onOffAuthenticatorApi(0)

                    }
                }

            }

        })


    }

    private fun show24hourDialog() {

        var dialog = Dialog(mActivity)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(com.JavaWallet.R.layout.logout_dialog)
        val dialog_no = dialog.findViewById<View>(com.JavaWallet.R.id.dialog_no) as TextView
        val dialog_yes = dialog.findViewById<View>(com.JavaWallet.R.id.dialog_yes) as TextView

        dialog.dialog_message.text = "It will take 24 hours to switch off three factor authentication." + "\n" + getString(R.string.continueuu)
        dialog_no.setOnClickListener {
            switch_factor.isChecked = true
            dialog.dismiss()
        }
        dialog_yes.setOnClickListener {
            dialog.dismiss()
            onOffAuthenticatorApi(2)
        }
        dialog.show()
    }


    private fun getData() {

        mActivity.apiServiceWithAuthorization.sentthreefactorauthreq(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error) })

    }

    private fun inviteAgainApi(userlist: ArrayList<SentAuthReq>) {
        mActivity.showLoading()
        var rqst = InviteRemoveRequest(userlist.get(list_pos).authId)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.apiServiceWithAuthorization.invite_again(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error);mActivity.hideLoading() })

    }

    private fun removeData(userlist: SentAuthReq, position: Int) {
        list_pos = position
        var rqst = RemoveRequest(userlist.authId)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.apiServiceWithAuthorization.removethreefa(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error); })

    }

    private fun onOffAuthenticatorApi(statu_onoff: Int) {

        var rqst = onoffAuthenticatorRequest(statu_onoff)
        val plainText = Gson().toJson(rqst)
        val cryptLib = CryptLib()
        val cipherText = cryptLib.encryptPlainTextWithRandomIV(plainText)

        mActivity.apiServiceWithAuthorization.onOffAuthenticator(JavaWallet.mPreferenceDataModal.JWTToken, cipherText)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error); })
    }

    private fun getUserConatctApi() {
        mActivity.apiServiceWithAuthorization.getUserContact(JavaWallet.mPreferenceDataModal.JWTToken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ println(it);handleResponse(it) },
                        { error -> mActivity.handleError(error); })

    }


    private fun handleResponse(it: Any?) {

        when (it) {

            is SentThreeFaqResponse -> {
                mActivity.hideLoading()
                switch_factor.isEnabled = true
                rltv_invite.isEnabled = true
                if (it.status) {

                    userlist = it.data.sentAuthReqs
                    adaptr = RequsetSent_Adapter(userlist, this)
                    rcycl_sentrequests.adapter = adaptr
                    if (userlist.size >= 2) {
                        rltv_invite.isEnabled = false
                        ic_plls.alpha = 0.2f
                        tv_add.alpha = 0.5f
                    } else {
                        rltv_invite.isEnabled = true
                        ic_plls.alpha = 1.0f
                        tv_add.alpha = 1.0f
                    }

                    if (it.data.faStatus == 0) {
                        switch_factor.isChecked = false
                        tvfactor_text.text = getString(com.JavaWallet.R.string._3_factor_authentication_is_safest)
                        tvfactor_text.setTextColor(mActivity.resources.getColor(com.JavaWallet.R.color.factortext))
                        tv_setlimit.isEnabled = false
                        tv_setlimit.alpha = 0.4f
                        rltv_invite.isEnabled = false
                        ic_plls.alpha = 0.2f
                        tv_add.alpha = 0.5f

                    } else if (it.data.faStatus == 1) {
                        switch_factor.isChecked = true
                        if (userlist.size == 2) {
                            rltv_invite.isEnabled = false
                            ic_plls.alpha = 0.4f
                            tv_add.alpha = 0.5f
                        } else {
                            rltv_invite.isEnabled = true
                            ic_plls.alpha = 1.0f
                            tv_add.alpha = 1.0f
                        }
                        tvfactor_text.text = getString(com.JavaWallet.R.string._3_factor_authentication_is_safest)
                        tvfactor_text.setTextColor(mActivity.resources.getColor(com.JavaWallet.R.color.factortext))
                        tv_setlimit.isEnabled = true
                        tv_setlimit.alpha = 1.0f

                    } else if (it.data.faStatus == 2) {

                        if (userlist.size == 2) {
                            rltv_invite.isEnabled = false
                            ic_plls.alpha = 0.4f
                            tv_add.alpha = 0.5f
                        } else {
                            rltv_invite.isEnabled = true
                            ic_plls.alpha = 1.0f
                            tv_add.alpha = 1.0f
                        }
                        switch_factor.isChecked = true
                        switch_factor.isEnabled = false
                        tv_setlimit.isEnabled = true

                        var oldfa_date = mActivity.convertUTCtoDeviceZone(it.data.faStatusDate, "MM/dd/yyyy HH:mm:ss")
                        val sdf = SimpleDateFormat("MM/dd/yyyy HH:mm:ss")
                        val c = Calendar.getInstance()
                        try {
                            c.time = sdf.parse(oldfa_date)
                        } catch (e: ParseException) {
                            e.printStackTrace()
                        }
                        c.add(Calendar.DATE, 1);
                        var newDate = sdf.format(c.getTime());
                        val c_new = Calendar.getInstance()
                        var diff = mActivity.getHoursminutes(sdf.format(c_new.getTime()), newDate)
                        tv_setlimit.alpha = 1.0f
                        tvfactor_text.text = "Your request for turning off 3-Factor Authentication is in progress. It will be turned off in " + diff
                        tvfactor_text.setTextColor(mActivity.resources.getColor(com.JavaWallet.R.color.orange_progress))

                    }
                    getUserConatctApi()
                }

            }
            is InviteAgainResponse -> {
                mActivity.hideLoading()
                if (it.status) {
                    isonActivityrslt = false

                }
            }

            is RemoveResponse -> {

                if (it.status) {
                    userlist.removeAt(list_pos)
                    adaptr.notifyDataSetChanged()
                    getData()
                }
            }
            is AuthenticatorResponse -> {

                if (it.status) {
                    getData()
                }

            }
            is UserContactResponse -> {
                if (it.status) {
                    yourlabel = it.data.name
                }

            }

        }

    }

    private fun onclick() {

        tv_setlimit.setOnClickListener(this)
        rltv_invite.setOnClickListener(this)
    }


    override fun onremove_Click(userlist: SentAuthReq, position: Int) {

        removeData(userlist, position)
    }

    override fun oninvite_Click(userlist: ArrayList<SentAuthReq>, position: Int) {
        list_pos = position
        userlistinvite = userlist
        messageIntnt()

    }

    private fun messageIntnt() {
        val msg = ("Hi " + userlist.get(list_pos).label + "\nI am inviting you on " + yourlabel + " Java Wallet as a Cosigner. Use referral code "
                + userlist.get(list_pos).refCode + " while logging in. Use https://play.google.com/store/apps/details?id=com.JavaWallet to download the app.")
        val intent = Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(getString(R.string.smsto) + userlist.get(list_pos).countryCode.countryCodeId.toString() + userlist.get(list_pos).toMobile));
        intent.putExtra(getString(R.string.smsaddress), userlist.get(list_pos).countryCode.countryCodeId.toString() + userlist.get(list_pos).toMobile);
        intent.putExtra(getString(R.string.sms_body), msg);
        intent.putExtra(getString(R.string.exit_on_sent), true);
        startActivityForResult(intent, mActivity.Invite_again);
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == mActivity.Invite_again) {
            isonActivityrslt = true
            when (resultCode) {

                Activity.RESULT_OK -> showconfirmDialog()
                Activity.RESULT_CANCELED // unfortunately returned by default android sms app at the moment
                -> showconfirmDialog()
                else -> Toast.makeText(activity, getString(R.string.errorsendingtext), Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun showconfirmDialog() {

        var dialog = Dialog(mActivity)
        dialog.setCancelable(false)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(R.layout.logout_dialog)
        dialog.dialog_message.text = getString(R.string.sentthemessage)
        dialog.dialog_no.setOnClickListener {
            dialog.dismiss()
            mActivity.showToast(getString(R.string.messageagain))
        }
        dialog.dialog_yes.setOnClickListener {
            dialog.dismiss()
            inviteAgainApi(userlistinvite)
            // ConstantsUtils.CurrentScreen = 0

        }
        dialog.show()
    }


    override fun onClick(p0: View?) {
        when (p0) {
            tv_setlimit -> {
                mActivity.startNewActivity(SetLimit())
                mActivity.finish();
            }
            rltv_invite -> {
                try {
                    if (userlist.size != 2) {
                        mActivity.startNewActivity(Invite_Authenticator())
                        mActivity.finish();
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }

            }


        }

    }

}